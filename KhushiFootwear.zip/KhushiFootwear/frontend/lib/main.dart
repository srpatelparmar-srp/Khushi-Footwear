import 'package:flutter/material.dart';
import 'views/accountant_view.dart';
import 'views/sales_executive_view.dart';
import 'views/customer_store_view.dart';
import 'views/admin_erp_modules_view.dart';
import 'views/owner_app_view.dart';
import 'views/staff_app_view.dart';
import 'views/footwear_suite_view.dart';
import 'views/reports_analytics_view.dart';
import 'views/business_flow_view.dart';
import 'views/db_architecture_view.dart';

final ValueNotifier<ThemeMode> themeModeNotifier = ValueNotifier(ThemeMode.light);

void main() {
  runApp(const KhushiFootwearApp());
}

class KhushiFootwearApp extends StatelessWidget {
  const KhushiFootwearApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeModeNotifier,
      builder: (context, currentMode, _) {
        return MaterialApp(
          title: 'Khushi Footwear ERP & POS',
          debugShowCheckedModeBanner: false,
          themeMode: currentMode,
          theme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.light,
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF4F46E5),
              primary: const Color(0xFF4F46E5),
              secondary: const Color(0xFFEC4899),
              surface: Colors.white,
            ),
            scaffoldBackgroundColor: const Color(0xFFF8FAFC),
            fontFamily: 'Segoe UI',
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.dark,
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF4F46E5),
              brightness: Brightness.dark,
              primary: const Color(0xFF6366F1),
              secondary: const Color(0xFFF472B6),
              surface: const Color(0xFF1E293B),
            ),
            scaffoldBackgroundColor: const Color(0xFF0F172A),
            fontFamily: 'Segoe UI',
          ),
          home: const AuthWrapperScreen(),
        );
      },
    );
  }
}

// -------------------------------------------------------------
// DATA MODELS
// -------------------------------------------------------------
class LoggedUser {
  final String username;
  final String fullName;
  final String role;
  final String token;

  LoggedUser({
    required this.username,
    required this.fullName,
    required this.role,
    required this.token,
  });
}

// -------------------------------------------------------------
// AUTH WRAPPER (LOGIN / REGISTRATION)
// -------------------------------------------------------------
class AuthWrapperScreen extends StatefulWidget {
  const AuthWrapperScreen({super.key});

  @override
  State<AuthWrapperScreen> createState() => _AuthWrapperScreenState();
}

class _AuthWrapperScreenState extends State<AuthWrapperScreen> {
  LoggedUser? _currentUser;
  bool _isRegisterMode = false;

  final TextEditingController _usernameCtrl = TextEditingController(text: 'purchasemgr');
  final TextEditingController _passwordCtrl = TextEditingController(text: 'Password@123');
  final TextEditingController _fullNameCtrl = TextEditingController();
  final TextEditingController _phoneCtrl = TextEditingController();
  final TextEditingController _emailCtrl = TextEditingController();

  String _selectedRole = 'Purchase Manager';
  final List<String> _roles = [
    'Super Admin',
    'Shop Owner',
    'Store Manager',
    'Cashier',
    'Inventory Manager',
    'Purchase Manager',
    'Accountant',
    'Sales Executive',
    'Customer',
  ];

  void _handleLogin() {
    final user = _usernameCtrl.text.trim();
    if (user.isEmpty) return;

    setState(() {
      _currentUser = LoggedUser(
        username: user,
        fullName: _fullNameCtrl.text.isNotEmpty ? _fullNameCtrl.text : '$user ($_selectedRole)',
        role: _selectedRole,
        token: 'auth_jwt_token_${DateTime.now().millisecondsSinceEpoch}',
      );
    });
  }

  void _handleRegister() {
    if (_usernameCtrl.text.trim().isEmpty || _fullNameCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all mandatory fields!')),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Account for ${_fullNameCtrl.text} created! You can now log in.')),
    );
    setState(() => _isRegisterMode = false);
  }

  void _handleLogout() {
    setState(() {
      _currentUser = null;
    });
  }

  void _showForgotPasswordDialog() {
    final phoneOrUserCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.lock_reset, color: Color(0xFF4F46E5)),
            SizedBox(width: 8),
            Text('Forgot Password / Reset OTP'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Enter your registered username or mobile number to receive a 6-digit verification code.'),
            const SizedBox(height: 12),
            TextField(
              controller: phoneOrUserCtrl,
              decoration: const InputDecoration(
                labelText: 'Username or Mobile (+91)',
                prefixIcon: Icon(Icons.phone_android),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Verification OTP dispatched to registered mobile for ${phoneOrUserCtrl.text}!')),
              );
            },
            child: const Text('Send Reset OTP'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_currentUser != null) {
      return MainShellScreen(user: _currentUser!, onLogout: _handleLogout);
    }

    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 440),
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.grey.shade200),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                )
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFF59E0B), Color(0xFFEC4899), Color(0xFF6366F1)],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.snowshoeing_rounded, color: Colors.white, size: 28),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'KHUSHI FOOTWEAR',
                          style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 1.2, color: Color(0xFF0F172A)),
                        ),
                        Text('Enterprise ERP & Smart POS', style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Text(
                  _isRegisterMode ? 'Create New Account' : 'Sign In to Your Workspace',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1E293B)),
                ),
                const SizedBox(height: 6),
                Text(
                  _isRegisterMode
                      ? 'Register with your assigned role to access custom dashboards'
                      : 'Choose your role and enter credentials to continue',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                ),
                const SizedBox(height: 20),

                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _selectedRole,
                      isExpanded: true,
                      icon: const Icon(Icons.arrow_drop_down, color: Color(0xFF4F46E5)),
                      items: _roles.map((r) => DropdownMenuItem(value: r, child: Text('Role: $r', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)))).toList(),
                      onChanged: (val) {
                        if (val != null) {
                          setState(() {
                            _selectedRole = val;
                            if (!_isRegisterMode) {
                              _usernameCtrl.text = val.toLowerCase().replaceAll(' ', '');
                            }
                          });
                        }
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 12),

                if (_isRegisterMode) ...[
                  TextField(
                    controller: _fullNameCtrl,
                    decoration: InputDecoration(
                      labelText: 'Full Name',
                      prefixIcon: const Icon(Icons.person_outline, size: 20),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      isDense: true,
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _phoneCtrl,
                    decoration: InputDecoration(
                      labelText: 'Mobile Phone',
                      prefixIcon: const Icon(Icons.phone_outlined, size: 20),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      isDense: true,
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _emailCtrl,
                    decoration: InputDecoration(
                      labelText: 'Email Address',
                      prefixIcon: const Icon(Icons.email_outlined, size: 20),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      isDense: true,
                    ),
                  ),
                  const SizedBox(height: 12),
                ],

                TextField(
                  controller: _usernameCtrl,
                  decoration: InputDecoration(
                    labelText: 'Username',
                    prefixIcon: const Icon(Icons.badge_outlined, size: 20),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 12),

                TextField(
                  controller: _passwordCtrl,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    prefixIcon: const Icon(Icons.lock_outline, size: 20),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    isDense: true,
                  ),
                ),
                if (!_isRegisterMode) ...[
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: _showForgotPasswordDialog,
                      child: const Text('Forgot Password?', style: TextStyle(fontSize: 11, color: Color(0xFF4F46E5))),
                    ),
                  ),
                ] else ...[
                  const SizedBox(height: 16),
                ],

                SizedBox(
                  height: 44,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF4F46E5),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    onPressed: _isRegisterMode ? _handleRegister : _handleLogin,
                    child: Text(
                      _isRegisterMode ? 'Register Account' : 'Sign In as $_selectedRole',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
                const SizedBox(height: 14),

                TextButton(
                  onPressed: () {
                    setState(() => _isRegisterMode = !_isRegisterMode);
                  },
                  child: Text(
                    _isRegisterMode ? 'Already have an account? Sign In' : 'Need an account? Register Here',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF4F46E5)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// -------------------------------------------------------------
// MAIN SHELL SCREEN (ROLE ACCESS + COMPLETE PURCHASE SUITE)
// -------------------------------------------------------------
class MainShellScreen extends StatefulWidget {
  final LoggedUser user;
  final VoidCallback onLogout;

  const MainShellScreen({super.key, required this.user, required this.onLogout});

  @override
  State<MainShellScreen> createState() => _MainShellScreenState();
}

class _MainShellScreenState extends State<MainShellScreen> {
  int _activeModule = 0;
  late String _currentRole;

  @override
  void initState() {
    super.initState();
    _currentRole = widget.user.role;
  }

  @override
  Widget build(BuildContext context) {
    final isDesktop = MediaQuery.of(context).size.width >= 900;
    final List<NavigationRailDestination> desktopNavs = _getRoleNavigations();
    final List<NavigationDestination> mobileNavs = _getRoleMobileNavigations();

    return Scaffold(
      appBar: AppBar(
        elevation: 0.5,
        backgroundColor: Colors.white,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFF59E0B), Color(0xFFEC4899), Color(0xFF6366F1)],
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.snowshoeing, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'KHUSHI FOOTWEAR',
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 1.1, color: Color(0xFF0F172A)),
                  ),
                  Text(
                    'Logged: ${widget.user.fullName} (${widget.user.role})',
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 10, color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Switch Flutter App Mode',
            onSelected: (newRole) {
              setState(() {
                _currentRole = newRole;
                _activeModule = 0;
              });
            },
            itemBuilder: (ctx) => [
              const PopupMenuItem(value: 'DB Architecture', child: Text('💾 Stored Procedures, Views & Sequences')),
              const PopupMenuItem(value: 'Business Flow', child: Text('🔄 10-Step Main Business Flow')),
              const PopupMenuItem(value: '23 Reports', child: Text('📊 23 Reports & Analytics Suite')),
              const PopupMenuItem(value: 'Footwear Suite', child: Text('👟 Footwear Specialist (18 Features)')),
              const PopupMenuItem(value: 'Shop Owner', child: Text('📱 Owner App (8 Features)')),
              const PopupMenuItem(value: 'Cashier', child: Text('📱 Staff App (8 Features)')),
              const PopupMenuItem(value: 'Customer', child: Text('📱 Customer App (10 Features)')),
              const PopupMenuItem(value: 'Super Admin', child: Text('🌐 Full ERP (21 Web Modules)')),
              const PopupMenuItem(value: 'Sales Executive', child: Text('👞 Sales Executive Module')),
              const PopupMenuItem(value: 'Accountant', child: Text('💰 Accountant Module')),
            ],
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFEEF2FF),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFFC7D2FE)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.apps, size: 14, color: Color(0xFF4F46E5)),
                  const SizedBox(width: 4),
                  Text('App: $_currentRole', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF3730A3))),
                  const Icon(Icons.arrow_drop_down, size: 16, color: Color(0xFF4F46E5)),
                ],
              ),
            ),
          ),
          // Dark / Light Theme Toggle
          IconButton(
            icon: Icon(
              themeModeNotifier.value == ThemeMode.dark ? Icons.light_mode : Icons.dark_mode_outlined,
              size: 20,
              color: const Color(0xFF4F46E5),
            ),
            tooltip: 'Toggle Dark / Light Theme',
            onPressed: () {
              setState(() {
                themeModeNotifier.value = themeModeNotifier.value == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
              });
            },
          ),
          // User Profile & Settings Menu
          PopupMenuButton<String>(
            tooltip: 'User Account & Security',
            icon: const Icon(Icons.account_circle_outlined, size: 22, color: Color(0xFF4F46E5)),
            onSelected: (val) {
              if (val == 'change_password') {
                _showChangePasswordDialog();
              } else if (val == 'audit_logs') {
                _showActivityLogsDialog();
              } else if (val == 'backup') {
                _showDataBackupDialog();
              }
            },
            itemBuilder: (ctx) => [
              PopupMenuItem(
                enabled: false,
                child: Text('User: ${widget.user.fullName}\nRole: ${widget.user.role}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
              ),
              const PopupMenuDivider(),
              const PopupMenuItem(value: 'change_password', child: Row(children: [Icon(Icons.password, size: 16), SizedBox(width: 8), Text('Change Password')])),
              const PopupMenuItem(value: 'audit_logs', child: Row(children: [Icon(Icons.history, size: 16), SizedBox(width: 8), Text('Activity Audit Logs')])),
              const PopupMenuItem(value: 'backup', child: Row(children: [Icon(Icons.cloud_upload, size: 16), SizedBox(width: 8), Text('Data Backup')])),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.logout, size: 20, color: Colors.redAccent),
            tooltip: 'Sign Out',
            onPressed: widget.onLogout,
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Row(
        children: [
          if (isDesktop)
            NavigationRail(
              selectedIndex: _activeModule < desktopNavs.length ? _activeModule : 0,
              onDestinationSelected: (idx) => setState(() => _activeModule = idx),
              labelType: NavigationRailLabelType.all,
              backgroundColor: Colors.white,
              selectedIconTheme: const IconThemeData(color: Color(0xFF4F46E5)),
              selectedLabelTextStyle: const TextStyle(color: Color(0xFF4F46E5), fontWeight: FontWeight.bold),
              destinations: desktopNavs,
            ),
          Expanded(
            child: _buildRoleSpecificContent(isDesktop),
          ),
        ],
      ),
      bottomNavigationBar: !isDesktop
          ? NavigationBar(
              selectedIndex: _activeModule < mobileNavs.length ? _activeModule : 0,
              onDestinationSelected: (idx) => setState(() => _activeModule = idx),
              destinations: mobileNavs,
            )
          : null,
    );
  }

  List<NavigationRailDestination> _getRoleNavigations() {
    if (_currentRole == 'Accountant') {
      return const [
        NavigationRailDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: Text('Cashbook')),
        NavigationRailDestination(icon: Icon(Icons.receipt_long_outlined), label: Text('Expenses')),
        NavigationRailDestination(icon: Icon(Icons.account_balance_outlined), label: Text('Bank & UPI')),
        NavigationRailDestination(icon: Icon(Icons.credit_card_outlined), label: Text('Outstanding')),
        NavigationRailDestination(icon: Icon(Icons.calculate_outlined), label: Text('GST Records')),
        NavigationRailDestination(icon: Icon(Icons.badge_outlined), label: Text('Salaries')),
        NavigationRailDestination(icon: Icon(Icons.insights_outlined), label: Text('P&L Statement')),
      ];
    }
    if (_currentRole == 'Sales Executive') {
      return const [
        NavigationRailDestination(icon: Icon(Icons.snowshoeing_outlined), label: Text('Footwear Catalog')),
        NavigationRailDestination(icon: Icon(Icons.people_alt_outlined), label: Text('Customer Profiles')),
        NavigationRailDestination(icon: Icon(Icons.mark_chat_unread_outlined), label: Text('Lead Enquiries')),
        NavigationRailDestination(icon: Icon(Icons.handshake_outlined), label: Text('Sales Orders')),
        NavigationRailDestination(icon: Icon(Icons.auto_awesome_outlined), label: Text('Recommendations')),
        NavigationRailDestination(icon: Icon(Icons.track_changes_outlined), label: Text('Targets & Comm')),
      ];
    }
    if (_currentRole == 'Customer') {
      return const [
        NavigationRailDestination(icon: Icon(Icons.storefront_outlined), label: Text('Shop Shoes & Offers')),
        NavigationRailDestination(icon: Icon(Icons.shopping_cart_outlined), label: Text('My Cart & Checkout')),
        NavigationRailDestination(icon: Icon(Icons.local_shipping_outlined), label: Text('Orders & Tracking')),
        NavigationRailDestination(icon: Icon(Icons.favorite_border_outlined), label: Text('Wishlist & Loyalty')),
        NavigationRailDestination(icon: Icon(Icons.person_outline), label: Text('Profile & Reviews')),
      ];
    }
    if (_currentRole == 'Purchase Manager') {
      return const [
        NavigationRailDestination(icon: Icon(Icons.local_shipping_outlined), label: Text('Suppliers')),
        NavigationRailDestination(icon: Icon(Icons.shopping_cart_checkout_outlined), label: Text('Purchase Orders')),
        NavigationRailDestination(icon: Icon(Icons.receipt_long_outlined), label: Text('Purchase Invoices')),
        NavigationRailDestination(icon: Icon(Icons.replay_outlined), label: Text('Purchase Returns')),
        NavigationRailDestination(icon: Icon(Icons.payments_outlined), label: Text('Supplier Payments')),
        NavigationRailDestination(icon: Icon(Icons.analytics_outlined), label: Text('Purchase Reports')),
      ];
    }
    if (_currentRole == 'Inventory Manager') {
      return const [
        NavigationRailDestination(icon: Icon(Icons.inventory_2_outlined), label: Text('Stock Matrix')),
        NavigationRailDestination(icon: Icon(Icons.add_box_outlined), label: Text('Stock Inward (GRN)')),
        NavigationRailDestination(icon: Icon(Icons.warning_amber), label: Text('Low & Out Stock')),
        NavigationRailDestination(icon: Icon(Icons.broken_image_outlined), label: Text('Damaged Shoes')),
        NavigationRailDestination(icon: Icon(Icons.fact_check_outlined), label: Text('Physical Audits')),
      ];
    }
    if (_currentRole == 'Cashier') {
      return const [
        NavigationRailDestination(icon: Icon(Icons.point_of_sale_outlined), label: Text('POS Billing')),
        NavigationRailDestination(icon: Icon(Icons.search_rounded), label: Text('Search Shoes')),
        NavigationRailDestination(icon: Icon(Icons.swap_horiz_rounded), label: Text('Returns & Exch')),
        NavigationRailDestination(icon: Icon(Icons.receipt_long), label: Text('Daily Sales')),
        NavigationRailDestination(icon: Icon(Icons.lock_clock_outlined), label: Text('Counter Shift')),
      ];
    }

    return const [
      NavigationRailDestination(icon: Icon(Icons.dashboard_outlined), label: Text('Dashboard')),
      NavigationRailDestination(icon: Icon(Icons.point_of_sale_outlined), label: Text('POS Billing')),
      NavigationRailDestination(icon: Icon(Icons.inventory_2_outlined), label: Text('Inventory')),
      NavigationRailDestination(icon: Icon(Icons.swap_horiz_rounded), label: Text('Exchanges')),
      NavigationRailDestination(icon: Icon(Icons.storefront_outlined), label: Text('Catalog')),
      NavigationRailDestination(icon: Icon(Icons.analytics_outlined), label: Text('23 Reports')),
    ];
  }

  List<NavigationDestination> _getRoleMobileNavigations() {
    if (_currentRole == 'Accountant') {
      return const [
        NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Cashbook'),
        NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'Expenses'),
        NavigationDestination(icon: Icon(Icons.account_balance_outlined), label: 'Bank/UPI'),
        NavigationDestination(icon: Icon(Icons.calculate_outlined), label: 'GST'),
        NavigationDestination(icon: Icon(Icons.insights_outlined), label: 'P&L'),
      ];
    }
    if (_currentRole == 'Sales Executive') {
      return const [
        NavigationDestination(icon: Icon(Icons.snowshoeing_outlined), label: 'Catalog'),
        NavigationDestination(icon: Icon(Icons.people_alt_outlined), label: 'Customers'),
        NavigationDestination(icon: Icon(Icons.mark_chat_unread_outlined), label: 'Leads'),
        NavigationDestination(icon: Icon(Icons.handshake_outlined), label: 'Orders'),
        NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), label: 'Picks'),
        NavigationDestination(icon: Icon(Icons.track_changes_outlined), label: 'Targets'),
      ];
    }
    if (_currentRole == 'Customer') {
      return const [
        NavigationDestination(icon: Icon(Icons.storefront_outlined), label: 'Shop'),
        NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), label: 'Cart'),
        NavigationDestination(icon: Icon(Icons.local_shipping_outlined), label: 'Orders'),
        NavigationDestination(icon: Icon(Icons.favorite_border_outlined), label: 'Wishlist'),
        NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
      ];
    }
    if (_currentRole == 'Purchase Manager') {
      return const [
        NavigationDestination(icon: Icon(Icons.local_shipping_outlined), label: 'Suppliers'),
        NavigationDestination(icon: Icon(Icons.shopping_cart_checkout_outlined), label: 'Orders'),
        NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'Invoices'),
        NavigationDestination(icon: Icon(Icons.payments_outlined), label: 'Payments'),
        NavigationDestination(icon: Icon(Icons.analytics_outlined), label: 'Reports'),
      ];
    }
    if (_currentRole == 'Cashier') {
      return const [
        NavigationDestination(icon: Icon(Icons.point_of_sale_outlined), label: 'POS Billing'),
        NavigationDestination(icon: Icon(Icons.search_rounded), label: 'Search'),
        NavigationDestination(icon: Icon(Icons.swap_horiz), label: 'Returns'),
        NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Daily Sales'),
        NavigationDestination(icon: Icon(Icons.lock_clock_outlined), label: 'Shift'),
      ];
    }

    return const [
      NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Dashboard'),
      NavigationDestination(icon: Icon(Icons.point_of_sale_outlined), label: 'POS'),
      NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'Stock'),
      NavigationDestination(icon: Icon(Icons.swap_horiz), label: 'Exchange'),
      NavigationDestination(icon: Icon(Icons.analytics_outlined), label: 'Reports'),
    ];
  }

  Widget _buildRoleSpecificContent(bool isDesktop) {
    if (_currentRole == 'DB Architecture') {
      return const DatabaseArchitectureView();
    }
    if (_currentRole == 'Business Flow') {
      return BusinessFlowView(isDesktop: isDesktop);
    }
    if (_currentRole == '23 Reports') {
      return ReportsAnalyticsView(isDesktop: isDesktop);
    }
    if (_currentRole == 'Footwear Suite') {
      return FootwearSuiteView(isDesktop: isDesktop);
    }
    if (_currentRole == 'Shop Owner') {
      return OwnerAppView(isDesktop: isDesktop);
    }
    if (_currentRole == 'Cashier' || _currentRole == 'Store Manager') {
      return StaffAppView(isDesktop: isDesktop);
    }
    if (_currentRole == 'Accountant') {
      return AccountantView(isDesktop: isDesktop, activeModule: _activeModule);
    }
    if (_currentRole == 'Sales Executive') {
      return SalesExecutiveView(isDesktop: isDesktop, activeModule: _activeModule);
    }
    if (_currentRole == 'Customer') {
      return CustomerStoreView(isDesktop: isDesktop, activeModule: _activeModule);
    }
    if (_currentRole == 'Purchase Manager') {
      switch (_activeModule) {
        case 0:
          return _buildSuppliersManagementModule();
        case 1:
          return _buildPurchaseOrdersModule();
        case 2:
          return _buildPurchaseInvoicesModule();
        case 3:
          return _buildPurchaseReturnsModule();
        case 4:
          return _buildSupplierPaymentsModule();
        case 5:
          return _buildPurchaseReportsModule(isDesktop);
        default:
          return _buildSuppliersManagementModule();
      }
    }

    return _buildDashboard(isDesktop);
  }

  // ===========================================================
  // PURCHASE MANAGER COMPLETE 12 FUNCTIONALITIES
  // ===========================================================

  // 1. Manage Suppliers & View Supplier Outstanding
  Widget _buildSuppliersManagementModule() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Wholesale Footwear Suppliers & Creditors', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('Manage vendor contacts, GSTIN numbers, bank details and outstanding payable balances', style: TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
              ElevatedButton.icon(
                onPressed: () => _showAddSupplierDialog(context),
                icon: const Icon(Icons.add_business, size: 16),
                label: const Text('Add Supplier'),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
              )
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _metricTile('Active Suppliers', '14 Vendors', Icons.local_shipping, const Color(0xFF4F46E5), 'Footwear Manufacturers')),
              const SizedBox(width: 10),
              Expanded(child: _metricTile('Total Outstanding Due', '₹ 45,000', Icons.pending_actions, Colors.red, 'Payable within 15 days')),
              const SizedBox(width: 10),
              Expanded(child: _metricTile('Month Purchases', '₹ 2,85,400', Icons.shopping_bag, Colors.green, '48 Shipments fulfilled')),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView(
              children: [
                _supplierCard('Nike India Wholesale Ltd.', 'Contact: Ramesh Nair', '+91 98220 98765', 'GSTIN: 27AAACN1234F1Z9', 'Due: ₹ 0.00', Colors.green),
                const SizedBox(height: 10),
                _supplierCard('Metro Leather Goods Traders', 'Contact: Iqbal Khan', '+91 94220 11223', 'GSTIN: 24BBBML5678G2Z3', 'Due: ₹ 45,000.00', Colors.red),
                const SizedBox(height: 10),
                _supplierCard('Crocs Brand Regional Distributor', 'Contact: Sandeep Patil', '+91 97654 44556', 'GSTIN: 29CCDCB9012H3Z1', 'Due: ₹ 0.00', Colors.green),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _supplierCard(String name, String contact, String phone, String gst, String due, Color col) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.grey.shade200)),
      child: Row(
        children: [
          CircleAvatar(backgroundColor: col.withValues(alpha: 0.1), child: Icon(Icons.local_shipping, color: col, size: 20)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                Text('$contact • $phone • $gst', style: const TextStyle(fontSize: 11, color: Colors.grey)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(due, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: col)),
              const Text('Terms: Net 30', style: TextStyle(fontSize: 10, color: Colors.grey)),
            ],
          )
        ],
      ),
    );
  }

  // 2. Create, Update, Approve & Receive Purchase Orders
  Widget _buildPurchaseOrdersModule() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Purchase Orders (PO) & GRN Generation', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('Create POs, send for approval, receive shipments and generate Goods Receipt Notes', style: TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
              ElevatedButton.icon(
                onPressed: () => _showCreatePODialog(context),
                icon: const Icon(Icons.add_shopping_cart, size: 16),
                label: const Text('New Purchase Order'),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
              )
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView(
              children: [
                _poTile('PO-882101', 'Nike India Wholesale', '48 Pairs (Nike Air Zoom)', '₹ 1,42,000.00', 'RECEIVED', Colors.green),
                const SizedBox(height: 10),
                _poTile('PO-882102', 'Metro Leather Traders', '24 Pairs (Formal Oxford)', '₹ 84,500.00', 'APPROVED', Colors.blue),
                const SizedBox(height: 10),
                _poTile('PO-882103', 'Crocs Distributor', '30 Pairs (Classic Clogs)', '₹ 58,900.00', 'PENDING', Colors.orange),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _poTile(String poNo, String supplier, String desc, String amt, String status, Color col) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.grey.shade200)),
      child: Row(
        children: [
          CircleAvatar(backgroundColor: col.withValues(alpha: 0.1), child: Icon(Icons.receipt, color: col, size: 20)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(poNo, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF4F46E5))),
                Text('$supplier • $desc', style: const TextStyle(fontSize: 11, color: Colors.grey)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(amt, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              Chip(
                label: Text(status, style: const TextStyle(fontSize: 8, color: Colors.white)),
                backgroundColor: col,
                padding: EdgeInsets.zero,
              ),
            ],
          )
        ],
      ),
    );
  }

  // 3. Purchase Invoices Module
  Widget _buildPurchaseInvoicesModule() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Supplier Purchase Invoices & GST Input Credit', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Track incoming supplier tax invoices, GST Input Tax Credit (ITC), and balance payable', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Expanded(
            child: ListView(
              children: const [
                ListTile(
                  leading: Icon(Icons.receipt_long, color: Colors.indigo),
                  title: Text('PINV-2026-8801: Metro Leather Goods Traders'),
                  subtitle: Text('Invoice Date: 12 Nov 2026 | Subtotal: ₹ 75,446 | GST (12%): ₹ 9,054'),
                  trailing: Text('Total: ₹ 84,500\nDue: ₹ 45,000', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red, fontSize: 11), textAlign: TextAlign.right),
                ),
                Divider(),
                ListTile(
                  leading: Icon(Icons.receipt_long, color: Colors.indigo),
                  title: Text('PINV-2026-8799: Nike India Wholesale Ltd.'),
                  subtitle: Text('Invoice Date: 05 Nov 2026 | Subtotal: ₹ 1,26,785 | GST (12%): ₹ 15,215'),
                  trailing: Text('Total: ₹ 1,42,000\nPAID', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 11), textAlign: TextAlign.right),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  // 4. Purchase Returns & Debit Notes
  Widget _buildPurchaseReturnsModule() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Purchase Returns & Debit Notes (RTV)', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('Return defective shoe consignments and issue formal GST Debit Notes to manufacturers', style: TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
              ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.replay, size: 16),
                label: const Text('Issue Debit Note'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, foregroundColor: Colors.white),
              )
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView(
              children: const [
                ListTile(
                  leading: Icon(Icons.assignment_return, color: Colors.orange),
                  title: Text('Debit Note #DBN-2026-012: Metro Leather Traders'),
                  subtitle: Text('4 Pairs returned | Reason: Wrong shoe sizes delivered (UK 6 instead of UK 8)'),
                  trailing: Text('Refund: ₹ 8,800.00\nSETTLED', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 11), textAlign: TextAlign.right),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  // 5. Supplier Payments Module
  Widget _buildSupplierPaymentsModule() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Supplier Payments Ledger (Bank NEFT / RTGS)', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Record supplier disbursements, bank transaction reference (UTR) numbers, and update credit balances', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Expanded(
            child: ListView(
              children: const [
                ListTile(
                  leading: Icon(Icons.payments, color: Colors.green),
                  title: Text('Payment #SPAY-2026-044 to Metro Leather Traders'),
                  subtitle: Text('Mode: NEFT (Ref: HDFC00012349876) | Part-payment against PO-8801'),
                  trailing: Text('₹ 39,500.00', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
                ),
                Divider(),
                ListTile(
                  leading: Icon(Icons.payments, color: Colors.green),
                  title: Text('Payment #SPAY-2026-043 to Nike India Wholesale'),
                  subtitle: Text('Mode: RTGS (Ref: UTIB00098765432) | Full settlement for PO-8799'),
                  trailing: Text('₹ 1,42,000.00', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  // 6. Purchase Reports & History
  Widget _buildPurchaseReportsModule(bool isDesktop) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Purchase Reports, Analytics & Procurement Velocity', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Monthly procurement spend, supplier performance, and footwear replenishment lead times', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.grey.shade200)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Top Supplier Volume Breakdown', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(height: 12),
                _sizeBar('Nike India Wholesale Ltd.', 0.70, '₹ 1,42,000 (180 Pairs)'),
                _sizeBar('Metro Leather Goods Traders', 0.45, '₹ 85,400 (140 Pairs)'),
                _sizeBar('Crocs Brand Regional Logistics', 0.30, '₹ 58,000 (95 Pairs)'),
              ],
            ),
          )
        ],
      ),
    );
  }

  void _showAddSupplierDialog(BuildContext context) {
    final nameCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    final gstCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add Wholesale Supplier'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Supplier Company Name')),
            TextField(controller: phoneCtrl, decoration: const InputDecoration(labelText: 'Contact Phone Number')),
            TextField(controller: gstCtrl, decoration: const InputDecoration(labelText: 'GSTIN Number (15 digits)')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Supplier ${nameCtrl.text} registered!')));
            },
            child: const Text('Save Supplier'),
          )
        ],
      ),
    );
  }

  void _showCreatePODialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Create New Purchase Order (PO)'),
        content: const Text('Select supplier, specify footwear size/color requirements, and generate formal purchase order document.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Purchase Order Created and submitted for Store Manager approval!')));
            },
            child: const Text('Create PO'),
          )
        ],
      ),
    );
  }

  void _showChangePasswordDialog() {
    final curCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Change Password'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: curCtrl, obscureText: true, decoration: const InputDecoration(labelText: 'Current Password *')),
            const SizedBox(height: 10),
            TextField(controller: newCtrl, obscureText: true, decoration: const InputDecoration(labelText: 'New Password *')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Password updated successfully! Audit log created.')));
            },
            child: const Text('Update Password'),
          ),
        ],
      ),
    );
  }

  void _showActivityLogsDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Security & Activity Audit Logs'),
        content: SizedBox(
          width: 400,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text('Recent Security Events:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              SizedBox(height: 8),
              Text('• 12 Nov, 12:45 PM: User login from Chrome Web (Branch: Pune Flagship)'),
              Text('• 12 Nov, 11:20 AM: Invoice #KF-INV-88231 generated by Anita Deshmukh'),
              Text('• 12 Nov, 10:15 AM: Stock GRN #GRN-088 approved by Store Manager'),
              Text('• 12 Nov, 09:30 AM: Counter 1 Shift opened with float ₹ 5,000.00'),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
        ],
      ),
    );
  }

  void _showDataBackupDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.cloud_done, color: Colors.green),
            SizedBox(width: 8),
            Text('Enterprise Cloud Data Backup'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text('Last Full Backup: Today at 04:00 AM (Size: 42.8 MB)'),
            SizedBox(height: 6),
            Text('Storage Target: Encrypted Cloud Geo-Redundant Vault'),
            SizedBox(height: 6),
            Text('Status: HEALTHY • Automated daily snapshots enabled.'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('On-demand database snapshot created successfully!')));
            },
            child: const Text('Take Backup Now'),
          ),
        ],
      ),
    );
  }

  // Common Helpers
  Widget _buildDashboard(bool isDesktop) {
    return AdminErpModulesView(
      isDesktop: isDesktop,
      role: _currentRole,
      initialModuleIndex: _activeModule,
    );
  }

  Widget _metricTile(String title, String val, IconData icon, Color color, String sub) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.grey.shade200)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(child: Text(title, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey.shade600, fontSize: 11, fontWeight: FontWeight.bold))),
              CircleAvatar(backgroundColor: color.withValues(alpha: 0.12), radius: 14, child: Icon(icon, color: color, size: 16)),
            ],
          ),
          Text(val, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          Text(sub, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, color: Colors.grey.shade500)),
        ],
      ),
    );
  }

  Widget _sizeBar(String label, double progress, String val) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(label, style: const TextStyle(fontSize: 12)), Text(val, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold))]),
          const SizedBox(height: 3),
          LinearProgressIndicator(value: progress, color: const Color(0xFF4F46E5), backgroundColor: const Color(0xFFEEF2FF)),
        ],
      ),
    );
  }
}
