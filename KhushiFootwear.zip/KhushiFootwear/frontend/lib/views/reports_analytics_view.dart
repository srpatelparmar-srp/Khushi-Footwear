import 'package:flutter/material.dart';

class ReportsAnalyticsView extends StatefulWidget {
  final bool isDesktop;

  const ReportsAnalyticsView({super.key, required this.isDesktop});

  @override
  State<ReportsAnalyticsView> createState() => _ReportsAnalyticsViewState();
}

class _ReportsAnalyticsViewState extends State<ReportsAnalyticsView> {
  int _selectedReportIndex = 0;

  final List<String> _reportTitles = [
    '1. Daily Sales Report',
    '2. Monthly Sales Report',
    '3. Yearly Sales Report',
    '4. Brand-Wise Sales Report',
    '5. Category-Wise Sales Report',
    '6. Product-Wise Sales Report',
    '7. Size-Wise Sales Report',
    '8. Color-Wise Sales Report',
    '9. Cashier-Wise Sales Report',
    '10. Purchase Report',
    '11. Supplier Report',
    '12. Customer Report',
    '13. Stock Report',
    '14. Low Stock Report',
    '15. Damaged Stock Report',
    '16. Sales Return Report',
    '17. Exchange Report',
    '18. GST Report (GSTR-3B)',
    '19. Expense Report',
    '20. Profit & Loss Report',
    '21. Customer Outstanding Report',
    '22. Supplier Outstanding Report',
    '23. Employee Performance Report',
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Horizontal Scroll Filter Chips for all 23 Reports
        Container(
          height: 48,
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
          ),
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            itemCount: _reportTitles.length,
            itemBuilder: (context, idx) {
              final isSel = _selectedReportIndex == idx;
              return Padding(
                padding: const EdgeInsets.only(right: 6),
                child: FilterChip(
                  label: Text(_reportTitles[idx],
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: isSel ? FontWeight.bold : FontWeight.w500,
                        color: isSel ? Colors.white : Colors.black87,
                      )),
                  selected: isSel,
                  selectedColor: const Color(0xFF4F46E5),
                  backgroundColor: const Color(0xFFF8FAFC),
                  showCheckmark: false,
                  onSelected: (_) => setState(() => _selectedReportIndex = idx),
                ),
              );
            },
          ),
        ),

        // Body of selected report
        Expanded(
          child: _buildReportBody(),
        ),
      ],
    );
  }

  Widget _buildReportBody() {
    switch (_selectedReportIndex) {
      case 0:
        return _buildDailySalesReport();
      case 1:
        return _buildMonthlySalesReport();
      case 2:
        return _buildYearlySalesReport();
      case 3:
        return _buildBrandSalesReport();
      case 4:
        return _buildCategorySalesReport();
      case 5:
        return _buildProductSalesReport();
      case 6:
        return _buildSizeSalesReport();
      case 7:
        return _buildColorSalesReport();
      case 8:
        return _buildCashierSalesReport();
      case 9:
        return _buildPurchaseReport();
      case 10:
        return _buildSupplierReport();
      case 11:
        return _buildCustomerReport();
      case 12:
        return _buildStockReport();
      case 13:
        return _buildLowStockReport();
      case 14:
        return _buildDamagedStockReport();
      case 15:
        return _buildSalesReturnReport();
      case 16:
        return _buildExchangeReport();
      case 17:
        return _buildGstReport();
      case 18:
        return _buildExpenseReport();
      case 19:
        return _buildProfitAndLossReport();
      case 20:
        return _buildCustomerOutstandingReport();
      case 21:
        return _buildSupplierOutstandingReport();
      case 22:
        return _buildEmployeePerformanceReport();
      default:
        return _buildDailySalesReport();
    }
  }

  // 1. Daily Sales Report
  Widget _buildDailySalesReport() {
    return _reportScaffold(
      '1. Daily Footwear Sales Report (12 Nov 2026)',
      'Detailed counter invoices, pairs sold, GST collected, and payment split across cash, UPI and card.',
      [
        _metricTile('Gross Sales', '₹ 1,48,920', Icons.currency_rupee, Colors.green),
        _metricTile('Invoices Billed', '54 Bills', Icons.receipt, const Color(0xFF4F46E5)),
        _metricTile('Pairs Sold', '342 Pairs', Icons.snowshoeing, Colors.teal),
        _metricTile('GST Collected', '₹ 15,955', Icons.calculate, Colors.indigo),
      ],
      [
        _rowItem('UPI Payments (PhonePe, GPay, Paytm)', '₹ 96,798.00 (65%)', isHighlight: true),
        _rowItem('Cash Collected in Counter Float', '₹ 37,230.00 (25%)'),
        _rowItem('Card Swipes (POS EDC Terminal)', '₹ 14,892.00 (10%)'),
      ],
    );
  }

  // 2. Monthly Sales Report
  Widget _buildMonthlySalesReport() {
    return _reportScaffold(
      '2. Monthly Sales Report (November 2026)',
      'Month-to-date sales trajectory, daily run-rate, and target attainment.',
      [
        _metricTile('Total Revenue', '₹ 4,58,920', Icons.trending_up, Colors.green),
        _metricTile('Average Daily Run-rate', '₹ 38,243 / day', Icons.speed, const Color(0xFF4F46E5)),
        _metricTile('Target Attainment', '76.3%', Icons.track_changes, Colors.teal),
        _metricTile('Average Ticket Size', '₹ 2,731', Icons.shopping_basket, Colors.indigo),
      ],
      [
        _rowItem('Week 1 (01 - 07 Nov)', '₹ 2,68,500.00 (98 Bills)'),
        _rowItem('Week 2 (08 - 12 Nov)', '₹ 1,90,420.00 (70 Bills)'),
        _rowItem('Projected Month-End Sales', '₹ 11,47,000.00 (Exceeds 10L Target)', isHighlight: true),
      ],
    );
  }

  // 3. Yearly Sales Report
  Widget _buildYearlySalesReport() {
    return _reportScaffold(
      '3. Yearly Sales & Annual Growth Report (2026)',
      'Annual footwear turnover, year-on-year growth rate, and seasonal peak analyses.',
      [
        _metricTile('Annual Revenue', '₹ 52,40,000', Icons.account_balance, Colors.green),
        _metricTile('YoY Growth', '+22.4%', Icons.show_chart, Colors.teal),
        _metricTile('Annual Pairs Sold', '18,450 Pairs', Icons.inventory, const Color(0xFF4F46E5)),
        _metricTile('Peak Quarter', 'Q3 Festive', Icons.star, Colors.amber.shade900),
      ],
      [
        _rowItem('Q1 Spring Collection (Jan - Mar)', '₹ 11,20,000.00'),
        _rowItem('Q2 Summer & Back-to-School (Apr - Jun)', '₹ 12,80,000.00'),
        _rowItem('Q3 Monsoon & Outdoor (Jul - Sep)', '₹ 13,40,000.00'),
        _rowItem('Q4 Festive & Wedding (Oct - Dec Projected)', '₹ 15,00,000.00', isHighlight: true),
      ],
    );
  }

  // 4. Brand-wise Sales Report
  Widget _buildBrandSalesReport() {
    return _reportScaffold(
      '4. Brand-Wise Footwear Sales Report',
      'Revenue contribution and pair volumes across official brands in catalog.',
      [
        _metricTile('Top Brand (Nike)', '₹ 1,42,000', Icons.workspace_premium, Colors.black),
        _metricTile('Second (Adidas)', '₹ 98,500', Icons.workspace_premium, Colors.indigo),
        _metricTile('Third (Puma)', '₹ 64,200', Icons.workspace_premium, Colors.red),
        _metricTile('Fourth (Bata)', '₹ 58,900', Icons.workspace_premium, Colors.red.shade900),
      ],
      [
        _rowItem('Nike (Air Max, Pegasus, Court Vision)', '₹ 1,42,000.00 (31.0% Share • 120 Pairs)', isHighlight: true),
        _rowItem('Adidas (Ultraboost Light, Stan Smith)', '₹ 98,500.00 (21.5% Share • 85 Pairs)'),
        _rowItem('Puma (Smash V2, RS-X, Softride)', '₹ 64,200.00 (14.0% Share • 72 Pairs)'),
        _rowItem('Bata (Formal Derby Classic, Oxford)', '₹ 58,900.00 (12.8% Share • 94 Pairs)'),
        _rowItem('Woodland (Waterproof Trekker Boots)', '₹ 45,600.00 (9.9% Share • 38 Pairs)'),
        _rowItem('Campus (Oxyfit Walking Sneaker)', '₹ 38,400.00 (8.4% Share • 64 Pairs)'),
      ],
    );
  }

  // 5. Category-wise Sales Report
  Widget _buildCategorySalesReport() {
    return _reportScaffold(
      '5. Category-Wise Sales Distribution',
      'Sales split between Sports, Formal, Casual, Outdoor, and Ethnic collections.',
      [
        _metricTile('Sports & Running', '45.0% Share', Icons.directions_run, const Color(0xFF4F46E5)),
        _metricTile('Men Formal', '28.0% Share', Icons.work, Colors.teal),
        _metricTile('Outdoor & Boots', '15.0% Share', Icons.hiking, Colors.orange),
        _metricTile('Casual Streetwear', '12.0% Share', Icons.skateboarding, Colors.indigo),
      ],
      [
        _rowItem('Sports & Running Shoes', '₹ 2,06,514.00 (45.0%)', isHighlight: true),
        _rowItem('Men Formal Leather Footwear', '₹ 1,28,497.00 (28.0%)'),
        _rowItem('Outdoor Adventure & Trekking Boots', '₹ 68,838.00 (15.0%)'),
        _rowItem('Casual Slip-ons & Canvas', '₹ 55,071.00 (12.0%)'),
      ],
    );
  }

  // 6. Product-wise Sales Report
  Widget _buildProductSalesReport() {
    return _reportScaffold(
      '6. Product-Wise Model Performance Report',
      'Top-selling individual shoe articles ranked by revenue and pair volume.',
      [
        _metricTile('Rank 1 Model', 'Nike Air Max', Icons.star, Colors.green),
        _metricTile('Rank 2 Model', 'Adidas Boost', Icons.star, Colors.indigo),
        _metricTile('Rank 3 Model', 'Bata Derby', Icons.star, Colors.teal),
        _metricTile('Rank 4 Model', 'Puma Smash', Icons.star, Colors.orange),
      ],
      [
        _rowItem('1. Nike Air Max 270 Flyknit', '₹ 89,950.00 (10 Pairs)', isHighlight: true),
        _rowItem('2. Adidas Ultraboost Light', '₹ 75,992.00 (8 Pairs)'),
        _rowItem('3. Bata Formal Derby Classic', '₹ 44,982.00 (18 Pairs)'),
        _rowItem('4. Puma Smash V2 Leather', '₹ 39,186.00 (14 Pairs)'),
      ],
    );
  }

  // 7. Size-wise Sales Report
  Widget _buildSizeSalesReport() {
    return _reportScaffold(
      '7. Size-Wise Sales Volume Report',
      'Indian standard footwear fitting volume breakdown across UK 6 to 11.',
      [
        _metricTile('Top Size (UK 8)', '38.0% Sales', Icons.straighten, Colors.green),
        _metricTile('Second (UK 9)', '31.9% Sales', Icons.straighten, const Color(0xFF4F46E5)),
        _metricTile('Third (UK 7)', '17.8% Sales', Icons.straighten, Colors.teal),
        _metricTile('Large (UK 10-11)', '3.8% Sales', Icons.straighten, Colors.orange),
      ],
      [
        _rowItem('Size UK 8 (Standard Men Fit)', '188 Pairs • ₹ 4,12,000.00 (38.0%)', isHighlight: true),
        _rowItem('Size UK 9 (Athletic & Formal)', '158 Pairs • ₹ 3,78,000.00 (31.9%)'),
        _rowItem('Size UK 7 (Youth & Slim Fit)', '88 Pairs • ₹ 1,76,000.00 (17.8%)'),
        _rowItem('Size UK 6 (Small Foot Size)', '42 Pairs • ₹ 84,000.00 (8.5%)'),
        _rowItem('Size UK 10 & 11 (Large Fit)', '19 Pairs • ₹ 45,000.00 (3.8%)'),
      ],
    );
  }

  // 8. Color-wise Sales Report
  Widget _buildColorSalesReport() {
    return _reportScaffold(
      '8. Color-Wise Footwear Sales Report',
      'Customer color preference distribution across all footwear models.',
      [
        _metricTile('Pure White', '39.2% Share', Icons.palette, Colors.grey.shade700),
        _metricTile('Core Black', '33.9% Share', Icons.palette, Colors.black),
        _metricTile('Oxford Tan', '13.7% Share', Icons.palette, Colors.brown),
        _metricTile('Navy Blue', '8.9% Share', Icons.palette, Colors.blue),
      ],
      [
        _rowItem('Pure White / Wolf Grey', '194 Pairs (39.2% Share)', isHighlight: true),
        _rowItem('Core Black / Triple Black', '168 Pairs (33.9% Share)'),
        _rowItem('Oxford Tan / Brown Leather', '68 Pairs (13.7% Share)'),
        _rowItem('Navy Blue / White Accents', '44 Pairs (8.9% Share)'),
        _rowItem('Olive Khaki / Camouflage', '21 Pairs (4.3% Share)'),
      ],
    );
  }

  // 9. Cashier-wise Sales Report
  Widget _buildCashierSalesReport() {
    return _reportScaffold(
      '9. Cashier & Terminal Sales Report',
      'Turnover, collection accuracy, and invoices billed by each cashier shift.',
      [
        _metricTile('Top Cashier', 'Anita Deshmukh', Icons.badge, Colors.green),
        _metricTile('Terminal 1 Total', '₹ 1,48,920', Icons.point_of_sale, const Color(0xFF4F46E5)),
        _metricTile('Invoices Billed', '54 Bills', Icons.receipt, Colors.teal),
        _metricTile('Cash Discrepancy', '₹ 0.00 (Matched)', Icons.check_circle, Colors.green),
      ],
      [
        _rowItem('Anita Deshmukh (Counter 1)', '₹ 1,48,920.00 (54 Invoices • 8.5 Shift Hours)', isHighlight: true),
        _rowItem('Sunil Patil (Counter 2)', '₹ 98,450.00 (38 Invoices • 7.0 Shift Hours)'),
      ],
    );
  }

  // 10. Purchase Report
  Widget _buildPurchaseReport() {
    return _reportScaffold(
      '10. Purchase & Procurement Summary Report',
      'Wholesale purchase orders, goods receipt notes (GRN), and input tax credits.',
      [
        _metricTile('Purchases (Month)', '₹ 2,85,400', Icons.shopping_bag, const Color(0xFF4F46E5)),
        _metricTile('Consignments', '48 Shipments', Icons.local_shipping, Colors.teal),
        _metricTile('Pairs Received', '580 Pairs', Icons.snowshoeing, Colors.green),
        _metricTile('Claimable ITC', '₹ 34,248', Icons.receipt_long, Colors.indigo),
      ],
      [
        _rowItem('Nike India Wholesale Shipments', '₹ 1,42,000.00 (180 Pairs)', isHighlight: true),
        _rowItem('Metro Leather Goods Consignments', '₹ 85,400.00 (140 Pairs)'),
        _rowItem('Crocs Regional Logistics', '₹ 58,000.00 (95 Pairs)'),
      ],
    );
  }

  // 11. Supplier Report
  Widget _buildSupplierReport() {
    return _reportScaffold(
      '11. Supplier Master & Vendor Report',
      'Wholesale supplier delivery fulfillment rates, return ratios, and balances.',
      [
        _metricTile('Active Suppliers', '14 Vendors', Icons.business, const Color(0xFF4F46E5)),
        _metricTile('Fulfillment Rate', '98.5%', Icons.check, Colors.green),
        _metricTile('Return Ratio', '0.8%', Icons.replay, Colors.orange),
        _metricTile('Total Billed', '₹ 2,85,400', Icons.payments, Colors.teal),
      ],
      [
        _rowItem('Nike India Wholesale Ltd. (Fulfillment: 100%)', 'Billed: ₹ 1,42,000.00 • Due: ₹ 0.00', isHighlight: true),
        _rowItem('Metro Leather Goods Traders (Fulfillment: 96%)', 'Billed: ₹ 85,400.00 • Due: ₹ 45,000.00'),
        _rowItem('Crocs Regional Distributor (Fulfillment: 100%)', 'Billed: ₹ 58,000.00 • Due: ₹ 0.00'),
      ],
    );
  }

  // 12. Customer Report
  Widget _buildCustomerReport() {
    return _reportScaffold(
      '12. Customer & Loyalty Analytics Report',
      'Registered customers, repeat purchase frequency, and loyalty points utilization.',
      [
        _metricTile('Registered Profiles', '1,240 Buyers', Icons.people, const Color(0xFF4F46E5)),
        _metricTile('Repeat Buyers', '68.5%', Icons.repeat, Colors.green),
        _metricTile('Active Walk-ins', '428 This Month', Icons.directions_walk, Colors.teal),
        _metricTile('Points Redeemed', '18,200 Pts', Icons.stars, Colors.amber.shade900),
      ],
      [
        _rowItem('VIP Gold Tier Buyers (>₹ 20,000 Spend)', '84 Customers (Contributing 28% Sales)', isHighlight: true),
        _rowItem('Silver Tier Buyers (₹ 5,000 - ₹ 20,000 Spend)', '342 Customers'),
        _rowItem('Welcome Bonus New Members (50 Pts Awarded)', '140 Registrations'),
      ],
    );
  }

  // 13. Stock Report
  Widget _buildStockReport() {
    return _reportScaffold(
      '13. Comprehensive Footwear Stock Ledger',
      'Consolidated inventory pairs and monetary valuation across all 4 outlets.',
      [
        _metricTile('Total Valuation', '₹ 18,50,000', Icons.inventory, Colors.green),
        _metricTile('Total Pairs', '4,280 Pairs', Icons.snowshoeing, const Color(0xFF4F46E5)),
        _metricTile('Flagship Pairs', '1,450 Pairs', Icons.store, Colors.teal),
        _metricTile('Warehouse Hub', '820 Pairs', Icons.warehouse, Colors.indigo),
      ],
      [
        _rowItem('Pune Central Flagship (MG Road)', '1,450 Pairs • Valuation: ₹ 6,85,000.00', isHighlight: true),
        _rowItem('Mumbai Suburban Outlet (Bandra)', '1,120 Pairs • Valuation: ₹ 4,95,000.00'),
        _rowItem('Nashik City Center Outlet', '890 Pairs • Valuation: ₹ 3,75,000.00'),
        _rowItem('Central Logistics Hub (Chakan)', '820 Pairs • Valuation: ₹ 2,95,000.00'),
      ],
    );
  }

  // 14. Low Stock Report
  Widget _buildLowStockReport() {
    return _reportScaffold(
      '14. Low Stock & Out-of-Stock Alert Report',
      'Footwear variants with shelf stock at or below the minimum threshold (5 pairs).',
      [
        _metricTile('Critical Out of Stock', '1 Model', Icons.error, Colors.red),
        _metricTile('Low Stock Warning', '2 Models', Icons.warning, Colors.orange),
        _metricTile('Safety Threshold', '5 Pairs', Icons.shield, const Color(0xFF4F46E5)),
        _metricTile('Reorder Status', 'PO Drafted', Icons.pending_actions, Colors.teal),
      ],
      [
        _rowItem('Woodland High Ankle Trekker (UK 8)', '0 Pairs in Stock (CRITICAL OUT)', isHighlight: true, color: Colors.red),
        _rowItem('Puma Smash V2 Leather (UK 7)', '2 Pairs in Stock (Threshold: 5)', color: Colors.orange),
        _rowItem('Campus Oxyfit Walking (UK 9)', '3 Pairs in Stock (Threshold: 6)', color: Colors.orange),
      ],
    );
  }

  // 15. Damaged Stock Report
  Widget _buildDamagedStockReport() {
    return _reportScaffold(
      '15. Damaged Footwear & Write-Off Report',
      'Defective footwear consignments, factory warranty claims, and scrap write-offs.',
      [
        _metricTile('Damaged Pairs', '6 Pairs', Icons.broken_image, Colors.red),
        _metricTile('Debit Notes Issued', '₹ 14,200', Icons.receipt_long, Colors.green),
        _metricTile('Vendor Approved', '4 Pairs', Icons.check_circle, Colors.teal),
        _metricTile('Loss Percentage', '0.14%', Icons.pie_chart, Colors.grey),
      ],
      [
        _rowItem('Bata Formal Derby (UK 9) - Sole delamination', 'Debit Note Settled: ₹ 2,499.00', isHighlight: true),
        _rowItem('Nike Air Max 270 (UK 8) - Air cushion puncture', 'Vendor Claim Approved: ₹ 8,995.00'),
        _rowItem('Crocs Classic Clog (UK 7) - Broken strap', 'Scrap Write-Off: ₹ 2,799.00'),
      ],
    );
  }

  // 16. Sales Return Report
  Widget _buildSalesReturnReport() {
    return _reportScaffold(
      '16. Footwear Sales Returns Report',
      'Audit customer returns within 7-day guarantee, refund methods, and root causes.',
      [
        _metricTile('Total Returns', '8 Pairs', Icons.assignment_return, Colors.orange),
        _metricTile('Total Refunded', '₹ 14,200', Icons.currency_rupee, const Color(0xFF4F46E5)),
        _metricTile('Return Ratio', '1.8%', Icons.trending_down, Colors.green),
        _metricTile('Primary Reason', 'Size Fit (75%)', Icons.straighten, Colors.teal),
      ],
      [
        _rowItem('Size Too Small / Large', '6 Pairs (75% of Returns)', isHighlight: true),
        _rowItem('Color Not Matching Customer Preference', '1 Pair (12.5% of Returns)'),
        _rowItem('Minor Manufacturing Defect', '1 Pair (12.5% of Returns)'),
      ],
    );
  }

  // 17. Exchange Report
  Widget _buildExchangeReport() {
    return _reportScaffold(
      '17. Size & Color Footwear Exchange Report',
      'Customer exchange fulfillment log retaining 94.4% of potential sales returns.',
      [
        _metricTile('Total Exchanges', '18 Pairs', Icons.swap_horiz, Colors.teal),
        _metricTile('Size Swaps', '14 Pairs', Icons.straighten, const Color(0xFF4F46E5)),
        _metricTile('Color Swaps', '4 Pairs', Icons.palette, Colors.indigo),
        _metricTile('Sale Retention', '94.4%', Icons.thumb_up, Colors.green),
      ],
      [
        _rowItem('Nike Air Max 270 UK 8 → Swapped to UK 9', 'Completed & Satisfied', isHighlight: true),
        _rowItem('Puma Smash V2 Black → Swapped to Navy Blue', 'Completed & Satisfied'),
        _rowItem('Bata Formal Derby UK 9 → Swapped to UK 10', 'Completed & Satisfied'),
      ],
    );
  }

  // 18. GST Report (GSTR-3B)
  Widget _buildGstReport() {
    return _reportScaffold(
      '18. GST Tax Compliance & GSTR-3B Report (HSN 6404)',
      'Automated footwear tax ledger: CGST 6%, SGST 6%, Input Tax Credit (ITC), and net payable.',
      [
        _metricTile('Taxable Turnover', '₹ 1,32,965', Icons.calculate, const Color(0xFF4F46E5)),
        _metricTile('Total Output GST', '₹ 15,955', Icons.receipt, Colors.teal),
        _metricTile('Input Tax Credit (ITC)', '₹ 34,248', Icons.input, Colors.green),
        _metricTile('Net Tax Payable', '₹ 0.00 (Covered by ITC)', Icons.verified, Colors.green),
      ],
      [
        _rowItem('CGST 6% Collected on Counter Sales', '₹ 7,977.50'),
        _rowItem('SGST 6% Collected on Counter Sales', '₹ 7,977.50'),
        _rowItem('Purchases Input Tax Credit (ITC Available)', '₹ 34,248.00 (Carried Forward)', isHighlight: true),
      ],
    );
  }

  // 19. Expense Report
  Widget _buildExpenseReport() {
    return _reportScaffold(
      '19. Store Operating Expenses Audit Report',
      'Categorized operating costs including showroom lease, electricity, and custom packaging.',
      [
        _metricTile('Total Expenses', '₹ 48,720', Icons.account_balance_wallet, Colors.orange),
        _metricTile('Showroom Rent', '₹ 32,000', Icons.home_work, Colors.blue),
        _metricTile('Electricity & AC', '₹ 6,450', Icons.bolt, Colors.amber.shade900),
        _metricTile('Packaging & Bags', '₹ 4,200', Icons.inventory, Colors.teal),
      ],
      [
        _rowItem('MG Road Flagship Showroom Lease', '₹ 32,000.00 (Paid via Bank Transfer)', isHighlight: true),
        _rowItem('MSEB Electricity Power (Air Conditioning)', '₹ 6,450.00 (Paid Online)'),
        _rowItem('Custom Shoe Boxes & Branded Bags', '₹ 4,200.00 (Paid Cash)'),
        _rowItem('Courier Logistics & Local Porter', '₹ 4,220.00'),
        _rowItem('Showroom Staff Tea & Hospitality', '₹ 1,850.00'),
      ],
    );
  }

  // 20. Profit and Loss Report
  Widget _buildProfitAndLossReport() {
    return _reportScaffold(
      '20. Consolidated Profit & Loss Statement (P&L)',
      'Gross trading profit, wholesale purchase costs, and net realized profitability.',
      [
        _metricTile('Gross Revenue', '₹ 4,58,920', Icons.trending_up, Colors.green),
        _metricTile('Wholesale COGS', '₹ 2,85,400', Icons.shopping_bag, const Color(0xFF4F46E5)),
        _metricTile('Gross Margin', '37.8%', Icons.pie_chart, Colors.teal),
        _metricTile('Net Operating Profit', '₹ 1,24,800 (27.2%)', Icons.savings, Colors.indigo),
      ],
      [
        _rowItem('Total Sales Revenue Realized', '₹ 4,58,920.00', isHighlight: true),
        _rowItem('Less: Cost of Footwear Goods Sold (COGS)', '-₹ 2,85,400.00'),
        _rowItem('Gross Profit', '₹ 1,73,520.00 (37.8% Gross Margin)'),
        _rowItem('Less: Operating Expenses & Staff Payroll', '-₹ 48,720.00'),
        _rowItem('Net Operating Profit Realized', '₹ 1,24,800.00 (27.2% Net Margin)', isHighlight: true),
      ],
    );
  }

  // 21. Customer Outstanding Report
  Widget _buildCustomerOutstandingReport() {
    return _reportScaffold(
      '21. Customer Credit & Outstanding Ledger Report',
      'Track unpaid store credit issued to regular customers with credit aging.',
      [
        _metricTile('Total Outstanding Due', '₹ 14,800', Icons.pending_actions, Colors.red),
        _metricTile('Customers with Dues', '4 Accounts', Icons.people, Colors.orange),
        _metricTile('Overdue (>15 Days)', '1 Customer', Icons.warning, Colors.red),
        _metricTile('Recovery Rate', '92.4%', Icons.check_circle, Colors.green),
      ],
      [
        _rowItem('Amit Saxena (+91 94230 11998)', '₹ 3,450.00 Due (15 Days Overdue)', isHighlight: true, color: Colors.red),
        _rowItem('Pooja Verma (+91 98221 55443)', '₹ 1,800.00 Due (8 Days Old)'),
        _rowItem('Karan Mehra (+91 99887 76655)', '₹ 2,200.00 Due (12 Days Old)'),
      ],
    );
  }

  // 22. Supplier Outstanding Report
  Widget _buildSupplierOutstandingReport() {
    return _reportScaffold(
      '22. Supplier Payables & Outstanding Dues Report',
      'Manufacturer credit terms, pending invoices, and upcoming RTGS/NEFT disbursements.',
      [
        _metricTile('Total Supplier Dues', '₹ 45,000', Icons.payment, Colors.red),
        _metricTile('Due in 2 Days', '₹ 45,000', Icons.schedule, Colors.orange),
        _metricTile('Cleared This Month', '₹ 2,40,400', Icons.done_all, Colors.green),
        _metricTile('Active Credit Vendors', '1 Vendor', Icons.business, const Color(0xFF4F46E5)),
      ],
      [
        _rowItem('Metro Leather Goods Traders (Inv: #METRO-881)', '₹ 45,000.00 Due on 14 Nov 2026', isHighlight: true, color: Colors.red),
        _rowItem('Nike India Wholesale Ltd. (Inv: #NIKE-442)', '₹ 0.00 Due (All Settled via RTGS)', color: Colors.green),
        _rowItem('Crocs Regional Distributor (Inv: #CROCS-211)', '₹ 0.00 Due (All Settled via NEFT)', color: Colors.green),
      ],
    );
  }

  // 23. Employee Performance Report
  Widget _buildEmployeePerformanceReport() {
    return _reportScaffold(
      '23. Employee Performance & Sales Incentive Report',
      'Staff sales targets, conversion ratios, monthly achievements, and 2.5% commission earned.',
      [
        _metricTile('Top Performer', 'Rahul Joshi (Gold)', Icons.military_tech, Colors.amber.shade900),
        _metricTile('Total Comm Earned', '₹ 7,002.50', Icons.monetization_on, Colors.green),
        _metricTile('Floor Conversion', '64.5%', Icons.trending_up, const Color(0xFF4F46E5)),
        _metricTile('Target Attainment', '76.3%', Icons.track_changes, Colors.teal),
      ],
      [
        _rowItem('1. Rahul Joshi (Sales Executive)', '₹ 1,14,500 Sales (76.3% Target) • ₹ 2,862.50 Comm • Gold Tier', isHighlight: true),
        _rowItem('2. Vikas Kulkarni (Floor Assistant)', '₹ 89,400 Sales (74.5% Target) • ₹ 2,235.00 Comm • Silver Tier'),
        _rowItem('3. Priya Nair (Sales Executive)', '₹ 76,200 Sales (63.5% Target) • ₹ 1,905.00 Comm • Bronze Tier'),
      ],
    );
  }

  // Scaffold Helper
  Widget _reportScaffold(String title, String desc, List<Widget> metrics, List<Widget> items) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
                    const SizedBox(height: 4),
                    Text(desc, style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                  ],
                ),
              ),
              Row(
                children: [
                  OutlinedButton.icon(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Exporting $title to Excel... Downloaded.')));
                    },
                    icon: const Icon(Icons.table_view, size: 14),
                    label: const Text('Export Excel', style: TextStyle(fontSize: 11)),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton.icon(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Exporting $title to PDF... Downloaded.')));
                    },
                    icon: const Icon(Icons.picture_as_pdf, size: 14),
                    label: const Text('Download PDF', style: TextStyle(fontSize: 11)),
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                  ),
                ],
              )
            ],
          ),
          const SizedBox(height: 16),
          LayoutBuilder(
            builder: (context, constraints) {
              final count = widget.isDesktop ? 4 : 2;
              return GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: count,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: widget.isDesktop ? 2.1 : 1.5,
                children: metrics,
              );
            },
          ),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Detailed Data Breakdown', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  const Divider(height: 20),
                  ...items,
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _metricTile(String title, String val, IconData icon, Color col) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade200)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(child: Text(title, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey.shade600, fontSize: 11, fontWeight: FontWeight.bold))),
              CircleAvatar(backgroundColor: col.withValues(alpha: 0.12), radius: 14, child: Icon(icon, color: col, size: 16)),
            ],
          ),
          Text(val, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          Text('Updated Just Now', style: TextStyle(fontSize: 9, color: Colors.grey.shade500)),
        ],
      ),
    );
  }

  Widget _rowItem(String label, String value, {bool isHighlight = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontWeight: isHighlight ? FontWeight.bold : FontWeight.w500, fontSize: 12)),
          Text(value, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: color ?? (isHighlight ? const Color(0xFF4F46E5) : Colors.black87))),
        ],
      ),
    );
  }
}

