import 'package:flutter/material.dart';

class StaffAppView extends StatefulWidget {
  final bool isDesktop;

  const StaffAppView({super.key, required this.isDesktop});

  @override
  State<StaffAppView> createState() => _StaffAppViewState();
}

class _StaffAppViewState extends State<StaffAppView> {
  int _activeTab = 0;

  final List<String> _tabs = [
    'Staff Shift & Login',
    'Product Search',
    'Barcode Scanner',
    'Stock Checking',
    'POS Billing Counter',
    'Customer Registration',
    'Invoice Generation',
    'Sales History',
  ];

  // Barcode Scanning State
  String _scannedBarcode = '8901234567890';
  Map<String, dynamic>? _scannedProduct = {
    'name': 'Nike Air Max 270 Flyknit',
    'sku': 'NK-AM270-WHT-9',
    'barcode': '8901234567890',
    'size': 'UK 9',
    'color': 'Pure White',
    'price': 8995.0,
    'stock': 6,
  };

  // Fast POS Cart State
  final List<Map<String, dynamic>> _posCart = [
    {
      'name': 'Nike Air Max 270 Flyknit',
      'spec': 'UK 9 • Pure White',
      'price': 8995.0,
      'qty': 1,
    },
    {
      'name': 'Shoe Care Waterproofer Nano Spray',
      'spec': '250ml Care Can',
      'price': 499.0,
      'qty': 1,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Tab Header Bar
        Container(
          height: 48,
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
          ),
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            itemCount: _tabs.length,
            itemBuilder: (context, idx) {
              final isSel = _activeTab == idx;
              return Padding(
                padding: const EdgeInsets.only(right: 6),
                child: FilterChip(
                  label: Text('${idx + 1}. ${_tabs[idx]}',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: isSel ? FontWeight.bold : FontWeight.w500,
                        color: isSel ? Colors.white : Colors.black87,
                      )),
                  selected: isSel,
                  selectedColor: const Color(0xFF4F46E5),
                  backgroundColor: const Color(0xFFF8FAFC),
                  showCheckmark: false,
                  onSelected: (_) => setState(() => _activeTab = idx),
                ),
              );
            },
          ),
        ),

        // Body Content
        Expanded(
          child: _buildTabBody(),
        ),
      ],
    );
  }

  Widget _buildTabBody() {
    switch (_activeTab) {
      case 0:
        return _buildStaffLoginAndShift();
      case 1:
        return _buildProductSearch();
      case 2:
        return _buildBarcodeScanner();
      case 3:
        return _buildStockChecking();
      case 4:
        return _buildPosBilling();
      case 5:
        return _buildCustomerRegistration();
      case 6:
        return _buildInvoiceGeneration();
      case 7:
        return _buildSalesHistory();
      default:
        return _buildStaffLoginAndShift();
    }
  }

  // 1. Staff Login & Shift
  Widget _buildStaffLoginAndShift() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Staff Shift & Counter Terminal', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Logged in staff terminal session, active cash float, and shift turnover status', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: [
                      const CircleAvatar(
                        radius: 24,
                        backgroundColor: Color(0xFFEEF2FF),
                        child: Icon(Icons.badge, color: Color(0xFF4F46E5), size: 28),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Active Cashier: Anita Deshmukh (Staff ID: #STF-104)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                            Text('Terminal: Counter 1 • Branch: Pune Central Flagship • Role: Head Cashier', style: TextStyle(color: Colors.grey, fontSize: 11)),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(color: Colors.green.shade50, borderRadius: BorderRadius.circular(6)),
                        child: const Text('SHIFT ACTIVE', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 11)),
                      ),
                    ],
                  ),
                  const Divider(height: 24),
                  _infoRow('Shift Started At', '12 Nov 2026, 09:30 AM'),
                  _infoRow('Opening Cash Drawer Float', '₹ 5,000.00'),
                  _infoRow('Cash Collected in Shift', '₹ 37,230.00'),
                  _infoRow('UPI / Digital Collected', '₹ 96,798.00'),
                  _infoRow('Total Bills Generated', '54 Invoices'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // 2. Product Search
  Widget _buildProductSearch() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Instant Footwear Catalog Search', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Quick lookup by brand, article code, shoe size, or color for floor assistance', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                decoration: const InputDecoration(
                  hintText: 'Search shoes (e.g. Nike Air Max, Bata Derby, UK 9, White)...',
                  prefixIcon: Icon(Icons.search, size: 20, color: Colors.grey),
                  border: InputBorder.none,
                ),
                onChanged: (_) {},
              ),
            ),
          ),
          const SizedBox(height: 12),
          _shoeItemTile('Nike Air Max 270 Flyknit', 'Sneakers • UK 7, 8, 9, 10 • Pure White', '₹ 8,995', '6 in stock', Colors.green),
          _shoeItemTile('Adidas Ultraboost Light', 'Running • UK 8, 9, 10 • Core Black', '₹ 9,499', '8 in stock', Colors.green),
          _shoeItemTile('Puma Smash V2 Leather', 'Casual • UK 7, 8 • Navy Blue', '₹ 2,799', '2 left (Low)', Colors.orange),
          _shoeItemTile('Bata Formal Derby Classic', 'Formal • UK 7, 8, 9, 10 • Oxford Tan', '₹ 2,499', '18 in stock', Colors.green),
          _shoeItemTile('Woodland Waterproof Trekker', 'Outdoor • UK 8, 9 • Khaki', '₹ 4,695', 'OUT OF STOCK', Colors.red),
        ],
      ),
    );
  }

  // 3. Barcode Scanning
  Widget _buildBarcodeScanner() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Laser Barcode Scanning Simulator', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Instant EAN-13 / Code-128 barcode recognition with automated size/color variant resolution', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),

          // Scanner Simulator Box
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFF0F172A),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                const Icon(Icons.qr_code_scanner, color: Colors.cyanAccent, size: 54),
                const SizedBox(height: 12),
                const Text('BARCODE SCANNER READY', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1.2)),
                const Text('Position shoe box barcode under laser beam', style: TextStyle(color: Colors.white60, fontSize: 11)),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _barcodeButton('Scan Nike Air Max (UK 9)', '8901234567890', 'NK-AM270-WHT-9', 8995.0, 'Pure White', 'UK 9'),
                    const SizedBox(width: 8),
                    _barcodeButton('Scan Adidas Boost (UK 8)', '8901234567891', 'AD-UBL-BLK-8', 9499.0, 'Core Black', 'UK 8'),
                    const SizedBox(width: 8),
                    _barcodeButton('Scan Bata Derby (UK 10)', '8901234567892', 'BT-FRM-TAN-10', 2499.0, 'Oxford Tan', 'UK 10'),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Scanned Result Card
          if (_scannedProduct != null)
            Card(
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Matched: ${_scannedProduct!['name']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(color: Colors.green.shade50, borderRadius: BorderRadius.circular(4)),
                          child: const Text('SCANNED', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 10)),
                        )
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text('Barcode: $_scannedBarcode • SKU: ${_scannedProduct!['sku']}', style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.grey)),
                    const SizedBox(height: 4),
                    Text('Shoe Size: ${_scannedProduct!['size']} • Color: ${_scannedProduct!['color']} • Shelf Stock: ${_scannedProduct!['stock']} pairs',
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('₹ ${_scannedProduct!['price'].toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF4F46E5))),
                        ElevatedButton.icon(
                          onPressed: () {
                            setState(() {
                              _posCart.add({
                                'name': _scannedProduct!['name'],
                                'spec': '${_scannedProduct!['size']} • ${_scannedProduct!['color']}',
                                'price': _scannedProduct!['price'],
                                'qty': 1,
                              });
                            });
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Added ${_scannedProduct!['name']} to POS cart!')));
                          },
                          icon: const Icon(Icons.add_shopping_cart, size: 14),
                          label: const Text('Add to POS Cart'),
                          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                        )
                      ],
                    )
                  ],
                ),
              ),
            )
        ],
      ),
    );
  }

  Widget _barcodeButton(String label, String barcode, String sku, double price, String color, String size) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(backgroundColor: Colors.white24, foregroundColor: Colors.white),
      onPressed: () {
        setState(() {
          _scannedBarcode = barcode;
          _scannedProduct = {
            'name': label.replaceAll('Scan ', ''),
            'sku': sku,
            'barcode': barcode,
            'size': size,
            'color': color,
            'price': price,
            'stock': 8,
          };
        });
      },
      child: Text(label, style: const TextStyle(fontSize: 10)),
    );
  }

  // 4. Stock Checking
  Widget _buildStockChecking() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Real-Time Stock Checking Matrix', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Look up exact shoe size and color availability in store racks and back-room storage', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Nike Air Max 270 (Pure White) - Size Breakdown', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 12),
                  _stockGridItem('UK 6', '0 Pairs', false),
                  _stockGridItem('UK 7', '4 Pairs', true),
                  _stockGridItem('UK 8', '8 Pairs', true),
                  _stockGridItem('UK 9', '6 Pairs', true),
                  _stockGridItem('UK 10', '2 Pairs (Low)', true, isLow: true),
                  _stockGridItem('UK 11', '0 Pairs', false),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _stockGridItem(String size, String stock, bool inStock, {bool isLow = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('Shoe Size: $size', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: inStock ? (isLow ? Colors.orange.shade50 : Colors.green.shade50) : Colors.red.shade50,
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              stock,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 11,
                color: inStock ? (isLow ? Colors.orange.shade800 : Colors.green.shade800) : Colors.red.shade800,
              ),
            ),
          )
        ],
      ),
    );
  }

  // 5. POS Billing
  Widget _buildPosBilling() {
    double subtotal = 0.0;
    for (var item in _posCart) {
      subtotal += (item['price'] as double) * (item['qty'] as int);
    }
    final gst = subtotal * 0.12;
    final grandTotal = subtotal + gst;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Counter POS Billing & Fast Checkout', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Scan items, enter customer mobile, apply floor discount, and collect payment', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Cart Items (Counter 1)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                      TextButton(onPressed: () => setState(() => _posCart.clear()), child: const Text('Clear', style: TextStyle(color: Colors.red))),
                    ],
                  ),
                  const Divider(),
                  ..._posCart.map((i) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(i['name'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                                Text(i['spec'], style: const TextStyle(fontSize: 10, color: Colors.grey)),
                              ],
                            ),
                            Text('₹ ${(i['price'] as double).toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF4F46E5))),
                          ],
                        ),
                      )),
                  const Divider(height: 20),
                  // AI Smart Cross-Sell & Footwear Stylist Widget
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [const Color(0xFF4F46E5).withValues(alpha: 0.08), const Color(0xFF7C3AED).withValues(alpha: 0.04)],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFF4F46E5).withValues(alpha: 0.25)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(color: const Color(0xFF4F46E5).withValues(alpha: 0.15), borderRadius: BorderRadius.circular(8)),
                              child: const Icon(Icons.auto_awesome, color: Color(0xFF4F46E5), size: 16),
                            ),
                            const SizedBox(width: 8),
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('AI SMART CROSS-SELL & FOOTWEAR STYLIST', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: Color(0xFF4F46E5), letterSpacing: 0.6)),
                                  Text('Recommended bundles for customer shopping cart (+28% Basket Size):', style: TextStyle(fontSize: 10, color: Colors.grey)),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        // Cross sell bundle options
                        _aiCrossSellAddonRow(
                          'Sneaker Shield Anti-Crease Guards',
                          '₹ 299',
                          'MRP ₹ 399 (Save 25%)',
                          'Prevents front toe wrinkles & keeps shoes new',
                          () {
                            setState(() {
                              _posCart.add({'name': 'Sneaker Shield Anti-Crease Guards', 'spec': 'Universal Fit • Pair', 'price': 299.0, 'qty': 1});
                            });
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Added Sneaker Shield Anti-Crease Guards to Cart!')));
                          },
                        ),
                        const SizedBox(height: 6),
                        _aiCrossSellAddonRow(
                          'Nano Waterproof Protect Spray (200ml)',
                          '₹ 499',
                          'MRP ₹ 699 (Save 28%)',
                          'Instant stain & rain repelling protective shield',
                          () {
                            setState(() {
                              _posCart.add({'name': 'Nano Waterproof Protect Spray (200ml)', 'spec': '200ml Aerosol Can', 'price': 499.0, 'qty': 1});
                            });
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Added Nano Waterproof Protect Spray to Cart!')));
                          },
                        ),
                      ],
                    ),
                  ),
                  _infoRow('Subtotal', '₹ ${subtotal.toStringAsFixed(0)}'),
                  _infoRow('GST on Footwear (12%)', '₹ ${gst.toStringAsFixed(0)}'),
                  const Divider(),
                  _infoRow('Grand Total to Collect', '₹ ${grandTotal.toStringAsFixed(0)}', isBold: true),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF25D366),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                          onPressed: () {
                            _showWhatsAppDigitalBillAndPassDialog(context, grandTotal);
                          },
                          icon: const Icon(Icons.send_rounded, size: 16),
                          label: const Text('Checkout & Send WhatsApp Bill + 7-Day Pass', style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  void _showWhatsAppDigitalBillAndPassDialog(BuildContext context, double total) {
    final invNum = 'KF-INV-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
    final passCode = 'KF-EXCH-202611-${(100000 + DateTime.now().millisecond * 89).clamp(100000, 999999)}';
    final expiryDate = DateTime.now().add(const Duration(days: 7));
    final expiryFormatted = '${expiryDate.day.toString().padLeft(2, '0')}-Nov-${expiryDate.year}';

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: const Color(0xFF25D366).withValues(alpha: 0.15), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.check_circle_outline, color: Color(0xFF25D366)),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Bill Created & Dispatched', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text('WhatsApp Digital Receipt + 7-Day Pass', style: TextStyle(fontSize: 11, color: Colors.grey)),
                ],
              ),
            )
          ],
        ),
        content: SizedBox(
          width: 380,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: const Color(0xFF25D366).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF25D366).withValues(alpha: 0.3))),
                child: Row(
                  children: [
                    const Icon(Icons.mark_chat_read_rounded, color: Color(0xFF25D366), size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'WhatsApp PDF Bill sent to +91 98921 55432 with 7-Day Barcode pass token.',
                        style: TextStyle(color: Colors.green.shade800, fontSize: 11, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              // Pass Card
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [const Color(0xFF4F46E5).withValues(alpha: 0.08), const Color(0xFF7C3AED).withValues(alpha: 0.04)],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF4F46E5).withValues(alpha: 0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('7-DAY EXCHANGE PASS', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: Color(0xFF4F46E5), letterSpacing: 0.8)),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(color: Colors.green.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(6)),
                          child: const Text('ACTIVE (7 DAYS LEFT)', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.green)),
                        )
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text('Pass Code: $passCode', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'monospace')),
                    const SizedBox(height: 4),
                    Text('Valid Until: $expiryFormatted • Valid for size/color swap with original shoebox', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                    const SizedBox(height: 8),
                    // Visual barcode representation
                    Container(
                      height: 32,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: List.generate(24, (i) => Container(
                          width: (i % 3 == 0) ? 3 : (i % 2 == 0 ? 2 : 1),
                          color: Colors.black87,
                        )),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Invoice: $invNum', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
                  Text('Amount: ₹ ${total.toStringAsFixed(0)}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF4F46E5))),
                ],
              )
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Thermal receipt printed & Customer digital card synced.')));
            },
            icon: const Icon(Icons.print, size: 14),
            label: const Text('Print 80mm Slip'),
          )
        ],
      ),
    );
  }

  // 6. Customer Registration
  Widget _buildCustomerRegistration() {
    final nameCtrl = TextEditingController();
    final mobileCtrl = TextEditingController();
    final sizeCtrl = TextEditingController(text: 'UK 9');

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Quick Customer Floor Registration', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Register walk-in customers in under 10 seconds to award 50 welcome loyalty reward points', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  TextField(controller: mobileCtrl, decoration: const InputDecoration(labelText: 'Customer Mobile Number *', prefixText: '+91 ')),
                  const SizedBox(height: 10),
                  TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Customer Full Name *')),
                  const SizedBox(height: 10),
                  TextField(controller: sizeCtrl, decoration: const InputDecoration(labelText: 'Foot Size Preference (e.g. UK 9)')),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white, minimumSize: const Size.fromHeight(42)),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Customer registered! 50 Welcome Loyalty Points added.')));
                    },
                    icon: const Icon(Icons.person_add, size: 16),
                    label: const Text('Register & Award 50 Points'),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // 7. Invoice Generation
  Widget _buildInvoiceGeneration() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('GST Tax Invoice & Thermal Slip Preview', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('80mm ESC/POS thermal receipt formatting with GSTIN, HSN 6404, barcode, and return policy', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Center(
            child: Container(
              width: 320,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey.shade300),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10)],
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('KHUSHI FOOTWEAR PVT. LTD.', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  Text('Pune Central Flagship, MG Road', style: TextStyle(fontSize: 10)),
                  Text('GSTIN: 27AABCK1234F1Z9', style: TextStyle(fontSize: 10)),
                  Divider(),
                  Text('TAX INVOICE: #KF-INV-88231', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
                  Text('Date: 12 Nov 2026 12:45 PM', style: TextStyle(fontSize: 10)),
                  Text('Cashier: Anita Deshmukh', style: TextStyle(fontSize: 10)),
                  Divider(),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Nike Air Max 270 (UK 9)', style: TextStyle(fontSize: 11)), Text('₹ 8,995.00', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold))]),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Care Protect Spray', style: TextStyle(fontSize: 11)), Text('₹ 499.00', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold))]),
                  Divider(),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('CGST 6% + SGST 6%', style: TextStyle(fontSize: 11)), Text('₹ 1,139.28', style: TextStyle(fontSize: 11))]),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('TOTAL PAID (UPI)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)), Text('₹ 10,633.00', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF4F46E5)))]),
                  Divider(),
                  Text('Exchanges valid within 7 days with shoebox.', style: TextStyle(fontSize: 9, color: Colors.grey)),
                  Text('Thank you for shopping at Khushi Footwear!', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // 8. Sales History
  Widget _buildSalesHistory() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Staff Daily Sales History & Completed Bills', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Audit today receipts generated by this terminal', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _historyRow('KF-INV-88231', 'Amit Saxena', 'Nike Air Max + Spray', '₹ 10,633', 'UPI', '12:45 PM'),
                  const Divider(),
                  _historyRow('KF-INV-88230', 'Pooja Verma', 'Puma Smash V2 (UK 6)', '₹ 2,799', 'CASH', '12:15 PM'),
                  const Divider(),
                  _historyRow('KF-INV-88229', 'Walk-in Customer', 'Bata Formal Derby (UK 10)', '₹ 2,499', 'CARD', '11:40 AM'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // Helper
  Widget _shoeItemTile(String name, String spec, String price, String stock, Color col) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10), side: BorderSide(color: Colors.grey.shade200)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                Text(spec, style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(price, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF4F46E5), fontSize: 13)),
                Text(stock, style: TextStyle(fontWeight: FontWeight.bold, color: col, fontSize: 10)),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _aiCrossSellAddonRow(String title, String price, String discountNote, String desc, VoidCallback onAdd) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                      decoration: BoxDecoration(color: Colors.green.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(4)),
                      child: Text(discountNote, style: const TextStyle(fontSize: 8, fontWeight: FontWeight.bold, color: Colors.green)),
                    ),
                  ],
                ),
                Text(desc, style: const TextStyle(fontSize: 9, color: Colors.grey)),
              ],
            ),
          ),
          Text(price, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF4F46E5))),
          const SizedBox(width: 8),
          InkWell(
            onTap: onAdd,
            borderRadius: BorderRadius.circular(6),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: const Color(0xFF4F46E5), borderRadius: BorderRadius.circular(6)),
              child: const Row(
                children: [
                  Icon(Icons.add, color: Colors.white, size: 12),
                  SizedBox(width: 2),
                  Text('Add', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 12, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
          Text(value, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.w600, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _historyRow(String inv, String cust, String item, String total, String mode, String time) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('$inv • $cust', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
            Text('$item • $time', style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
          ],
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(total, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF4F46E5), fontSize: 12)),
            Text(mode, style: const TextStyle(fontSize: 10, color: Colors.green, fontWeight: FontWeight.bold)),
          ],
        )
      ],
    );
  }
}

