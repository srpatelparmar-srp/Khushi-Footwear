import 'package:flutter/material.dart';

class AccountantView extends StatefulWidget {
  final bool isDesktop;
  final int activeModule;

  const AccountantView({
    super.key,
    required this.isDesktop,
    required this.activeModule,
  });

  @override
  State<AccountantView> createState() => _AccountantViewState();
}

class _AccountantViewState extends State<AccountantView> {
  @override
  Widget build(BuildContext context) {
    switch (widget.activeModule) {
      case 0:
        return _buildCashbookAndDailyIncome();
      case 1:
        return _buildExpensesModule();
      case 2:
        return _buildBankAndUpiReconciliation();
      case 3:
        return _buildCustomerAndSupplierOutstanding();
      case 4:
        return _buildGstRecordsModule();
      case 5:
        return _buildSalaryDisbursementsModule();
      case 6:
        return _buildProfitAndLossReports();
      default:
        return _buildCashbookAndDailyIncome();
    }
  }

  // 1. Daily Income & Cashbook
  Widget _buildCashbookAndDailyIncome() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Daily Cashbook & Counter Collections', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('Cash inflows, POS billings, petty cash disbursements & drawer settlements', style: TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
              ElevatedButton.icon(
                onPressed: () => _showAddVoucherDialog(),
                icon: const Icon(Icons.add_card, size: 16),
                label: const Text('Add Cash Voucher'),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
              )
            ],
          ),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Today POS Cash', '₹ 48,500', Icons.payments, Colors.green, '+18% vs yesterday'),
            _metricItem('Cash Inflows', '₹ 52,300', Icons.arrow_downward, Colors.teal, 'Vouchers credited'),
            _metricItem('Cash Outflows', '₹ 6,400', Icons.arrow_upward, Colors.redAccent, 'Petty expenses'),
            _metricItem('Net Cash In Hand', '₹ 94,400', Icons.account_balance_wallet, const Color(0xFF4F46E5), 'Drawer verified'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Recent Cashbook Vouchers', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _voucherRow('VCH-2026-001', 'POS Cash Sales Collection', 'INFLOW', '₹ 48,500', '12 Nov 2026', Colors.green),
                  _voucherRow('VCH-2026-002', 'Store Courier & Packaging Freight', 'OUTFLOW', '₹ 3,200', '12 Nov 2026', Colors.redAccent),
                  _voucherRow('VCH-2026-003', 'Shoe Polish Supplies Purchase', 'OUTFLOW', '₹ 1,450', '12 Nov 2026', Colors.redAccent),
                  _voucherRow('VCH-2026-004', 'Counter Advance Recovery (Staff)', 'INFLOW', '₹ 3,800', '11 Nov 2026', Colors.green),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // 2. Business Expenses Management
  Widget _buildExpensesModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Business Expenses & Overhead Ledger', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Track store utilities, electricity, packaging, marketing, and recurring operational costs', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Total Month Expense', '₹ 42,850', Icons.receipt_long, Colors.redAccent, '6 Categories'),
            _metricItem('Store Electricity & Rent', '₹ 28,000', Icons.store, Colors.orange, 'Fixed monthly'),
            _metricItem('Packaging & Boxes', '₹ 8,450', Icons.inventory, Colors.indigo, 'Poly bags & shoeboxes'),
            _metricItem('Staff Tea & Refreshment', '₹ 6,400', Icons.coffee, Colors.brown, 'Daily pantry'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Logged Expenses (November 2026)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _expenseRow('Main Showroom Rent', 'RENT', '₹ 22,000', 'NEFT - HDFC', '01 Nov 2026'),
                  _expenseRow('State Electricity Bill', 'UTILITY', '₹ 6,000', 'UPI Auto-debit', '04 Nov 2026'),
                  _expenseRow('Custom Branded Shoe Box Supply', 'PACKAGING', '₹ 8,450', 'Cheque 44102', '07 Nov 2026'),
                  _expenseRow('Staff Refreshments & Tea', 'PANTRY', '₹ 6,400', 'Cash', '11 Nov 2026'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // 3. Bank & UPI Transactions Reconciliation (BRS)
  Widget _buildBankAndUpiReconciliation() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Bank & UPI Payment Reconciliation (BRS)', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Daily UPI QR Code settlements, POS swipe machine batches, NEFT supplier vendor payouts', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('HDFC Current A/C', '₹ 3,42,800', Icons.account_balance, const Color(0xFF4F46E5), 'A/c: 50200012345678'),
            _metricItem('UPI Collections (Today)', '₹ 84,200', Icons.qr_code, Colors.teal, '38 transactions settled'),
            _metricItem('Swipe POS Machine', '₹ 31,500', Icons.credit_card, Colors.blue, 'Batch closed 11:30 PM'),
            _metricItem('Unreconciled BRS', '₹ 0.00', Icons.verified, Colors.green, '100% matched'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Payment Settlement Streams', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _bankRow('UPI-HDFC-991823', 'UPI QR Merchant Settlement', '₹ 84,200', 'RECONCILED', Colors.green),
                  _bankRow('POS-SWIPE-88129', 'PineLabs Credit Card Settlement', '₹ 31,500', 'RECONCILED', Colors.green),
                  _bankRow('NEFT-VEND-77341', 'Metro Leather Wholesaler Payout', '₹ 39,500', 'RECONCILED', Colors.blueGrey),
                  _bankRow('UPI-REFUND-1029', 'Customer Size Return Refund', '₹ 2,499', 'RECONCILED', Colors.orange),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // 4. Customer Outstanding & Supplier Outstanding
  Widget _buildCustomerAndSupplierOutstanding() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Credit & Outstanding Ledgers', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Accounts receivable (Customer Khata) & Accounts payable (Wholesale Supplier Dues)', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Customer Dues (Receivable)', '₹ 18,500', Icons.person_search, Colors.amber.shade900, '8 Khata Customers'),
            _metricItem('Supplier Dues (Payable)', '₹ 45,000', Icons.business_outlined, Colors.redAccent, '3 Footwear Mills'),
            _metricItem('Overdue > 30 Days', '₹ 4,200', Icons.warning_amber, Colors.deepOrange, 'Action required'),
            _metricItem('Net Working Capital', '+₹ 2,79,300', Icons.trending_up, Colors.green, 'Healthy liquidity'),
          ]),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Top Customer Receivables', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        const SizedBox(height: 8),
                        _outstandingRow('Rahul Sharma', '+91 98765 43210', '₹ 4,200', 'Due 18 Nov'),
                        _outstandingRow('Priya Patel', '+91 91234 56789', '₹ 6,500', 'Due 22 Nov'),
                        _outstandingRow('Amit Verma', '+91 97890 12345', '₹ 7,800', 'Due 28 Nov'),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Top Supplier Payables', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        const SizedBox(height: 8),
                        _outstandingRow('Metro Leather Mills', 'Agra, UP', '₹ 25,000', 'Due 20 Nov'),
                        _outstandingRow('Apex Sole Industries', 'Jalandhar, PB', '₹ 12,000', 'Due 25 Nov'),
                        _outstandingRow('Relaxo Wholesale Hub', 'Delhi', '₹ 8,000', 'Due 30 Nov'),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  // 5. GST Records & Tax Filing (GSTR-1 & GSTR-3B)
  Widget _buildGstRecordsModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('GST Records & GSTR-3B Tax Filing', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Output tax on footwear sales (5% / 12% slabs) vs Input Tax Credit (ITC) on supplier purchase invoices', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Total Output GST Collected', '₹ 46,248', Icons.receipt, const Color(0xFF4F46E5), 'From POS & Online sales'),
            _metricItem('Input Tax Credit (ITC)', '₹ 34,248', Icons.input, Colors.teal, 'From Vendor Tax Invoices'),
            _metricItem('Net GST Payable', '₹ 12,000', Icons.account_balance, Colors.orange, 'CGST 6K + SGST 6K'),
            _metricItem('Filing Due Date', '20 Nov 2026', Icons.event, Colors.indigo, 'Status: READY'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Footwear Slab Summary (Indian GST Structure)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _gstSlabRow('Shoes <= ₹1,000 (Budget / Daily)', '5% GST', '₹ 1,24,000', '₹ 6,200 GST'),
                  _gstSlabRow('Shoes > ₹1,000 (Sports / Leather)', '12% GST', '₹ 3,33,733', '₹ 40,048 GST'),
                  const Divider(),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Total Tax Liability Before ITC', style: TextStyle(fontWeight: FontWeight.bold)),
                      Text('₹ 46,248', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF4F46E5))),
                    ],
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // 6. Employee Salary Disbursements
  Widget _buildSalaryDisbursementsModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Employee Salary Disbursements & Payroll', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('Basic salary, sales commission payouts, attendance deductions & pay slip generation', style: TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
              ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.send_outlined, size: 16),
                label: const Text('Disburse Salaries'),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
              )
            ],
          ),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Total Monthly Payroll', '₹ 1,18,500', Icons.badge, const Color(0xFF4F46E5), '7 Store Staff'),
            _metricItem('Sales Commissions Paid', '₹ 14,250', Icons.trending_up, Colors.green, 'Based on target achievement'),
            _metricItem('Attendance Deductions', '₹ 2,400', Icons.schedule, Colors.redAccent, 'Unapproved leaves'),
            _metricItem('Disbursement Status', '100% PAID', Icons.verified, Colors.teal, 'Bank Direct Credit'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Payroll Breakdown (October 2026)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _salaryRow('Vikram Singh', 'Store Manager', '₹ 28,000', '₹ 2,500 Comm', '₹ 30,500 Paid'),
                  _salaryRow('Ramesh Cashier', 'Billing Staff', '₹ 18,000', '₹ 1,845 Comm', '₹ 19,845 Paid'),
                  _salaryRow('Suresh Inventory', 'Inventory Manager', '₹ 20,000', '₹ 0 Comm', '₹ 20,000 Paid'),
                  _salaryRow('Pooja Sales', 'Sales Executive', '₹ 15,000', '₹ 4,200 Comm', '₹ 19,200 Paid'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // 7. Profit & Loss Reports
  Widget _buildProfitAndLossReports() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Profit & Loss Financial Statement (P&L)', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Revenues, cost of footwear sold (COGS), operating expenses, payroll, and Net Operating Profit', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Gross Revenue', '₹ 5,82,400', Icons.insights, Colors.green, 'POS & Online Invoices'),
            _metricItem('Cost of Goods (COGS)', '₹ 2,85,400', Icons.shopping_cart, Colors.indigo, 'Purchase Cost of Sold Pairs'),
            _metricItem('Total Operating Expenses', '₹ 1,61,350', Icons.receipt, Colors.redAccent, 'Overheads + Payroll'),
            _metricItem('Net Operating Profit', '₹ 1,35,650', Icons.monetization_on, const Color(0xFF4F46E5), 'Net Margin: 23.3%'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Comprehensive Statement Breakdown', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _statementRow('Total Footwear Sales Revenue', '₹ 5,82,400', isBold: true, color: Colors.green),
                  _statementRow('Less: Wholesale Footwear Purchase Cost (COGS)', '-₹ 2,85,400', color: Colors.indigo),
                  const Divider(),
                  _statementRow('Gross Trading Profit', '₹ 2,97,000', isBold: true),
                  _statementRow('Less: Store Rent & Electricity', '-₹ 28,000', color: Colors.redAccent),
                  _statementRow('Less: Packaging & Stationery', '-₹ 8,450', color: Colors.redAccent),
                  _statementRow('Less: Staff Payroll & Sales Commissions', '-₹ 1,18,500', color: Colors.redAccent),
                  _statementRow('Less: Miscellaneous Operational Costs', '-₹ 6,400', color: Colors.redAccent),
                  const Divider(),
                  _statementRow('Net Net Operating Profit (EBITDA)', '₹ 1,35,650', isBold: true, color: const Color(0xFF4F46E5)),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // --- HELPERS ---
  Widget _buildMetricsGrid(List<Widget> items) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final crossCount = widget.isDesktop ? 4 : 2;
        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: crossCount,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: widget.isDesktop ? 2.1 : 1.5,
          children: items,
        );
      },
    );
  }

  Widget _metricItem(String title, String val, IconData icon, Color color, String sub) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade200)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(child: Text(title, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey.shade600, fontSize: 11, fontWeight: FontWeight.bold))),
              CircleAvatar(backgroundColor: color.withValues(alpha: 0.12), radius: 14, child: Icon(icon, color: color, size: 16)),
            ],
          ),
          Text(val, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          Text(sub, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, color: Colors.grey.shade500)),
        ],
      ),
    );
  }

  Widget _voucherRow(String vch, String desc, String type, String amount, String date, Color typeColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(color: typeColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)),
                child: Text(type, style: TextStyle(color: typeColor, fontSize: 10, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$vch - $desc', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                  Text(date, style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
                ],
              ),
            ],
          ),
          Text(amount, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: typeColor)),
        ],
      ),
    );
  }

  Widget _expenseRow(String title, String cat, String amt, String mode, String date) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text('$cat • $mode • $date', style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
            ],
          ),
          Text(amt, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.redAccent)),
        ],
      ),
    );
  }

  Widget _bankRow(String ref, String desc, String amt, String status, Color statusColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(ref, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text(desc, style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
            ],
          ),
          Row(
            children: [
              Text(amt, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)),
                child: Text(status, style: TextStyle(color: statusColor, fontSize: 10, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _outstandingRow(String name, String detail, String due, String remark) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text('$detail • $remark', style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
            ],
          ),
          Text(due, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.redAccent)),
        ],
      ),
    );
  }

  Widget _gstSlabRow(String slab, String rate, String taxable, String tax) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(slab, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text('Taxable Turnover: $taxable', style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(tax, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF4F46E5))),
              Text(rate, style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _salaryRow(String name, String role, String basic, String comm, String net) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text('$role • Basic: $basic • $comm', style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
            ],
          ),
          Text(net, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.green)),
        ],
      ),
    );
  }

  Widget _statementRow(String title, String amt, {bool isBold = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal, fontSize: 12)),
          Text(amt, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal, fontSize: 13, color: color)),
        ],
      ),
    );
  }

  void _showAddVoucherDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add Cashbook Voucher'),
        content: const Text('Record a cash receipt or petty cash payment with narration and counter verification.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cashbook Voucher saved successfully!')));
            },
            child: const Text('Save Voucher'),
          )
        ],
      ),
    );
  }
}
