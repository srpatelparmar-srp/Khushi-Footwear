import 'package:flutter/material.dart';

class OwnerAppView extends StatefulWidget {
  final bool isDesktop;

  const OwnerAppView({super.key, required this.isDesktop});

  @override
  State<OwnerAppView> createState() => _OwnerAppViewState();
}

class _OwnerAppViewState extends State<OwnerAppView> {
  int _activeTab = 0;

  final List<String> _tabs = [
    'Business Dashboard',
    'Daily & Monthly Sales',
    'Purchase Summary',
    'Profit & Loss',
    'Stock Alerts',
    'Employee Performance',
    'Branch-Wise Reports',
    'Expense Management',
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Tab Header Bar
        Container(
          height: 48,
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
          ),
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            itemCount: _tabs.length,
            itemBuilder: (context, idx) {
              final isSel = _activeTab == idx;
              return Padding(
                padding: const EdgeInsets.only(right: 6),
                child: FilterChip(
                  label: Text('${idx + 1}. ${_tabs[idx]}',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: isSel ? FontWeight.bold : FontWeight.w500,
                        color: isSel ? Colors.white : Colors.black87,
                      )),
                  selected: isSel,
                  selectedColor: const Color(0xFF4F46E5),
                  backgroundColor: const Color(0xFFF8FAFC),
                  showCheckmark: false,
                  onSelected: (_) => setState(() => _activeTab = idx),
                ),
              );
            },
          ),
        ),

        // Body Content
        Expanded(
          child: _buildTabBody(),
        ),
      ],
    );
  }

  Widget _buildTabBody() {
    switch (_activeTab) {
      case 0:
        return _buildBusinessDashboard();
      case 1:
        return _buildDailyAndMonthlySales();
      case 2:
        return _buildPurchaseSummary();
      case 3:
        return _buildProfitAndLoss();
      case 4:
        return _buildStockAlerts();
      case 5:
        return _buildEmployeePerformance();
      case 6:
        return _buildBranchWiseReports();
      case 7:
        return _buildExpenseManagement();
      default:
        return _buildBusinessDashboard();
    }
  }

  // 1. Business Dashboard
  Widget _buildBusinessDashboard() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Owner Executive Dashboard', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('High-level executive metrics across all 4 footwear retail branches & central warehouse', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricCard('Today Revenue', '₹ 1,48,920', Icons.currency_rupee, Colors.green, '+18% vs yesterday'),
            _metricCard('Monthly Revenue', '₹ 4,58,920', Icons.point_of_sale, const Color(0xFF4F46E5), 'Nov 2026 (12 Days)'),
            _metricCard('Gross Profit Margin', '₹ 1,73,520 (37.8%)', Icons.trending_up, Colors.teal, 'Above target 35%'),
            _metricCard('Net Profit Realized', '₹ 1,24,800 (27.2%)', Icons.savings, Colors.indigo, 'After rent & salaries'),
            _metricCard('Inventory Valuation', '₹ 18,50,000', Icons.inventory, Colors.amber.shade900, '4,280 Pairs across shops'),
            _metricCard('Operating Expenses', '₹ 48,720', Icons.receipt_long, Colors.orange, 'Rent, electricity, packaging'),
            _metricCard('Critical Stock Alerts', '2 Models', Icons.warning_amber, Colors.red, 'Action needed immediately'),
            _metricCard('Active Store Staff', '18 Employees', Icons.people, Colors.blue, '100% Floor coverage'),
          ]),
        ],
      ),
    );
  }

  // 2. Daily and Monthly Sales
  Widget _buildDailyAndMonthlySales() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Daily & Monthly Footwear Sales Breakdown', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Track sales trends, average ticket size, payment mode split, and fast-moving shoe sizes', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Payment Mode Split (Today: ₹ 1,48,920)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 12),
                  _progressRow('UPI (Google Pay, PhonePe, Paytm)', 0.65, '₹ 96,798 (65%)'),
                  _progressRow('Cash Collected at Counters', 0.25, '₹ 37,230 (25%)'),
                  _progressRow('Credit/Debit Cards (POS EDC)', 0.10, '₹ 14,892 (10%)'),
                  const Divider(height: 24),
                  const Text('Top Selling Footwear Sizes', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 8),
                  _progressRow('Size UK 8 (Standard Men)', 0.38, '38% of pairs sold'),
                  _progressRow('Size UK 9 (Athletic & Formal)', 0.32, '32% of pairs sold'),
                  _progressRow('Size UK 7 (Youth & Casual)', 0.20, '20% of pairs sold'),
                  _progressRow('Size UK 10 & 11 (Large Fit)', 0.10, '10% of pairs sold'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // 3. Purchase Summary
  Widget _buildPurchaseSummary() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Wholesale Footwear Procurement & Purchases', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Month-to-date consignments from Nike, Adidas, Puma, Bata & Woodland', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricCard('Monthly Purchases', '₹ 2,85,400', Icons.shopping_bag, const Color(0xFF4F46E5), '48 Consignments fulfilled'),
            _metricCard('Pairs Received', '580 Pairs', Icons.snowshoeing, Colors.teal, 'Across 4 brands'),
            _metricCard('Total Outstanding Due', '₹ 45,000', Icons.pending_actions, Colors.red, 'Metro Traders due in 2 days'),
            _metricCard('Input Tax Credit (ITC)', '₹ 34,248', Icons.receipt, Colors.green, 'Claimable in GSTR-3B'),
          ]),
        ],
      ),
    );
  }

  // 4. Profit and Loss
  Widget _buildProfitAndLoss() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Consolidated Profit & Loss Statement (P&L)', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Detailed revenue realization vs wholesale cost of goods sold (COGS) and overheads', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _statementRow('Total Footwear Sales (Revenue)', '₹ 4,58,920.00', isPositive: true),
                  _statementRow('Less: Wholesale Cost of Goods Sold (COGS)', '-₹ 2,85,400.00'),
                  const Divider(),
                  _statementRow('Gross Trading Profit', '₹ 1,73,520.00', isBold: true, isPositive: true),
                  _statementRow('Less: Showroom Rents & Utilities', '-₹ 38,450.00'),
                  _statementRow('Less: Staff Salaries & Incentive Commissions', '-₹ 10,270.00'),
                  const Divider(),
                  _statementRow('Net Operating Profit (Before Tax)', '₹ 1,24,800.00', isBold: true, isPositive: true, color: Colors.green),
                  _statementRow('Net Margin Percentage', '27.2%', isBold: true, color: const Color(0xFF4F46E5)),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // 5. Stock Alerts
  Widget _buildStockAlerts() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Live Stock Alerts & Out-of-Stock Warnings', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Automated replenishment triggers when shelf quantity drops below safety threshold (5 pairs)', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _alertCard('CRITICAL: Out of Stock', 'Woodland High Ankle Trekking Boots (UK 8 - Khaki)', '0 Pairs Left', 'Demand high due to trekking season. Issue PO immediately.', Colors.red),
          const SizedBox(height: 10),
          _alertCard('WARNING: Low Stock Threshold', 'Puma Smash V2 Leather (UK 7 - Navy Blue)', '2 Left on Shelf', 'Only 2 pairs remaining in Pune Flagship rack. Transfer from Central Hub.', Colors.orange),
          const SizedBox(height: 10),
          _alertCard('INFO: Fast Moving Velocity', 'Nike Air Max 270 (UK 9 - Pure White)', '6 Left (8 Sold Today)', 'Replenishment recommended before weekend rush.', Colors.blue),
        ],
      ),
    );
  }

  // 6. Employee Performance
  Widget _buildEmployeePerformance() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Store Staff & Sales Performance Ranking', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Track units sold, personal sales targets, commission incentives, and floor ranking', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _staffRankRow('1. Rahul Joshi', 'Sales Executive', '₹ 1,14,500 Sales (76.3% Target)', '₹ 2,862 Comm', 'Rank 1 (Gold)', Colors.amber.shade800),
                  const Divider(),
                  _staffRankRow('2. Vikas Kulkarni', 'Floor Assistant', '₹ 89,400 Sales (68.0% Target)', '₹ 2,235 Comm', 'Rank 2 (Silver)', Colors.blueGrey),
                  const Divider(),
                  _staffRankRow('3. Priya Nair', 'Sales Executive', '₹ 76,200 Sales (61.5% Target)', '₹ 1,905 Comm', 'Rank 3 (Bronze)', Colors.brown),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // 7. Branch-wise Reports
  Widget _buildBranchWiseReports() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Branch-Wise Revenue & Inventory Reports', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Comparative sales performance and stock distribution across all 4 outlets', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _branchReportCard('Pune Central Flagship (MG Road)', '₹ 2,14,500 Sales', '1,450 Pairs Stock', '3 POS Counters', 'Rank #1 Branch'),
          const SizedBox(height: 10),
          _branchReportCard('Mumbai Suburban Outlet (Bandra)', '₹ 1,42,800 Sales', '1,120 Pairs Stock', '2 POS Counters', 'Rank #2 Branch'),
          const SizedBox(height: 10),
          _branchReportCard('Nashik City Center Outlet', '₹ 1,01,620 Sales', '890 Pairs Stock', '2 POS Counters', 'Rank #3 Branch'),
        ],
      ),
    );
  }

  // 8. Expense Management
  Widget _buildExpenseManagement() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Store Operating Expense Oversight', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Monitor overhead expenditures, utilities, showroom lease payments, and approve vouchers', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _expenseRow('MG Road Showroom Monthly Rent', '₹ 32,000.00', 'Bank Transfer', 'APPROVED', Colors.green),
                  const Divider(),
                  _expenseRow('Electricity Bill (Air Conditioning & Lighting)', '₹ 6,450.00', 'Online UPI', 'APPROVED', Colors.green),
                  const Divider(),
                  _expenseRow('Custom Branded Shoe Carry Bags (500 pcs)', '₹ 4,200.00', 'Cash', 'APPROVED', Colors.green),
                  const Divider(),
                  _expenseRow('Staff Refreshments & Tea (Showroom)', '₹ 1,850.00', 'Cash', 'APPROVED', Colors.green),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // Helpers
  Widget _buildMetricsGrid(List<Widget> items) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final count = widget.isDesktop ? 4 : 2;
        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: count,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: widget.isDesktop ? 2.1 : 1.5,
          children: items,
        );
      },
    );
  }

  Widget _metricCard(String title, String val, IconData icon, Color col, String sub) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade200)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(child: Text(title, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey.shade600, fontSize: 11, fontWeight: FontWeight.bold))),
              CircleAvatar(backgroundColor: col.withValues(alpha: 0.12), radius: 14, child: Icon(icon, color: col, size: 16)),
            ],
          ),
          Text(val, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          Text(sub, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, color: Colors.grey.shade500)),
        ],
      ),
    );
  }

  Widget _progressRow(String label, double val, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(label, style: const TextStyle(fontSize: 12)), Text(text, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12))]),
          const SizedBox(height: 3),
          LinearProgressIndicator(value: val, minHeight: 6, borderRadius: BorderRadius.circular(3), color: const Color(0xFF4F46E5), backgroundColor: const Color(0xFFEEF2FF)),
        ],
      ),
    );
  }

  Widget _statementRow(String title, String amt, {bool isBold = false, bool isPositive = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: TextStyle(fontSize: 12, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
          Text(amt, style: TextStyle(fontSize: 12, fontWeight: isBold ? FontWeight.bold : FontWeight.normal, color: color ?? (isPositive ? Colors.green : Colors.black87))),
        ],
      ),
    );
  }

  Widget _alertCard(String badge, String title, String qty, String desc, Color col) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: col.withValues(alpha: 0.3))),
      color: col.withValues(alpha: 0.04),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Icon(Icons.warning, color: col, size: 28),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(badge, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 11)),
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  Text(desc, style: TextStyle(color: Colors.grey.shade700, fontSize: 11)),
                ],
              ),
            ),
            Text(qty, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: col)),
          ],
        ),
      ),
    );
  }

  Widget _staffRankRow(String name, String role, String sales, String comm, String badge, Color badgeCol) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)), Text('$role • $sales', style: TextStyle(color: Colors.grey.shade600, fontSize: 11))]),
          Row(children: [Text(comm, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.green)), const SizedBox(width: 8), Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: badgeCol.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)), child: Text(badge, style: TextStyle(color: badgeCol, fontSize: 10, fontWeight: FontWeight.bold)))])
        ],
      ),
    );
  }

  Widget _branchReportCard(String name, String sales, String stock, String terminals, String rank) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)), Text('$terminals • $stock', style: TextStyle(color: Colors.grey.shade600, fontSize: 11))]),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(sales, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF4F46E5))), Text(rank, style: const TextStyle(color: Colors.teal, fontWeight: FontWeight.bold, fontSize: 10))])
          ],
        ),
      ),
    );
  }

  Widget _expenseRow(String title, String amt, String mode, String status, Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)), Text('Mode: $mode', style: TextStyle(color: Colors.grey.shade600, fontSize: 10))]),
          Row(children: [Text(amt, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.orange)), const SizedBox(width: 8), Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: col.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)), child: Text(status, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 9)))])
        ],
      ),
    );
  }
}

