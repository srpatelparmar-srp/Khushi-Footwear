import 'package:flutter/material.dart';

class FootwearSuiteView extends StatefulWidget {
  final bool isDesktop;

  const FootwearSuiteView({super.key, required this.isDesktop});

  @override
  State<FootwearSuiteView> createState() => _FootwearSuiteViewState();
}

class _FootwearSuiteViewState extends State<FootwearSuiteView> {
  int _activeTab = 0;

  final List<String> _tabs = [
    'AI Voice Assistant & Co-Pilot',
    'AI Visual Search & Camera',
    'AI Festival Demand Forecaster',
    'AI Wear-Cycle & Retention',
    'AI Dead-Stock Markdown Engine',
    'Smart Size & Rack Locator',
    'Size & Color Matrix',
    'Brand & Model Inventory',
    'SKU & Barcode Center',
    'Availability Checker',
    'Size & Color Exchanges',
    'Damaged Footwear (RTV)',
    'Velocity (Fast & Slow)',
    'Promotions (B2G1 & Combos)',
    'Size & Brand Sales Reports',
  ];

  // Exchange Dialog State
  final String _exchangeOldVariant = 'Nike Air Max 270 (UK 8 - Pure White)';
  String _exchangeNewSize = 'UK 9';
  String _exchangeNewColor = 'Triple Black';

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Tab Header
        Container(
          height: 48,
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
          ),
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            itemCount: _tabs.length,
            itemBuilder: (context, idx) {
              final isSel = _activeTab == idx;
              return Padding(
                padding: const EdgeInsets.only(right: 6),
                child: FilterChip(
                  label: Text('${idx + 1}. ${_tabs[idx]}',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: isSel ? FontWeight.bold : FontWeight.w500,
                        color: isSel ? Colors.white : Colors.black87,
                      )),
                  selected: isSel,
                  selectedColor: const Color(0xFF4F46E5),
                  backgroundColor: const Color(0xFFF8FAFC),
                  showCheckmark: false,
                  onSelected: (_) => setState(() => _activeTab = idx),
                ),
              );
            },
          ),
        ),

        // Body Content
        Expanded(child: _buildTabBody()),
      ],
    );
  }

  Widget _buildTabBody() {
    switch (_activeTab) {
      case 0:
        return _buildAiVoiceAssistant();
      case 1:
        return _buildAiVisualSearch();
      case 2:
        return _buildAiDemandForecaster();
      case 3:
        return _buildAiWearCycleRetention();
      case 4:
        return _buildAiDeadStockMarkdown();
      case 5:
        return _buildSmartSizeAndRackLocator();
      case 6:
        return _buildSizeAndColorMatrix();
      case 7:
        return _buildBrandAndModelInventory();
      case 8:
        return _buildSkuAndBarcodeCenter();
      case 9:
        return _buildAvailabilityChecker();
      case 10:
        return _buildSizeAndColorExchanges();
      case 11:
        return _buildDamagedFootwearManagement();
      case 12:
        return _buildVelocityTracking();
      case 13:
        return _buildPromotionsAndOffers();
      case 14:
        return _buildSizeAndBrandReports();
      default:
        return _buildAiVoiceAssistant();
    }
  }

  // =========================================================================
  // AI 0. VOICE-ASSISTED WAREHOUSE INVENTORY ASSISTANT & FLOOR CO-PILOT
  // =========================================================================
  String _activeVoiceQuery = 'Where is Woodland Brown UK 9?';
  String _voiceResponseText = 'Found 6 pairs of Woodland Rugged Trekking Boot in UK 9 at RACK-B2, TIER-2 (EYE LEVEL). Selling price is ₹ 4,295.';
  bool _isListening = false;
  String _voiceBrand = 'Woodland';
  String _voiceSize = 'UK 9';
  String _voiceRack = 'RACK-B2';
  String _voiceTier = 'TIER-2 (EYE LEVEL)';
  int _voiceStock = 6;
  String _voicePrice = '₹ 4,295';

  Widget _buildAiVoiceAssistant() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('AI Voice-Assisted Warehouse Inventory Assistant', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Hands-free voice co-pilot for floor handlers and stock pickers. Speak natural queries into your headset or phone to locate shelf tiers and check stock in 120ms.', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          // Interactive Voice Microphone HUD Card
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.record_voice_over, color: Color(0xFF4F46E5), size: 18),
                          SizedBox(width: 8),
                          Text('Floor Co-Pilot Voice Engine', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(color: Colors.green.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                        child: const Row(
                          children: [
                            CircleAvatar(radius: 3, backgroundColor: Colors.green),
                            SizedBox(width: 5),
                            Text('WHISPER-PRO NLP (120ms)', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.green)),
                          ],
                        ),
                      )
                    ],
                  ),
                  const SizedBox(height: 24),
                  // Animated Microphone Button
                  GestureDetector(
                    onTap: () {
                      setState(() => _isListening = true);
                      Future.delayed(const Duration(milliseconds: 700), () {
                        if (mounted) setState(() => _isListening = false);
                      });
                    },
                    child: Container(
                      width: 90,
                      height: 90,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _isListening ? const Color(0xFFEF4444) : const Color(0xFF4F46E5),
                        boxShadow: [
                          BoxShadow(
                            color: (_isListening ? const Color(0xFFEF4444) : const Color(0xFF4F46E5)).withValues(alpha: 0.35),
                            blurRadius: _isListening ? 25 : 12,
                            spreadRadius: _isListening ? 6 : 2,
                          )
                        ],
                      ),
                      child: Icon(_isListening ? Icons.graphic_eq : Icons.mic, color: Colors.white, size: 40),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    _isListening ? '🎙️ Listening to floor staff audio...' : 'Tap Mic or speak natural command',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: _isListening ? Colors.redAccent : Colors.grey.shade700),
                  ),
                  const SizedBox(height: 16),
                  // Spoken Query Display Pill
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(color: const Color(0xFFF1F5F9), borderRadius: BorderRadius.circular(10)),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.format_quote, size: 14, color: Colors.grey),
                        const SizedBox(width: 4),
                        Text('“$_activeVoiceQuery”', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF1E293B))),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Quick Voice Prompts
                  Wrap(
                    spacing: 8,
                    runSpacing: 6,
                    alignment: WrapAlignment.center,
                    children: [
                      _quickVoiceChip('Where is Woodland Brown UK 9?', () {
                        setState(() {
                          _activeVoiceQuery = 'Where is Woodland Brown UK 9?';
                          _voiceBrand = 'Woodland';
                          _voiceSize = 'UK 9';
                          _voiceRack = 'RACK-B2';
                          _voiceTier = 'TIER-2 (EYE LEVEL)';
                          _voiceStock = 6;
                          _voicePrice = '₹ 4,295';
                          _voiceResponseText = 'Found 6 pairs of Woodland Rugged Boot UK 9 at RACK-B2, TIER-2 (EYE LEVEL).';
                        });
                      }),
                      _quickVoiceChip('Check Nike Air Max size 8 stock', () {
                        setState(() {
                          _activeVoiceQuery = 'Check Nike Air Max size 8 stock';
                          _voiceBrand = 'Nike';
                          _voiceSize = 'UK 8';
                          _voiceRack = 'RACK-A2';
                          _voiceTier = 'TIER-2 (EYE LEVEL)';
                          _voiceStock = 8;
                          _voicePrice = '₹ 8,995';
                          _voiceResponseText = 'Found 8 pairs of Nike Air Max 270 in UK 8 at RACK-A2, TIER-2 (EYE LEVEL).';
                        });
                      }),
                      _quickVoiceChip('Find Bata Formal Derby in UK 7', () {
                        setState(() {
                          _activeVoiceQuery = 'Find Bata Formal Derby in UK 7';
                          _voiceBrand = 'Bata';
                          _voiceSize = 'UK 7';
                          _voiceRack = 'RACK-C2';
                          _voiceTier = 'TIER-1 (TOP TIER)';
                          _voiceStock = 12;
                          _voicePrice = '₹ 2,499';
                          _voiceResponseText = 'Found 12 pairs of Bata Formal Derby in UK 7 at RACK-C2, TIER-1.';
                        });
                      }),
                      _quickVoiceChip('Puma Smash Navy UK 10 price and rack', () {
                        setState(() {
                          _activeVoiceQuery = 'Puma Smash Navy UK 10 price and rack';
                          _voiceBrand = 'Puma';
                          _voiceSize = 'UK 10';
                          _voiceRack = 'RACK-A4';
                          _voiceTier = 'TIER-3 (HAND LEVEL)';
                          _voiceStock = 9;
                          _voicePrice = '₹ 2,799';
                          _voiceResponseText = 'Puma Smash Navy UK 10 is ₹ 2,799 with 9 pairs at RACK-A4, TIER-3.';
                        });
                      }),
                    ],
                  )
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // AI Spoken Audio Response HUD Card
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [const Color(0xFF4F46E5).withValues(alpha: 0.08), const Color(0xFF7C3AED).withValues(alpha: 0.04)],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFF4F46E5).withValues(alpha: 0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.volume_up_rounded, color: Color(0xFF4F46E5), size: 20),
                        SizedBox(width: 8),
                        Text('Synthesized Floor Audio Guidance:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF4F46E5))),
                      ],
                    ),
                    IconButton(
                      icon: const Icon(Icons.replay_rounded, size: 18, color: Color(0xFF4F46E5)),
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('🔊 Speaking: "$_voiceResponseText"')));
                      },
                      tooltip: 'Replay Speech',
                    )
                  ],
                ),
                Text('“$_voiceResponseText”', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Color(0xFF1E293B))),
                const SizedBox(height: 6),
                Text('Detected: Brand = $_voiceBrand • Size = $_voiceSize', style: const TextStyle(fontSize: 10, color: Color(0xFF4F46E5), fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                // Visual Coordinate Badges
                Row(
                  children: [
                    _voiceInfoPill('TARGET RACK', _voiceRack, Icons.location_on, Colors.indigo),
                    const SizedBox(width: 10),
                    _voiceInfoPill('SHELF TIER', _voiceTier, Icons.layers, Colors.teal),
                    const SizedBox(width: 10),
                    _voiceInfoPill('STOCK COUNT', '$_voiceStock Pairs Available', Icons.inventory, Colors.green),
                    const SizedBox(width: 10),
                    _voiceInfoPill('SELLING PRICE', _voicePrice, Icons.currency_rupee, const Color(0xFF4F46E5)),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _quickVoiceChip(String text, VoidCallback onTap) {
    return ActionChip(
      avatar: const Icon(Icons.mic_none, size: 13, color: Color(0xFF4F46E5)),
      label: Text(text, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600)),
      backgroundColor: Colors.white,
      side: BorderSide(color: Colors.grey.shade300),
      onPressed: onTap,
    );
  }

  Widget _voiceInfoPill(String label, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 12, color: color),
                const SizedBox(width: 4),
                Text(label, style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: color)),
              ],
            ),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.black87), maxLines: 1, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }

  // =========================================================================
  // AI 4. DEAD-STOCK MARKDOWN & FLASH CLEARANCE OPTIMIZER
  // =========================================================================
  int _markdownAgingFilter = 60;

  Widget _buildAiDeadStockMarkdown() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('AI Dead-Stock Markdown & Flash Clearance Optimizer', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Identifies slow-moving shoe sizes unsold for >60/90/120 days, auto-computes optimal flash sale markdown pricing, and bundles BOGO promotions.', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          // Summary KPI Pills
          Row(
            children: [
              _markdownMetricPill('Trapped Inventory', '₹ 2,42,800', Icons.lock_clock, Colors.redAccent, 'Cost tied up in stagnant sizes'),
              const SizedBox(width: 10),
              _markdownMetricPill('Cash Recoverable', '₹ 2,04,400', Icons.currency_rupee, Colors.green, 'Via proposed markdown prices'),
              const SizedBox(width: 10),
              _markdownMetricPill('Avg Markdown Rate', '28.5% Off', Icons.percent, Colors.orange, 'Protects wholesale purchase cost'),
              const SizedBox(width: 10),
              _markdownMetricPill('Aging SKUs Flagged', '12 Variants', Icons.layers_clear, const Color(0xFF4F46E5), 'Ready for 1-click POS clearance'),
            ],
          ),
          const SizedBox(height: 16),
          // Filter Toolbar & 1-Click Sync to POS
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      const Text('Aging Filter: ', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.grey)),
                      const SizedBox(width: 8),
                      ChoiceChip(
                        label: const Text('All Aging (>60 Days)', style: TextStyle(fontSize: 10)),
                        selected: _markdownAgingFilter == 60,
                        selectedColor: const Color(0xFF4F46E5),
                        labelStyle: TextStyle(color: _markdownAgingFilter == 60 ? Colors.white : Colors.black87),
                        onSelected: (val) => setState(() => _markdownAgingFilter = 60),
                      ),
                      const SizedBox(width: 6),
                      ChoiceChip(
                        label: const Text('Stagnant (>90 Days)', style: TextStyle(fontSize: 10)),
                        selected: _markdownAgingFilter == 90,
                        selectedColor: const Color(0xFF4F46E5),
                        labelStyle: TextStyle(color: _markdownAgingFilter == 90 ? Colors.white : Colors.black87),
                        onSelected: (val) => setState(() => _markdownAgingFilter = 90),
                      ),
                      const SizedBox(width: 6),
                      ChoiceChip(
                        label: const Text('Severe Dead-Stock (>120 Days)', style: TextStyle(fontSize: 10)),
                        selected: _markdownAgingFilter == 120,
                        selectedColor: const Color(0xFF4F46E5),
                        labelStyle: TextStyle(color: _markdownAgingFilter == 120 ? Colors.white : Colors.black87),
                        onSelected: (val) => setState(() => _markdownAgingFilter = 120),
                      ),
                    ],
                  ),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF4F46E5),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    ),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          backgroundColor: Color(0xFF16A34A),
                          content: Text('⚡ AI Clearance Markdown pricing rules pushed LIVE to all Counter POS terminals!'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.sync_alt, size: 16),
                    label: const Text('Push Markdown Prices to POS Counters', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Identified Dead-Stock Shoe Sizes & Recommended Clearance Strategy', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
            child: ListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _markdownItemRow('Campus Oxyfit Dual Mesh (Grey)', 'UK 11', '124 Days Idle', 'Original: ₹ 1,899', 'Clearance: ₹ 1,044 (-45%)', 'BUY 1 GET 1 AT 50% (BOGO)', 'RACK-D4', 9, Colors.red),
                const Divider(height: 1),
                _markdownItemRow('Bata Formal Derby Classic (Burgundy)', 'UK 6', '108 Days Idle', 'Original: ₹ 2,499', 'Clearance: ₹ 1,749 (-30%)', 'WEEKEND FLASH SALE (30% OFF)', 'RACK-C3', 6, Colors.orange),
                const Divider(height: 1),
                _markdownItemRow('Puma Smash V2 Tennis (Olive Green)', 'UK 12', '132 Days Idle', 'Original: ₹ 2,799', 'Clearance: ₹ 1,539 (-45%)', 'BUY 1 GET 1 AT 50% (BOGO)', 'RACK-D2', 5, Colors.red),
                const Divider(height: 1),
                _markdownItemRow('Woodland Suede Chukka Boot (Navy)', 'UK 7', '76 Days Idle', 'Original: ₹ 4,295', 'Clearance: ₹ 3,436 (-20%)', 'CLEARANCE COUNTER RACK (20% OFF)', 'RACK-B4', 8, Colors.amber.shade800),
                const Divider(height: 1),
                _markdownItemRow('Nike Air Max 270 (Neon Volt)', 'UK 6', '92 Days Idle', 'Original: ₹ 8,995', 'Clearance: ₹ 6,296 (-30%)', 'WEEKEND FLASH SALE (30% OFF)', 'RACK-A3', 4, Colors.orange),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _markdownMetricPill(String title, String val, IconData icon, Color col, String sub) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: col.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: col.withValues(alpha: 0.25)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 14, color: col),
                const SizedBox(width: 4),
                Text(title, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 10)),
              ],
            ),
            const SizedBox(height: 6),
            Text(val, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: col)),
            const SizedBox(height: 2),
            Text(sub, style: const TextStyle(fontSize: 9, color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  Widget _markdownItemRow(String name, String size, String idleDays, String originalPrice, String clearancePrice, String strategy, String rack, int qty, Color statusColor) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
            child: Icon(Icons.local_offer_outlined, color: statusColor, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                      child: Text(idleDays, style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: statusColor)),
                    )
                  ],
                ),
                Text('Size: $size • $originalPrice • In Stock: $qty Pairs • Location: $rack', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                const SizedBox(height: 2),
                Text('Recommended Promo: $strategy', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF4F46E5))),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.green.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.green.withValues(alpha: 0.25)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(clearancePrice, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.green)),
                const Text('Cash Flow Recovery', style: TextStyle(fontSize: 9, color: Colors.grey)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // AI 3. SHOE-WEAR CYCLE PREDICTOR & WHATSAPP AUTO-RETENTION
  // =========================================================================
  int _wearCycleFilterDays = 150;

  Widget _buildAiWearCycleRetention() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('AI Shoe-Wear Cycle & WhatsApp Retention Engine', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Calculates midsole foam compression (~600km) and formal sole wear (~180-210 days) to auto-dispatch personalized upgrade vouchers via WhatsApp.', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          // Retention KPI Metrics
          Row(
            children: [
              _retentionMetricPill('Audited Walk-ins', '142 Customers', Icons.people_outline, const Color(0xFF4F46E5), 'Registered in CRM'),
              const SizedBox(width: 10),
              _retentionMetricPill('Due for Replacement', '18 Customers', Icons.timer_outlined, Colors.orange, 'Shoe age > 160 days'),
              const SizedBox(width: 10),
              _retentionMetricPill('Critical Soledown', '7 Customers', Icons.priority_high, Colors.redAccent, 'Shoe age > 210 days'),
              const SizedBox(width: 10),
              _retentionMetricPill('Revenue Recovery', '₹ 1,84,500', Icons.currency_rupee, Colors.green, '15% Upgrade Voucher'),
            ],
          ),
          const SizedBox(height: 16),
          // WhatsApp Retention Batch Dispatch Card
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Shoe Lifespan Filter & WhatsApp Campaign', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF25D366),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        ),
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              backgroundColor: Color(0xFF16A34A),
                              content: Text('📲 Automated WhatsApp Retention Vouchers dispatched to 18 wear-out customers with 15% VIP coupons!'),
                            ),
                          );
                        },
                        icon: const Icon(Icons.send_rounded, size: 16),
                        label: const Text('Dispatch WhatsApp Upgrade Vouchers', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      )
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Text('Filter Inactive Window: ', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.grey)),
                      const SizedBox(width: 8),
                      ChoiceChip(
                        label: const Text('> 150 Days (~5 Months)', style: TextStyle(fontSize: 10)),
                        selected: _wearCycleFilterDays == 150,
                        selectedColor: const Color(0xFF4F46E5),
                        labelStyle: TextStyle(color: _wearCycleFilterDays == 150 ? Colors.white : Colors.black87),
                        onSelected: (val) => setState(() => _wearCycleFilterDays = 150),
                      ),
                      const SizedBox(width: 6),
                      ChoiceChip(
                        label: const Text('> 180 Days (Half Year)', style: TextStyle(fontSize: 10)),
                        selected: _wearCycleFilterDays == 180,
                        selectedColor: const Color(0xFF4F46E5),
                        labelStyle: TextStyle(color: _wearCycleFilterDays == 180 ? Colors.white : Colors.black87),
                        onSelected: (val) => setState(() => _wearCycleFilterDays = 180),
                      ),
                      const SizedBox(width: 6),
                      ChoiceChip(
                        label: const Text('> 210 Days (Critical)', style: TextStyle(fontSize: 10)),
                        selected: _wearCycleFilterDays == 210,
                        selectedColor: const Color(0xFF4F46E5),
                        labelStyle: TextStyle(color: _wearCycleFilterDays == 210 ? Colors.white : Colors.black87),
                        onSelected: (val) => setState(() => _wearCycleFilterDays = 210),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Customer Shoe Mileage & AI Replacement Candidates', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
            child: ListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _retentionCustomerRow('Rahul Verma', '+91 98921 55432', 'UK 9', 'Nike Air Max 270', 218, 'CRITICAL_SOLEDOWN', 'Nike Pegasus 40 FlyEase', 'KF-UPGRADE-8491', Colors.red),
                const Divider(height: 1),
                _retentionCustomerRow('Amit Saxena', '+91 97654 32109', 'UK 8', 'Bata Classic Derby', 194, 'DUE_FOR_RENEWAL', 'Bata Heritage Oxford', 'KF-UPGRADE-2144', Colors.orange),
                const Divider(height: 1),
                _retentionCustomerRow('Vikram Shinde', '+91 98220 11984', 'UK 10', 'Adidas Ultraboost', 182, 'DUE_FOR_RENEWAL', 'Ultraboost Light v2', 'KF-UPGRADE-5491', Colors.orange),
                const Divider(height: 1),
                _retentionCustomerRow('Sneha Patel', '+91 94231 66782', 'UK 6', 'Puma Smash V2', 165, 'DUE_FOR_RENEWAL', 'Puma Cali Court White', 'KF-UPGRADE-7782', Colors.amber.shade800),
                const Divider(height: 1),
                _retentionCustomerRow('Suresh Jadhav', '+91 91588 44321', 'UK 8', 'Woodland Trekking Boot', 225, 'CRITICAL_SOLEDOWN', 'Woodland Pro Hiker', 'KF-UPGRADE-9012', Colors.red),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _retentionMetricPill(String title, String val, IconData icon, Color col, String sub) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: col.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: col.withValues(alpha: 0.25)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 14, color: col),
                const SizedBox(width: 4),
                Text(title, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 10)),
              ],
            ),
            const SizedBox(height: 6),
            Text(val, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: col)),
            const SizedBox(height: 2),
            Text(sub, style: const TextStyle(fontSize: 9, color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  Widget _retentionCustomerRow(String name, String phone, String size, String lastPurchased, int daysAgo, String wearStatus, String suggestedUpgrade, String voucher, Color badgeCol) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: badgeCol.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
            child: Icon(Icons.person, color: badgeCol, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: badgeCol.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                      child: Text('$daysAgo Days Ago', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: badgeCol)),
                    )
                  ],
                ),
                Text('$phone • Size: $size • Last Shoe: $lastPurchased', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                const SizedBox(height: 2),
                Text('Suggested Upgrade: $suggestedUpgrade', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF4F46E5))),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF25D366).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFF25D366).withValues(alpha: 0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.mark_chat_read, size: 12, color: Color(0xFF25D366)),
                    const SizedBox(width: 4),
                    Text(voucher, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: Color(0xFF16A34A))),
                  ],
                ),
                const Text('15% WhatsApp Voucher Ready', style: TextStyle(fontSize: 9, color: Colors.grey)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // AI 2. FESTIVAL DEMAND FORECASTER & SMART RESTOCK OPTIMIZER
  // =========================================================================
  String _selectedFestivalSeason = 'Diwali & New Year Festival';

  Widget _buildAiDemandForecaster() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('AI Predictive Footwear Demand & Festival Restock Forecaster', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Machine Learning model analyzes size velocity, festival calendar surges (Diwali, Eid, Weddings), and generates 1-click supplier purchase orders.', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          // Seasonal Selector & Quick Metrics Grid
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Target Seasonal Spike Horizon:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                      DropdownButton<String>(
                        value: _selectedFestivalSeason,
                        underline: const SizedBox(),
                        style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF4F46E5), fontSize: 13),
                        items: [
                          'Diwali & New Year Festival',
                          'Wedding & Reception Season',
                          'Eid-ul-Fitr Festive Rush',
                          'Back to School / College',
                        ].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
                        onChanged: (val) {
                          if (val != null) setState(() => _selectedFestivalSeason = val);
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _demandMetricCard('Projected Spike', '3.2x Surge', Icons.trending_up, Colors.orange, 'Based on 3-year store sales'),
                      const SizedBox(width: 10),
                      _demandMetricCard('Critical SKUs at Risk', '8 Variants', Icons.warning_amber_rounded, Colors.redAccent, 'Stockout within 6 days'),
                      const SizedBox(width: 10),
                      _demandMetricCard('Recommended Order', '164 Pairs', Icons.inventory_2, const Color(0xFF4F46E5), 'Across sizes UK 7, 8, 9'),
                      const SizedBox(width: 10),
                      _demandMetricCard('Estimated PO Value', '₹ 1,48,200', Icons.currency_rupee, Colors.green, 'Wholesale supplier invoice'),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Recommended Restock List with 1-Click PO Generator
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('High-Risk Footwear Variants (Stockout Imminent)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4F46E5),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      backgroundColor: Color(0xFF16A34A),
                      content: Text('✅ AI Purchase Order PO-AI-202611-9481 generated & dispatched to Metro Footwear Wholesale!'),
                    ),
                  );
                },
                icon: const Icon(Icons.flash_on, size: 16),
                label: const Text('1-Click Generate AI Purchase Order', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
            child: ListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _forecastRow('Nike Air Max 270 (Pure White)', 'UK 8', 3, 24, 21, 94.2, 'Metro Footwear Ltd', '₹ 5,800/pair', Colors.red),
                const Divider(height: 1),
                _forecastRow('Bata Classic Leather Derby (Tan)', 'UK 9', 2, 35, 33, 96.5, 'Apex Leather Craft', '₹ 1,450/pair', Colors.red),
                const Divider(height: 1),
                _forecastRow('Adidas Ultraboost Light (Black)', 'UK 7', 4, 20, 16, 91.8, 'Metro Footwear Ltd', '₹ 7,200/pair', Colors.orange),
                const Divider(height: 1),
                _forecastRow('Woodland Rugged Trekking Boot', 'UK 8', 5, 22, 17, 88.4, 'Woodland Direct Depo', '₹ 2,750/pair', Colors.orange),
                const Divider(height: 1),
                _forecastRow('Puma Smash V2 Tennis Shoe', 'UK 8', 6, 28, 22, 85.0, 'Metro Footwear Ltd', '₹ 1,799/pair', Colors.amber.shade800),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _demandMetricCard(String title, String val, IconData icon, Color col, String sub) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: col.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: col.withValues(alpha: 0.25)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 14, color: col),
                const SizedBox(width: 4),
                Text(title, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 10)),
              ],
            ),
            const SizedBox(height: 6),
            Text(val, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: col)),
            const SizedBox(height: 2),
            Text(sub, style: const TextStyle(fontSize: 9, color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  Widget _forecastRow(String name, String size, int currentStock, int predictedDemand, int recommendedOrder, double riskScore, String supplier, String unitCost, Color riskColor) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: riskColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
            child: Icon(Icons.show_chart, color: riskColor, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: riskColor.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                      child: Text('${riskScore.toStringAsFixed(1)}% Risk', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: riskColor)),
                    )
                  ],
                ),
                Text('Size: $size • Current Stock: $currentStock Pairs • Supplier: $supplier ($unitCost)', style: const TextStyle(fontSize: 11, color: Colors.grey)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF4F46E5).withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFF4F46E5).withValues(alpha: 0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('Order +$recommendedOrder Pairs', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF4F46E5))),
                Text('Festive Demand: $predictedDemand Pairs', style: const TextStyle(fontSize: 9, color: Colors.grey)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // AI. FOOTWEAR VISUAL SEARCH & LIVE CAMERA SCANNER
  // =========================================================================
  String _aiSelectedSilhouette = 'Running Sneaker';
  String _aiSelectedColor = 'White / Navy';
  bool _isAiScanning = false;

  Widget _buildAiVisualSearch() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('AI Footwear Visual Search & Camera Scanner', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Customer or staff snaps a picture of any sneaker or shoe. AI Vision model extracts silhouette, sole, color, and retrieves exact in-store shelf inventory.', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          // Visual Camera Viewfinder Simulator Card
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.camera_alt, color: Color(0xFF4F46E5), size: 18),
                          SizedBox(width: 8),
                          Text('AI Vision Camera Viewfinder', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(color: Colors.green.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                        child: const Row(
                          children: [
                            CircleAvatar(radius: 3, backgroundColor: Colors.green),
                            SizedBox(width: 5),
                            Text('AI MODEL READY (v2.4 Vision)', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.green)),
                          ],
                        ),
                      )
                    ],
                  ),
                  const SizedBox(height: 14),
                  // Mock Camera Capture Area with AI Target Bounding Box
                  Container(
                    height: 160,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F172A),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFF4F46E5).withValues(alpha: 0.4)),
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // Reticle lines
                        Positioned.fill(
                          child: CustomPaint(
                            painter: _AiCameraGridPainter(),
                          ),
                        ),
                        // Shoe Outline Target
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.directions_run, size: 54, color: _isAiScanning ? const Color(0xFF22C55E) : const Color(0xFF818CF8)),
                            const SizedBox(height: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.black.withValues(alpha: 0.6),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: const Color(0xFF818CF8).withValues(alpha: 0.5)),
                              ),
                              child: Text(
                                _isAiScanning ? '🔍 AI ANALYZING SHOE SILHOUETTE...' : '📸 ALIGN SHOE INSIDE FRAME & CAPTURE',
                                style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 0.6),
                              ),
                            )
                          ],
                        ),
                        Positioned(
                          top: 10,
                          right: 10,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(6)),
                            child: const Text('96.8% Confidence', style: TextStyle(color: Colors.white70, fontSize: 9)),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Sample Presets for Quick Demo
                  Row(
                    children: [
                      const Text('Quick Test Presets: ', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.grey)),
                      const SizedBox(width: 8),
                      _presetChip('Running Sneaker', 'White / Navy'),
                      const SizedBox(width: 6),
                      _presetChip('Formal Oxford', 'Tan Leather'),
                      const SizedBox(width: 6),
                      _presetChip('High Top Basketball', 'Red / Black'),
                      const Spacer(),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF4F46E5),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        ),
                        onPressed: () {
                          setState(() => _isAiScanning = true);
                          Future.delayed(const Duration(milliseconds: 600), () {
                            if (mounted) setState(() => _isAiScanning = false);
                          });
                        },
                        icon: const Icon(Icons.document_scanner, size: 16),
                        label: const Text('Capture & Match In-Store Stock', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      )
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Extracted AI Features & Detected Product Match Cards
          Row(
            children: [
              _aiFeaturePill('Detected Silhouette', _aiSelectedSilhouette, Icons.category),
              const SizedBox(width: 10),
              _aiFeaturePill('Primary Palette', _aiSelectedColor, Icons.palette),
              const SizedBox(width: 10),
              _aiFeaturePill('Sole Profile', 'Air Cushion EVA', Icons.layers),
              const SizedBox(width: 10),
              _aiFeaturePill('Upper Material', 'Breathable Mesh', Icons.texture),
            ],
          ),
          const SizedBox(height: 16),
          const Text('AI Matched In-Store Products & Rack Locations', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
            child: ListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _aiMatchRow('Nike Air Max 270 (Triple White)', 'Nike', 'UK 8, 9, 10', '₹ 8,995', '98.4%', 'RACK-A2', 'TIER-2 (EYE LEVEL)', 'SHOWROOM WALL', 8),
                const Divider(height: 1),
                _aiMatchRow('Adidas Ultraboost Light (Core White / Navy)', 'Adidas', 'UK 7, 8, 9', '₹ 11,499', '96.2%', 'RACK-B1', 'TIER-1 (TOP)', 'MAIN GODOWN', 5),
                const Divider(height: 1),
                _aiMatchRow('Puma Smash V2 Classic Leather', 'Puma', 'UK 6 to 11', '₹ 2,799', '94.8%', 'RACK-A4', 'TIER-3 (HAND LEVEL)', 'SHOWROOM WALL', 14),
                const Divider(height: 1),
                _aiMatchRow('Campus Oxyfit Dual Mesh Sneaker', 'Campus', 'UK 7, 8, 9, 10', '₹ 1,899', '91.5%', 'RACK-C1', 'TIER-2 (EYE LEVEL)', 'BUDGET SECTION', 12),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _presetChip(String silhouette, String color) {
    final isSel = _aiSelectedSilhouette == silhouette;
    return ChoiceChip(
      label: Text('$silhouette ($color)', style: const TextStyle(fontSize: 10)),
      selected: isSel,
      selectedColor: const Color(0xFF4F46E5),
      labelStyle: TextStyle(color: isSel ? Colors.white : Colors.black87),
      onSelected: (val) {
        if (val) {
          setState(() {
            _aiSelectedSilhouette = silhouette;
            _aiSelectedColor = color;
          });
        }
      },
    );
  }

  Widget _aiFeaturePill(String title, String value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: const Color(0xFFEEF2FF),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFF4F46E5).withValues(alpha: 0.2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 12, color: const Color(0xFF4F46E5)),
                const SizedBox(width: 4),
                Text(title, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w600, color: Colors.grey)),
              ],
            ),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF4F46E5))),
          ],
        ),
      ),
    );
  }

  Widget _aiMatchRow(String name, String brand, String sizes, String price, String confidence, String rack, String tier, String zone, int stock) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: const Color(0xFF22C55E).withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.auto_awesome, color: Color(0xFF16A34A), size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: Colors.green.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
                      child: Text('$confidence Match', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.green)),
                    )
                  ],
                ),
                Text('Brand: $brand • Available Sizes: $sizes • $price', style: const TextStyle(fontSize: 11, color: Colors.grey)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: Colors.indigo.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.indigo.withValues(alpha: 0.2))),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.location_on, size: 12, color: Color(0xFF4F46E5)),
                    const SizedBox(width: 4),
                    Text('$rack • $tier', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: Color(0xFF4F46E5))),
                  ],
                ),
                Text('$zone • In Stock: $stock Pairs', style: const TextStyle(fontSize: 9, color: Colors.grey)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // 0. SMART FOOTWEAR SIZE FINDER & RACK / SHELF LOCATOR ENGINE
  // =========================================================================
  double _customerFootLengthCm = 26.2;
  String _selectedGender = 'MEN';

  Widget _buildSmartSizeAndRackLocator() {
    // Conversion Logic
    String ukSize = _customerFootLengthCm >= 28.3 ? '11'
        : _customerFootLengthCm >= 27.5 ? '10'
        : _customerFootLengthCm >= 26.7 ? '9'
        : _customerFootLengthCm >= 25.9 ? '8'
        : _customerFootLengthCm >= 25.1 ? '7'
        : _customerFootLengthCm >= 24.3 ? '6' : '5';
    String usSize = (int.parse(ukSize) + 1).toString();
    String euroSize = (int.parse(ukSize) + 34).toString();
    double inches = _customerFootLengthCm / 2.54;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Smart Footwear Size Finder & Rack Locator', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Convert customer foot length into UK/IND, US, and EUR standards & locate instant rack shelf coordinates.', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          // Interactive Size Calculation Card
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('1. Customer Foot Length Measurement', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                      Row(
                        children: [
                          ChoiceChip(
                            label: const Text('Men', style: TextStyle(fontSize: 11)),
                            selected: _selectedGender == 'MEN',
                            onSelected: (val) => setState(() => _selectedGender = 'MEN'),
                            selectedColor: const Color(0xFF4F46E5),
                            labelStyle: TextStyle(color: _selectedGender == 'MEN' ? Colors.white : Colors.black87),
                          ),
                          const SizedBox(width: 6),
                          ChoiceChip(
                            label: const Text('Women', style: TextStyle(fontSize: 11)),
                            selected: _selectedGender == 'WOMEN',
                            onSelected: (val) => setState(() => _selectedGender = 'WOMEN'),
                            selectedColor: const Color(0xFF4F46E5),
                            labelStyle: TextStyle(color: _selectedGender == 'WOMEN' ? Colors.white : Colors.black87),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: Slider(
                          value: _customerFootLengthCm,
                          min: 22.0,
                          max: 30.0,
                          divisions: 80,
                          activeColor: const Color(0xFF4F46E5),
                          label: '${_customerFootLengthCm.toStringAsFixed(1)} cm',
                          onChanged: (val) => setState(() => _customerFootLengthCm = val),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(color: const Color(0xFFEEF2FF), borderRadius: BorderRadius.circular(8)),
                        child: Column(
                          children: [
                            Text('${_customerFootLengthCm.toStringAsFixed(1)} CM', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF4F46E5))),
                            Text('${inches.toStringAsFixed(2)} INCH', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                          ],
                        ),
                      )
                    ],
                  ),
                  const SizedBox(height: 12),
                  // Conversion Result Badges
                  Row(
                    children: [
                      _sizeStandardBadge('RECOMMENDED UK / IND', 'UK $ukSize', Colors.indigo),
                      const SizedBox(width: 10),
                      _sizeStandardBadge('US STANDARD', 'US $usSize', Colors.blue),
                      const SizedBox(width: 10),
                      _sizeStandardBadge('EURO SIZE', 'EU $euroSize', Colors.teal),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: Colors.amber.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.amber.withValues(alpha: 0.3))),
                          child: const Row(
                            children: [
                              Icon(Icons.tips_and_updates, size: 16, color: Colors.amber),
                              SizedBox(width: 6),
                              Expanded(
                                child: Text('Regular Width Fit. For wide feet, consider 0.5 size up.', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600)),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // In-Stock Shoes Available in this Recommended Size with Rack Location
          Text('2. In-Stock Pairs in UK $ukSize with Live Rack Coordinates', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
            child: ListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _rackItemRow('Nike Air Max 270 (Triple White)', 'UK $ukSize', 'White', '₹ 8,995', 'RACK-A2', 'TIER-2 (EYE LEVEL)', 'SHOWROOM WALL', 8),
                const Divider(height: 1),
                _rackItemRow('Adidas Ultraboost Light (Core Black)', 'UK $ukSize', 'Black', '₹ 11,499', 'RACK-B1', 'TIER-1 (TOP)', 'MAIN GODOWN', 5),
                const Divider(height: 1),
                _rackItemRow('Puma Smash V2 Leather Sneaker', 'UK $ukSize', 'Navy', '₹ 2,799', 'RACK-A4', 'TIER-3 (HAND LEVEL)', 'SHOWROOM WALL', 14),
                const Divider(height: 1),
                _rackItemRow('Bata Classic Leather Derby Oxford', 'UK $ukSize', 'Tan Brown', '₹ 2,499', 'RACK-C2', 'TIER-2 (EYE LEVEL)', 'FORMAL SECTION', 6),
                const Divider(height: 1),
                _rackItemRow('Woodland Rugged Trekking Boots', 'UK $ukSize', 'Khaki Olive', '₹ 4,295', 'RACK-D1', 'TIER-4 (BOTTOM)', 'BACK MEZZANINE', 4),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sizeStandardBadge(String label, String value, MaterialColor color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: color.withValues(alpha: 0.3))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: color.shade800)),
          Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color.shade900)),
        ],
      ),
    );
  }

  Widget _rackItemRow(String name, String size, String color, String price, String rack, String tier, String zone, int stock) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: const Color(0xFF4F46E5).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.shelves, color: Color(0xFF4F46E5), size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                Text('$size • Color: $color • $price', style: const TextStyle(fontSize: 11, color: Colors.grey)),
              ],
            ),
          ),
          // Rack Coordinates Tag
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: Colors.indigo.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.indigo.withValues(alpha: 0.2))),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.location_on, size: 12, color: Color(0xFF4F46E5)),
                    const SizedBox(width: 4),
                    Text('$rack • $tier', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: Color(0xFF4F46E5))),
                  ],
                ),
                Text('Zone: $zone • In Stock: $stock Pairs', style: const TextStyle(fontSize: 9, color: Colors.grey)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // 1 & 2. SIZE-WISE & COLOR-WISE INVENTORY MANAGEMENT
  // =========================================================================
  Widget _buildSizeAndColorMatrix() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('1 & 2. Size-Wise & Color-Wise Stock Matrix', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Multi-dimensional stock ledger tracking pair quantities per shoe size (UK 6 to 11) and color variants', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricCard('Available Sizes', 'UK 6 to 11', Icons.straighten, const Color(0xFF4F46E5), 'Standard Indian fitting'),
            _metricCard('Active Colorways', '18 Shades', Icons.palette, Colors.teal, 'Pure White, Black, Tan, Navy'),
            _metricCard('Total Size Stock', '4,280 Pairs', Icons.inventory_2, Colors.green, 'Across 4 outlets'),
            _metricCard('Low Size Alert', 'UK 10 & 11', Icons.warning_amber, Colors.orange, 'Stock below 5 pairs'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Live Variant Matrix: Nike Air Max 270 Flyknit', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 12),
                  _matrixItemRow('UK 7', 'Pure White (#FFFFFF)', '4 Pairs', Colors.green),
                  _matrixItemRow('UK 8', 'Pure White (#FFFFFF)', '8 Pairs', Colors.green),
                  _matrixItemRow('UK 9', 'Pure White (#FFFFFF)', '6 Pairs', Colors.green),
                  _matrixItemRow('UK 9', 'Triple Black (#111827)', '4 Pairs', Colors.green),
                  _matrixItemRow('UK 10', 'Royal Blue (#2563EB)', '2 Pairs (Low Stock)', Colors.orange),
                  _matrixItemRow('UK 11', 'Pure White (#FFFFFF)', '0 Pairs (Out of Stock)', Colors.red),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 3 & 4. BRAND-WISE & MODEL-WISE PRODUCT INVENTORY
  // =========================================================================
  Widget _buildBrandAndModelInventory() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('3 & 4. Brand-Wise & Model-Wise Product Management', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Inventory distribution, valuation, and active models across leading footwear brands', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _brandInventoryCard('Nike', '1,450 Pairs Stock', '₹ 6,52,000 Valuation', 'Fastest: UK 9', 'Air Max 270, Pegasus 40, Court Vision', Colors.black),
          const SizedBox(height: 10),
          _brandInventoryCard('Adidas', '980 Pairs Stock', '₹ 4,41,000 Valuation', 'Fastest: UK 8', 'Ultraboost Light, Stan Smith, Supernova', Colors.indigo),
          const SizedBox(height: 10),
          _brandInventoryCard('Puma', '620 Pairs Stock', '₹ 1,86,000 Valuation', 'Fastest: UK 7', 'Smash V2 Leather, RS-X, Softride', Colors.red),
          const SizedBox(height: 10),
          _brandInventoryCard('Bata', '840 Pairs Stock', '₹ 2,10,000 Valuation', 'Fastest: UK 10', 'Formal Derby Classic, Oxford, Hush Puppies', Colors.red.shade900),
          const SizedBox(height: 10),
          _brandInventoryCard('Woodland', '390 Pairs Stock', '₹ 1,95,000 Valuation', 'Fastest: UK 8', 'Waterproof Trekker, Nubuck High Ankle', Colors.brown),
        ],
      ),
    );
  }

  // =========================================================================
  // 5 & 6. UNIQUE SKU & UNIQUE BARCODE PER VARIANT
  // =========================================================================
  Widget _buildSkuAndBarcodeCenter() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('5 & 6. Unique SKU & Barcode Generation (Size + Color)', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Strict enterprise rule: Every distinct shoe size and colorway has its own unique SKU and EAN-13 barcode', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _skuBarcodeRow('NK-AM270-WHT-8', '8901234567808', 'Nike Air Max 270 (UK 8 - Pure White)', '₹ 8,995'),
                  const Divider(),
                  _skuBarcodeRow('NK-AM270-WHT-9', '8901234567890', 'Nike Air Max 270 (UK 9 - Pure White)', '₹ 8,995'),
                  const Divider(),
                  _skuBarcodeRow('NK-AM270-BLK-9', '8901234567899', 'Nike Air Max 270 (UK 9 - Triple Black)', '₹ 8,995'),
                  const Divider(),
                  _skuBarcodeRow('AD-UBL-BLK-8', '8901234567891', 'Adidas Ultraboost (UK 8 - Core Black)', '₹ 9,499'),
                  const Divider(),
                  _skuBarcodeRow('BT-FRM-TAN-10', '8901234567892', 'Bata Formal Derby (UK 10 - Oxford Tan)', '₹ 2,499'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 7 & 8. SIZE AVAILABILITY & COLOR AVAILABILITY CHECKING
  // =========================================================================
  Widget _buildAvailabilityChecker() {
    String selectedModel = 'Nike Air Max 270 Flyknit';
    String selectedSize = 'UK 9';
    String selectedColor = 'Pure White';

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('7 & 8. Real-Time Size & Color Availability Checker', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Instant shelf verification tool for floor assistants when a customer requests a specific size and shade', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Model: $selectedModel', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 12),
                  const Text('Select Shoe Size to Check:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 8,
                    children: ['UK 6', 'UK 7', 'UK 8', 'UK 9', 'UK 10', 'UK 11'].map((s) {
                      final isSel = selectedSize == s;
                      return ChoiceChip(
                        label: Text(s),
                        selected: isSel,
                        onSelected: (_) => setState(() => selectedSize = s),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 12),
                  const Text('Select Color to Check:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 8,
                    children: ['Pure White', 'Triple Black', 'Royal Blue'].map((c) {
                      final isSel = selectedColor == c;
                      return ChoiceChip(
                        label: Text(c),
                        selected: isSel,
                        onSelected: (_) => setState(() => selectedColor = c),
                      );
                    }).toList(),
                  ),
                  const Divider(height: 24),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.green.shade200),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.check_circle, color: Colors.green, size: 28),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('AVAILABLE IN STORE: $selectedSize in $selectedColor', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green.shade900)),
                              Text('Current Shelf Stock: 6 Pairs • Rack Location: Aisle 3 - Shelf B', style: TextStyle(color: Colors.green.shade800, fontSize: 11)),
                            ],
                          ),
                        ),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Reserved $selectedSize ($selectedColor) for floor trial!')));
                          },
                          child: const Text('Reserve for Trial'),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 9 & 10. SIZE EXCHANGE & COLOR EXCHANGE
  // =========================================================================
  Widget _buildSizeAndColorExchanges() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('9 & 10. Footwear Size & Color Exchange Console', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Process customer size swaps or color replacements within 7 days, automatically adjusting stock counts', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Initiate Footwear Size/Color Swap', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  Text('Original Billed Footwear: $_exchangeOldVariant', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          initialValue: _exchangeNewSize,
                          decoration: const InputDecoration(labelText: 'Replacement Shoe Size'),
                          items: ['UK 7', 'UK 8', 'UK 9', 'UK 10', 'UK 11']
                              .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                              .toList(),
                          onChanged: (v) => setState(() => _exchangeNewSize = v ?? _exchangeNewSize),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          initialValue: _exchangeNewColor,
                          decoration: const InputDecoration(labelText: 'Replacement Color'),
                          items: ['Pure White', 'Triple Black', 'Royal Blue']
                              .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                              .toList(),
                          onChanged: (v) => setState(() => _exchangeNewColor = v ?? _exchangeNewColor),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text('Exchange processed! Returned pair put back into inventory, $_exchangeNewSize ($_exchangeNewColor) handed to customer.')));
                    },
                    icon: const Icon(Icons.swap_horiz),
                    label: const Text('Complete Size/Color Exchange & Issue Slip'),
                  ),
                  const Divider(height: 24),
                  const Text('Recent Exchange Audits', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 8),
                  _exchangeAuditRow('EXCH-2026-0881', 'Amit Saxena', 'Nike Air Max', 'UK 8 swapped to UK 9', 'COMPLETED'),
                  _exchangeAuditRow('EXCH-2026-0882', 'Sunita Rao', 'Puma Smash V2', 'Black swapped to Navy Blue', 'COMPLETED'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 11. DAMAGED FOOTWEAR MANAGEMENT
  // =========================================================================
  Widget _buildDamagedFootwearManagement() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('11. Damaged Footwear Management (RTV / Write-Off)', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Record footwear defects (sole separation, leather cracks, factory mismatches) and issue supplier debit notes', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricCard('Damaged Pairs (Month)', '6 Pairs', Icons.broken_image, Colors.red, '0.14% of total inventory'),
            _metricCard('Factory Claims', '4 Pairs', Icons.assignment_return, Colors.orange, 'RTV to Manufacturer'),
            _metricCard('Debit Notes Settled', '₹ 14,200', Icons.receipt_long, Colors.green, 'Refunds approved by vendor'),
            _metricCard('Scrap Write-Offs', '2 Pairs', Icons.delete_outline, Colors.grey, 'Irreparable customer wear'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _damagedItemRow('DAM-2026-012', 'Metro Leather Traders', 'Bata Formal Derby (UK 9)', 'Sole delamination during transit', 'DEBIT NOTE ISSUED (₹ 2,499)', Colors.green),
                  const Divider(),
                  _damagedItemRow('DAM-2026-011', 'Nike Wholesale', 'Nike Air Max 270 (UK 8)', 'Air cushion puncture on arrival', 'VENDOR APPROVED (₹ 8,995)', Colors.green),
                  const Divider(),
                  _damagedItemRow('DAM-2026-010', 'Crocs Logistics', 'Crocs Classic Clog (UK 7)', 'Broken heel strap defect', 'SCRAP WRITE-OFF (₹ 2,799)', Colors.red),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 12 & 13. FAST-MOVING & SLOW-MOVING PRODUCT TRACKING
  // =========================================================================
  Widget _buildVelocityTracking() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('12 & 13. Fast-Moving & Slow-Moving Footwear Velocity', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Automated inventory aging analysis to prioritize high-turnover reorders and liquidate slow-moving pairs', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.green.shade200)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.trending_up, color: Colors.green),
                            SizedBox(width: 8),
                            Text('FAST-MOVING STYLES (High Turn)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.green)),
                          ],
                        ),
                        const Divider(),
                        _velocityItem('Nike Air Max 270 (UK 9)', '180 Pairs / Month', 'Turn Rate: 4.2 Days', 'Replenish Immediately', Colors.green),
                        _velocityItem('Bata Formal Derby (UK 8)', '140 Pairs / Month', 'Turn Rate: 5.1 Days', 'Adequate Shelf Stock', Colors.green),
                        _velocityItem('Adidas Ultraboost (UK 8)', '125 Pairs / Month', 'Turn Rate: 5.8 Days', 'Adequate Shelf Stock', Colors.green),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.orange.shade200)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.hourglass_bottom, color: Colors.orange),
                            SizedBox(width: 8),
                            Text('SLOW-MOVING STYLES (Aging >60 Days)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.orange)),
                          ],
                        ),
                        const Divider(),
                        _velocityItem('Woodland Loafers (UK 11)', '2 Pairs Sold in 90 Days', '94 Days in Stock', 'Recommend: 25% Off Clearance', Colors.orange),
                        _velocityItem('Puma Neon High Tops (UK 6)', '4 Pairs Sold in 60 Days', '72 Days in Stock', 'Recommend: Bundle with Socks', Colors.orange),
                        _velocityItem('Ethnic Leather Mojari (UK 11)', '1 Pair Sold in 60 Days', '68 Days in Stock', 'Recommend: Festive B2G1', Colors.orange),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 14, 15 & 16. SEASONAL OFFERS, COMBO OFFERS & BUY 2 GET 1 (B2G1)
  // =========================================================================
  Widget _buildPromotionsAndOffers() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('14, 15 & 16. Footwear Promotional Offer Engine', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Manage seasonal festival sales, shoe care combos, and Buy 2 Get 1 Free (B2G1) automated POS billing triggers', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          _offerBannerCard(
            '14. SEASONAL FESTIVAL OFFER',
            'Festive Wedding Footwear Carnival (Flat 20% Off)',
            'Applicable on all Bata Formal Derbies, Oxfords, and Traditional Mojaris above ₹ 1,999.',
            'Coupon Code: FESTIVE20',
            Colors.amber.shade900,
          ),
          const SizedBox(height: 12),
          _offerBannerCard(
            '15. FOOTWEAR CARE COMBO OFFER',
            'Sneaker + Nano Protect Spray Bundle',
            'Buy any pair of Nike or Adidas sneakers, get Shoe Care Waterproofer Spray @ ₹ 499 (MRP ₹ 799).',
            'Automated Trigger at POS Checkout',
            const Color(0xFF4F46E5),
          ),
          const SizedBox(height: 12),
          _offerBannerCard(
            '16. BUY 2 GET 1 FREE (B2G1 OFFER)',
            'Buy 2 Get 1 Free on Daily Wear, Canvas & Flip-Flops',
            'Add any 3 pairs to cart from Casual & Beachwear categories. Lowest value pair automatically discounted to ₹ 0.00!',
            'Auto B2G1 Discount Rule Active',
            Colors.teal,
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // 17 & 18. SIZE-WISE & BRAND-WISE SALES REPORTS
  // =========================================================================
  Widget _buildSizeAndBrandReports() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('17 & 18. Size-Wise & Brand-Wise Sales Reports', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Granular volume and revenue contribution reports to optimize manufacturing orders and inventory mix', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('17. Size-Wise Sales Contribution (November 2026)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 12),
                  _sizeShareBar('Size UK 8 (Highest Demand)', 0.38, '188 Pairs (38.0% of Sales) • ₹ 4,12,000'),
                  _sizeShareBar('Size UK 9 (Athletic & Formal)', 0.32, '158 Pairs (31.9% of Sales) • ₹ 3,78,000'),
                  _sizeShareBar('Size UK 7 (Youth & Casual)', 0.18, '88 Pairs (17.8% of Sales) • ₹ 1,76,000'),
                  _sizeShareBar('Size UK 6 (Small Foot Size)', 0.08, '42 Pairs (8.5% of Sales) • ₹ 84,000'),
                  _sizeShareBar('Size UK 10 & 11 (Large Fit)', 0.04, '19 Pairs (3.8% of Sales) • ₹ 45,000'),
                  const Divider(height: 28),
                  const Text('18. Brand-Wise Revenue Share', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 12),
                  _sizeShareBar('Nike (31.0% Share)', 0.31, '120 Pairs • ₹ 1,42,000.00'),
                  _sizeShareBar('Adidas (21.5% Share)', 0.215, '85 Pairs • ₹ 98,500.00'),
                  _sizeShareBar('Puma (14.0% Share)', 0.14, '72 Pairs • ₹ 64,200.00'),
                  _sizeShareBar('Bata (12.8% Share)', 0.128, '94 Pairs • ₹ 58,900.00'),
                  _sizeShareBar('Woodland (9.9% Share)', 0.099, '38 Pairs • ₹ 45,600.00'),
                  _sizeShareBar('Campus (8.4% Share)', 0.084, '64 Pairs • ₹ 38,400.00'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // --- HELPERS ---
  Widget _buildMetricsGrid(List<Widget> items) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final count = widget.isDesktop ? 4 : 2;
        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: count,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: widget.isDesktop ? 2.1 : 1.5,
          children: items,
        );
      },
    );
  }

  Widget _metricCard(String title, String val, IconData icon, Color col, String sub) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade200)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(child: Text(title, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey.shade600, fontSize: 11, fontWeight: FontWeight.bold))),
              CircleAvatar(backgroundColor: col.withValues(alpha: 0.12), radius: 14, child: Icon(icon, color: col, size: 16)),
            ],
          ),
          Text(val, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          Text(sub, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, color: Colors.grey.shade500)),
        ],
      ),
    );
  }

  Widget _matrixItemRow(String size, String color, String stock, Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('Shoe Size: $size • Color: $color', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
          Text(stock, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: col)),
        ],
      ),
    );
  }

  Widget _brandInventoryCard(String brand, String stock, String val, String fastest, String models, Color badgeCol) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(brand, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                    const SizedBox(width: 8),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: badgeCol.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)), child: Text(fastest, style: TextStyle(color: badgeCol, fontSize: 10, fontWeight: FontWeight.bold))),
                  ],
                ),
                const SizedBox(height: 2),
                Text('Top Models: $models', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(val, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF4F46E5))),
                Text(stock, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: Colors.green)),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _skuBarcodeRow(String sku, String barcode, String name, String price) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text('SKU: $sku • EAN: $barcode', style: const TextStyle(fontFamily: 'monospace', fontSize: 10, color: Colors.grey)),
            ],
          ),
          Text(price, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF4F46E5))),
        ],
      ),
    );
  }

  Widget _exchangeAuditRow(String id, String cust, String item, String details, String status) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('$id • $cust ($details)', style: const TextStyle(fontSize: 11)),
          Text(status, style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 10)),
        ],
      ),
    );
  }

  Widget _damagedItemRow(String damNo, String vendor, String item, String reason, String status, Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$damNo • $item', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text('Vendor: $vendor • Reason: $reason', style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
            ],
          ),
          Text(status, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: col)),
        ],
      ),
    );
  }

  Widget _velocityItem(String item, String sales, String turn, String action, Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(item, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(sales, style: TextStyle(color: Colors.grey.shade700, fontSize: 11)),
              Text(turn, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 11)),
            ],
          ),
          Text(action, style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
        ],
      ),
    );
  }

  Widget _offerBannerCard(String type, String title, String desc, String code, Color col) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: col.withValues(alpha: 0.3))),
      color: col.withValues(alpha: 0.04),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: col.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(4)),
              child: Text(type, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 10)),
            ),
            const SizedBox(height: 6),
            Text(title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: col)),
            const SizedBox(height: 4),
            Text(desc, style: TextStyle(color: Colors.grey.shade700, fontSize: 12)),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(6), border: Border.all(color: Colors.grey.shade300)),
              child: Text(code, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.black87)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sizeShareBar(String label, double val, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(label, style: const TextStyle(fontSize: 12)), Text(text, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11))]),
          const SizedBox(height: 3),
          LinearProgressIndicator(value: val, minHeight: 6, borderRadius: BorderRadius.circular(3), color: const Color(0xFF4F46E5), backgroundColor: const Color(0xFFEEF2FF)),
        ],
      ),
    );
  }
}

class _AiCameraGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withValues(alpha: 0.12)
      ..strokeWidth = 1;

    // Draw 3x3 rule of thirds grid
    final dx = size.width / 3;
    final dy = size.height / 3;

    canvas.drawLine(Offset(dx, 0), Offset(dx, size.height), paint);
    canvas.drawLine(Offset(dx * 2, 0), Offset(dx * 2, size.height), paint);
    canvas.drawLine(Offset(0, dy), Offset(size.width, dy), paint);
    canvas.drawLine(Offset(0, dy * 2), Offset(size.width, dy * 2), paint);

    // Corner brackets
    final cornerPaint = Paint()
      ..color = const Color(0xFF818CF8)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    const double cornerLen = 16.0;
    // Top-left
    canvas.drawLine(const Offset(12, 12), const Offset(12 + cornerLen, 12), cornerPaint);
    canvas.drawLine(const Offset(12, 12), const Offset(12, 12 + cornerLen), cornerPaint);
    // Top-right
    canvas.drawLine(Offset(size.width - 12, 12), Offset(size.width - 12 - cornerLen, 12), cornerPaint);
    canvas.drawLine(Offset(size.width - 12, 12), Offset(size.width - 12, 12 + cornerLen), cornerPaint);
    // Bottom-left
    canvas.drawLine(Offset(12, size.height - 12), Offset(12 + cornerLen, size.height - 12), cornerPaint);
    canvas.drawLine(Offset(12, size.height - 12), Offset(12, size.height - 12 - cornerLen), cornerPaint);
    // Bottom-right
    canvas.drawLine(Offset(size.width - 12, size.height - 12), Offset(size.width - 12 - cornerLen, size.height - 12), cornerPaint);
    canvas.drawLine(Offset(size.width - 12, size.height - 12), Offset(size.width - 12, size.height - 12 - cornerLen), cornerPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
