import 'package:flutter/material.dart';

class AdminErpModulesView extends StatefulWidget {
  final bool isDesktop;
  final String role;
  final int initialModuleIndex;

  const AdminErpModulesView({
    super.key,
    required this.isDesktop,
    required this.role,
    this.initialModuleIndex = 0,
  });

  @override
  State<AdminErpModulesView> createState() => _AdminErpModulesViewState();
}

class _AdminErpModulesViewState extends State<AdminErpModulesView> {
  late int _selectedModule;

  // The 21 Web Application Modules as specified
  final List<Map<String, dynamic>> _modules = [
    {'title': 'Dashboard', 'icon': Icons.dashboard_outlined, 'desc': 'Sales, purchases, profit, expenses, stock summary'},
    {'title': 'User Management', 'icon': Icons.admin_panel_settings_outlined, 'desc': 'Users, roles, permissions'},
    {'title': 'Branch Management', 'icon': Icons.store_mall_directory_outlined, 'desc': 'Shop and branch details'},
    {'title': 'Category Management', 'icon': Icons.category_outlined, 'desc': 'Categories and subcategories'},
    {'title': 'Brand Management', 'icon': Icons.branding_watermark_outlined, 'desc': 'Footwear brands'},
    {'title': 'Product Management', 'icon': Icons.snowshoeing_outlined, 'desc': 'Products, sizes, colors, images'},
    {'title': 'Barcode Management', 'icon': Icons.qr_code_2_outlined, 'desc': 'Generate and print barcodes'},
    {'title': 'Inventory Management', 'icon': Icons.inventory_2_outlined, 'desc': 'Stock inward, outward, transfer'},
    {'title': 'POS Billing', 'icon': Icons.point_of_sale_outlined, 'desc': 'Sales, GST, discounts, invoices'},
    {'title': 'Purchase Management', 'icon': Icons.shopping_cart_checkout_outlined, 'desc': 'Suppliers, purchase orders, GRN'},
    {'title': 'Customer Management', 'icon': Icons.people_outline, 'desc': 'Customer details and history'},
    {'title': 'Supplier Management', 'icon': Icons.local_shipping_outlined, 'desc': 'Supplier details and payments'},
    {'title': 'Sales Management', 'icon': Icons.receipt_long_outlined, 'desc': 'Sales history and invoices'},
    {'title': 'Return Management', 'icon': Icons.swap_horiz_outlined, 'desc': 'Sales returns and exchanges'},
    {'title': 'Expense Management', 'icon': Icons.account_balance_wallet_outlined, 'desc': 'Business expenses'},
    {'title': 'Accounts Management', 'icon': Icons.account_balance_outlined, 'desc': 'Cashbook, payments, outstanding'},
    {'title': 'Employee Management', 'icon': Icons.badge_outlined, 'desc': 'Employees, attendance, salary'},
    {'title': 'Offer Management', 'icon': Icons.local_offer_outlined, 'desc': 'Coupons and discounts'},
    {'title': 'Reports', 'icon': Icons.analytics_outlined, 'desc': 'Sales, purchases, stock, GST, profit'},
    {'title': 'Notification Management', 'icon': Icons.notifications_active_outlined, 'desc': 'Stock alerts and payment reminders'},
    {'title': 'Settings', 'icon': Icons.settings_outlined, 'desc': 'Shop, tax, invoice and system settings'},
  ];

  @override
  void initState() {
    super.initState();
    _selectedModule = widget.initialModuleIndex;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Top 21 Modules Horizontal Filter Scroll Bar
        Container(
          height: 48,
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
          ),
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            itemCount: _modules.length,
            itemBuilder: (context, idx) {
              final mod = _modules[idx];
              final isSel = _selectedModule == idx;
              return Padding(
                padding: const EdgeInsets.only(right: 6),
                child: FilterChip(
                  avatar: Icon(mod['icon'] as IconData, size: 14, color: isSel ? Colors.white : const Color(0xFF4F46E5)),
                  label: Text('${idx + 1}. ${mod['title']}',
                      style: TextStyle(fontSize: 11, fontWeight: isSel ? FontWeight.bold : FontWeight.w500, color: isSel ? Colors.white : Colors.black87)),
                  selected: isSel,
                  selectedColor: const Color(0xFF4F46E5),
                  backgroundColor: const Color(0xFFF8FAFC),
                  checkmarkColor: Colors.white,
                  showCheckmark: false,
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 0),
                  onSelected: (_) => setState(() => _selectedModule = idx),
                ),
              );
            },
          ),
        ),

        // Active Module Content Area
        Expanded(
          child: _buildSelectedModuleContent(),
        ),
      ],
    );
  }

  Widget _buildSelectedModuleContent() {
    switch (_selectedModule) {
      case 0:
        return _buildDashboardModule();
      case 1:
        return _buildUserManagementModule();
      case 2:
        return _buildBranchManagementModule();
      case 3:
        return _buildCategoryManagementModule();
      case 4:
        return _buildBrandManagementModule();
      case 5:
        return _buildProductManagementModule();
      case 6:
        return _buildBarcodeManagementModule();
      case 7:
        return _buildInventoryManagementModule();
      case 8:
        return _buildPosBillingModule();
      case 9:
        return _buildPurchaseManagementModule();
      case 10:
        return _buildCustomerManagementModule();
      case 11:
        return _buildSupplierManagementModule();
      case 12:
        return _buildSalesManagementModule();
      case 13:
        return _buildReturnManagementModule();
      case 14:
        return _buildExpenseManagementModule();
      case 15:
        return _buildAccountsManagementModule();
      case 16:
        return _buildEmployeeManagementModule();
      case 17:
        return _buildOfferManagementModule();
      case 18:
        return _buildReportsModule();
      case 19:
        return _buildNotificationManagementModule();
      case 20:
        return _buildSettingsModule();
      default:
        return _buildDashboardModule();
    }
  }

  // =========================================================================
  // 1. DASHBOARD (Sales, purchases, profit, expenses, stock summary)
  // =========================================================================
  Widget _buildDashboardModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('1. Executive Business Dashboard', 'Comprehensive real-time overview of sales revenue, purchases, net profit margins, daily expenses, and stock ledger.'),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Total Sales Revenue', '₹ 4,58,920', Icons.point_of_sale, Colors.green, '+14.2% vs last month'),
            _metricItem('Wholesale Purchases', '₹ 2,85,400', Icons.shopping_bag, const Color(0xFF4F46E5), '48 PO consignments'),
            _metricItem('Gross Profit', '₹ 1,73,520', Icons.trending_up, Colors.teal, '37.8% Gross Margin'),
            _metricItem('Operating Expenses', '₹ 48,720', Icons.account_balance_wallet, Colors.orange, 'Rent, salaries, upkeep'),
            _metricItem('Net Realized Profit', '₹ 1,24,800', Icons.savings, Colors.indigo, '27.2% Net Margin'),
            _metricItem('Total Stock Valuation', '₹ 18,50,000', Icons.inventory, Colors.amber.shade900, '4,280 footwear pairs'),
            _metricItem('Active Branches', '4 Outlets', Icons.store, Colors.blue, 'Pune, Mumbai, Nashik'),
            _metricItem('Low Stock Warnings', '14 Styles', Icons.warning_amber, Colors.red, 'Needs inward replenishment'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Footwear Category Sales Contribution', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 12),
                  _sizeProgressRow('Sneakers & Sports Footwear (Nike, Adidas, Campus)', 0.45, '₹ 2,06,514 (45%)'),
                  _sizeProgressRow('Formal Leather Shoes & Derbies (Bata, Red Chief)', 0.28, '₹ 1,28,497 (28%)'),
                  _sizeProgressRow('Outdoor Boots & Trekkers (Woodland)', 0.15, '₹ 68,838 (15%)'),
                  _sizeProgressRow('Casual Slip-ons & Sandals (Crocs, Sparx)', 0.12, '₹ 55,071 (12%)'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 2. USER MANAGEMENT (Users, roles, permissions)
  // =========================================================================
  Widget _buildUserManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('2. User & Access Control Management', 'Maintain enterprise users, assign 9 granular security roles, configure granular permission policies, and track audit sessions.'),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Enterprise Users & Assigned Roles', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      ElevatedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.person_add, size: 14),
                        label: const Text('Add User'),
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                      )
                    ],
                  ),
                  const Divider(height: 20),
                  _tableRow('Rajesh Khushi', 'Super Admin', 'All Branches', 'rajesh.owner@khushifootwear.com', 'ACTIVE', Colors.green),
                  _tableRow('Sunil Patil', 'Store Manager', 'Pune Flagship', 'sunil.mgr@khushifootwear.com', 'ACTIVE', Colors.green),
                  _tableRow('Anita Deshmukh', 'Cashier', 'Pune Flagship', 'anita.pos@khushifootwear.com', 'ACTIVE', Colors.green),
                  _tableRow('Vikram Shinde', 'Inventory Manager', 'Central Warehouse', 'vikram.inv@khushifootwear.com', 'ACTIVE', Colors.green),
                  _tableRow('Mahesh Jadhav', 'Accountant', 'Head Office', 'mahesh.acc@khushifootwear.com', 'ACTIVE', Colors.green),
                  _tableRow('Rahul Joshi', 'Sales Executive', 'MG Road Showroom', 'rahul.sales@khushifootwear.com', 'ACTIVE', Colors.green),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 3. BRANCH MANAGEMENT (Shop and branch details)
  // =========================================================================
  Widget _buildBranchManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('3. Shop & Branch Multi-Location Management', 'Configure central shop profile, GSTIN certificates, multi-branch store outlets, and warehouse locations.'),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Central Outlets', '4 Showrooms', Icons.store, const Color(0xFF4F46E5), 'Pune, Mumbai, Nashik'),
            _metricItem('Warehouse Hubs', '1 Central Hub', Icons.warehouse, Colors.teal, 'Chakan Industrial Zone'),
            _metricItem('POS Terminals', '8 Active Counters', Icons.computer, Colors.indigo, 'Syncing real-time'),
            _metricItem('Total Floor Area', '14,500 sq.ft.', Icons.aspect_ratio, Colors.orange, 'Air conditioned retail'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Registered Showrooms & Hubs', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _branchRow('Branch #1: Pune Central Flagship', 'MG Road, Camp, Pune - 411001', '+91 20 2612 3456', '3 POS Counters • 1,450 Pairs Stock'),
                  const Divider(),
                  _branchRow('Branch #2: Mumbai Suburban Hub', 'Linking Road, Bandra West, Mumbai - 400050', '+91 22 2640 9876', '2 POS Counters • 1,120 Pairs Stock'),
                  const Divider(),
                  _branchRow('Branch #3: Nashik City Center Outlet', 'College Road, Nashik - 422005', '+91 253 231 4455', '2 POS Counters • 890 Pairs Stock'),
                  const Divider(),
                  _branchRow('Branch #4: Central Logistics Warehouse', 'Chakan MIDC Phase 2, Pune', '+91 2135 667788', 'GRN Inward Hub • 820 Pairs In Transit'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 4. CATEGORY MANAGEMENT (Categories and subcategories)
  // =========================================================================
  Widget _buildCategoryManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('4. Footwear Category & Subcategory Master', 'Structure footwear taxonomy: Sports, Formal, Casual, Outdoor, Ethnic, Medical Orthopedic & Kids footwear.'),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Footwear Categories Hierarchy', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      ElevatedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.add, size: 14),
                        label: const Text('Add Category'),
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                      )
                    ],
                  ),
                  const Divider(height: 20),
                  _categoryRow('Sports & Athletic', 'Running Shoes, Basketball High-tops, Badminton Gum-soles, Gym Training', '42 Active Products'),
                  _categoryRow('Men Formal', 'Oxford Classic, Derby Leather, Monk Straps, Formal Slip-ons', '28 Active Products'),
                  _categoryRow('Casual Streetwear', 'White Leather Sneakers, Canvas Low-tops, Loafers, Moccasins', '36 Active Products'),
                  _categoryRow('Outdoor & Adventure', 'Waterproof High Ankle Boots, Nubuck Trekkers, Desert Walkers', '18 Active Products'),
                  _categoryRow('Ethnic & Festive', 'Jutis, Mojaris, Kolhapuri Chappals, Sherwani Footwear', '14 Active Products'),
                  _categoryRow('Accessories & Care', 'Nano Waterproofer Sprays, Wax Polish, Shoe Horns, Odor Balls, Socks', '22 Active Items'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 5. BRAND MANAGEMENT (Footwear brands)
  // =========================================================================
  Widget _buildBrandManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('5. Footwear Brands Management', 'Manage OEM brand contracts, distributor agreements, official warranty policies and brand-wise sales shares.'),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Authorized Footwear Brands in Catalog', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _brandRow('Nike', 'Global Sports & Lifestyle', 'Air Max, Pegasus, Revolution, Court Vision', '₹ 1,42,000 Sales', Colors.black),
                  _brandRow('Adidas', 'Running & Originals', 'Ultraboost, Stan Smith, Supernova, Gazelle', '₹ 98,500 Sales', Colors.indigo),
                  _brandRow('Puma', 'Sportstyle & Casuals', 'Smash V2, RS-X, Nitro, Softride', '₹ 64,200 Sales', Colors.red),
                  _brandRow('Bata', 'Formal & Everyday Durability', 'Hush Puppies, Power, Comfit, Ambassador', '₹ 58,900 Sales', Colors.red.shade900),
                  _brandRow('Woodland', 'Rugged Leather Boots', 'Trekker, Oiled Leather, Khaki Explorer', '₹ 45,600 Sales', Colors.brown),
                  _brandRow('Campus', 'Accessible Youth Sneakers', 'Oxyfit, Camp-Dragon, King, Maxima', '₹ 38,400 Sales', Colors.blue),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 6. PRODUCT MANAGEMENT (Products, sizes, colors, images)
  // =========================================================================
  Widget _buildProductManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('6. Footwear Product & Variant Catalog', 'Manage shoe models, SKU identifiers, size matrices (UK 6 to 11), color swatches, MRP, HSN 6404, and images.'),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Shoe Catalog Products', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      ElevatedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.add_box, size: 14),
                        label: const Text('Add Shoe Model'),
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                      )
                    ],
                  ),
                  const Divider(height: 20),
                  _productVariantTable('Nike Air Max 270 Flyknit', 'Sneakers', 'UK 7, 8, 9, 10', 'Pure White, Black', '₹ 8,995', '₹ 11,995', '24 Pairs'),
                  _productVariantTable('Adidas Ultraboost Light', 'Running', 'UK 8, 9, 10', 'Core Black, Solar Red', '₹ 9,499', '₹ 12,999', '15 Pairs'),
                  _productVariantTable('Puma Smash V2 Leather', 'Casual', 'UK 6, 7, 8, 9', 'Navy Blue, Classic White', '₹ 2,799', '₹ 3,999', '5 Pairs'),
                  _productVariantTable('Bata Formal Derby Classic', 'Formal', 'UK 7, 8, 9, 10, 11', 'Oxford Tan, Jet Black', '₹ 2,499', '₹ 3,299', '22 Pairs'),
                  _productVariantTable('Woodland Waterproof Trekker', 'Outdoor', 'UK 8, 9', 'Olive Khaki, Dark Brown', '₹ 4,695', '₹ 5,995', '0 (Out)'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 7. BARCODE MANAGEMENT (Generate and print barcodes)
  // =========================================================================
  Widget _buildBarcodeManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('7. Footwear Barcode & Shoe Box Labeling', 'Generate standard Code-128 and EAN-13 barcodes per variant (Size + Color SKU) and print adhesive thermal box stickers.'),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Barcodes Generated', '4,280 Labels', Icons.qr_code, const Color(0xFF4F46E5), 'EAN-13 & Code 128'),
            _metricItem('Thermal Printers', '4 Connected', Icons.print, Colors.teal, 'TVS & Zebra Printers'),
            _metricItem('Label Size', '50mm x 25mm', Icons.label, Colors.indigo, 'Standard Shoe Box Tag'),
            _metricItem('Scan Accuracy', '100% Verified', Icons.check_circle, Colors.green, 'Zero POS scanning errors'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Sample Generated Barcode Stickers', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _barcodeStickerRow('8901234567890', 'NK-AM270-WHT-9', 'Nike Air Max 270 Flyknit', 'Size: UK 9 • Color: Pure White', '₹ 8,995.00'),
                  const Divider(),
                  _barcodeStickerRow('8901234567891', 'AD-UBL-BLK-8', 'Adidas Ultraboost Light', 'Size: UK 8 • Color: Core Black', '₹ 9,499.00'),
                  const Divider(),
                  _barcodeStickerRow('8901234567892', 'BT-FRM-TAN-10', 'Bata Formal Derby Classic', 'Size: UK 10 • Color: Oxford Tan', '₹ 2,499.00'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 8. INVENTORY MANAGEMENT (Stock inward, outward, transfer)
  // =========================================================================
  Widget _buildInventoryManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('8. Footwear Inventory & Ledger', 'Track stock inward (GRN), outward sales dispatch, branch-to-branch transfers, damaged write-offs, and physical audits.'),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Stock Inward Today', '180 Pairs', Icons.add_box, Colors.green, 'GRN #GRN-2026-088'),
            _metricItem('Outward Dispatched', '64 Pairs', Icons.outbox, const Color(0xFF4F46E5), 'Counter sales + Courier'),
            _metricItem('Branch Transfers', '2 In Transit', Icons.move_up, Colors.orange, 'Flagship to Suburban'),
            _metricItem('Damaged / Write-off', '3 Pairs', Icons.broken_image, Colors.red, 'Factory sole tear'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Recent Stock Movement Ledger', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _stockLedgerRow('INWARD (GRN)', 'Nike Air Max (UK 8, 9, 10)', '+40 Pairs', 'Nike India Consignment #PO-882', Colors.green),
                  _stockLedgerRow('OUTWARD (POS)', 'Bata Formal Derby (UK 9)', '-1 Pair', 'Invoice #KF-INV-88231', Colors.blue),
                  _stockLedgerRow('TRANSFER', 'Adidas Ultraboost (UK 8)', '12 Pairs', 'Pune Flagship → Mumbai Outlet', Colors.orange),
                  _stockLedgerRow('AUDIT ADJUST', 'Puma Smash V2 (UK 7)', '-1 Pair', 'Discrepancy reconciled', Colors.purple),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 9. POS BILLING (Sales, GST, discounts, invoices)
  // =========================================================================
  Widget _buildPosBillingModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('9. Fast POS Billing Counter', 'Instant barcode scanning, automated GST computation, split payments (Cash + UPI + Card), and thermal invoice generation.'),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Today POS Bills', '54 Invoices', Icons.receipt, const Color(0xFF4F46E5), 'Pune Flagship Counter 1'),
            _metricItem('Today Collection', '₹ 1,48,920', Icons.currency_rupee, Colors.green, 'Cash: ₹48K, UPI: ₹100K'),
            _metricItem('GST Collected', '₹ 15,955', Icons.calculate, Colors.teal, 'CGST 6% + SGST 6%'),
            _metricItem('Average Bill Time', '42 Seconds', Icons.timer, Colors.indigo, 'High floor throughput'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Active Shift Counter Status: OPEN', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.green)),
                  const SizedBox(height: 8),
                  const Text('Counter #1 • Cashier: Anita Deshmukh • Opening Float: ₹ 5,000.00 • Total Invoices: 54'),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.point_of_sale),
                    label: const Text('Open Fullscreen POS Billing Window'),
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 10. PURCHASE MANAGEMENT (Suppliers, purchase orders, GRN)
  // =========================================================================
  Widget _buildPurchaseManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('10. Purchase Management & Procurement', 'Create and track Purchase Orders (PO), receive shipments via Goods Receipt Notes (GRN), and reconcile bills.'),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Recent Purchase Orders & GRN Consignments', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _poRow('PO-2026-088', 'Nike India Wholesale Ltd.', '180 Pairs (Sports & Sneakers)', '₹ 1,42,000', 'GRN_RECEIVED', Colors.green),
                  _poRow('PO-2026-087', 'Metro Leather Goods Traders', '140 Pairs (Formal Derby & Boots)', '₹ 85,400', 'IN_TRANSIT', Colors.orange),
                  _poRow('PO-2026-086', 'Crocs Regional Logistics', '95 Pairs (Clogs & Slides)', '₹ 58,000', 'SETTLED', Colors.green),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 11. CUSTOMER MANAGEMENT (Customer details and history)
  // =========================================================================
  Widget _buildCustomerManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('11. Customer Relationship Management (CRM)', 'Manage customer directory, shoe size preferences, total spend, loyalty points, and store credit ledgers.'),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Registered Loyalty Customer Profiles', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _customerRow('Rahul Sharma', '+91 98765 43210', 'Size: UK 9 • Brand: Nike', '₹ 24,990', '240 Pts'),
                  _customerRow('Pooja Verma', '+91 98221 55443', 'Size: UK 6 • Brand: Puma', '₹ 14,200', '180 Pts'),
                  _customerRow('Amit Saxena', '+91 94230 11998', 'Size: UK 10 • Brand: Woodland', '₹ 38,500', '520 Pts'),
                  _customerRow('Sneha Patil', '+91 91234 56789', 'Size: UK 5 • Brand: Bata', '₹ 6,800', '95 Pts'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 12. SUPPLIER MANAGEMENT (Supplier details and payments)
  // =========================================================================
  Widget _buildSupplierManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('12. Supplier Master & Payables', 'Manage footwear manufacturer profiles, GSTIN, bank details, credit terms, and record payment disbursements.'),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Wholesale Suppliers & Creditors', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _supplierRow('Nike India Wholesale Ltd.', 'GSTIN: 27AAACN1234F1Z9', 'Due: ₹ 0.00 (All Clear)', Colors.green),
                  _supplierRow('Metro Leather Goods Traders', 'GSTIN: 24BBBML5678G2Z3', 'Due: ₹ 45,000.00 (Due in 2 days)', Colors.red),
                  _supplierRow('Crocs Brand Regional Logistics', 'GSTIN: 29CCDCB9012H3Z1', 'Due: ₹ 0.00 (All Clear)', Colors.green),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 13. SALES MANAGEMENT (Sales history and invoices)
  // =========================================================================
  Widget _buildSalesManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('13. Sales History & Invoicing Archive', 'Audit sales invoices, payment modes, GST breakdown, clerk handoff, and print duplicate receipts.'),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Latest Counter & Online Sales Invoices', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _invoiceRow('KF-INV-20261112-001', 'Rahul Sharma', 'Nike Air Max 270 (UK 9)', '₹ 8,995', 'UPI', 'BILLED'),
                  _invoiceRow('KF-INV-20261112-002', 'Pooja Verma', 'Puma Smash V2 (UK 6)', '₹ 2,799', 'CASH', 'BILLED'),
                  _invoiceRow('KF-INV-20261112-003', 'Walk-in Buyer', 'Bata Formal Derby (UK 10)', '₹ 2,499', 'CARD', 'BILLED'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 14. RETURN MANAGEMENT (Sales returns and exchanges)
  // =========================================================================
  Widget _buildReturnManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('14. Returns & Footwear Size/Color Exchanges', 'Process 7-day footwear returns, size replacements, color swaps, and issue credit notes or supplier debit notes.'),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Active Returns & Exchanges Log', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _exchangeRow('EXCH-2026-014', 'Amit Saxena', 'Nike Air Max 270', 'UK 8 swapped to UK 9', 'COMPLETED', Colors.green),
                  _exchangeRow('EXCH-2026-015', 'Sunita Rao', 'Puma Smash V2', 'Black swapped to Navy Blue', 'COMPLETED', Colors.green),
                  _exchangeRow('RET-2026-008', 'Karan Mehra', 'Bata Formal Derby', 'Refund: ₹ 2,499 (Sole defect)', 'REFUNDED', Colors.teal),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 15. EXPENSE MANAGEMENT (Business expenses)
  // =========================================================================
  Widget _buildExpenseManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('15. Store Operating Expense Management', 'Track operational outlays: showroom rent, electricity, packaging boxes, courier logistics, and tea/hospitality.'),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Month Expenses', '₹ 48,720', Icons.account_balance_wallet, Colors.orange, 'November 2026'),
            _metricItem('Showroom Rent', '₹ 32,000', Icons.home_work, Colors.blue, 'MG Road Showroom'),
            _metricItem('Electricity & AC', '₹ 6,450', Icons.bolt, Colors.amber.shade900, 'Power consumption'),
            _metricItem('Packaging & Boxes', '₹ 4,200', Icons.inventory, Colors.teal, 'Branded carry bags'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Expense Voucher History', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _expenseRow('EXP-2026-084', 'Showroom Monthly Rent (MG Road)', '₹ 32,000', 'Bank Transfer', '01 Nov 2026'),
                  _expenseRow('EXP-2026-085', 'MSEB Electricity Bill', '₹ 6,450', 'UPI Online', '05 Nov 2026'),
                  _expenseRow('EXP-2026-086', 'Custom Printed Shoe Boxes (500 units)', '₹ 4,200', 'Cash', '08 Nov 2026'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 16. ACCOUNTS MANAGEMENT (Cashbook, payments, outstanding)
  // =========================================================================
  Widget _buildAccountsManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('16. Accounts, Cashbook & Customer Credit', 'Daily cashbook, bank reconciliation, UPI merchant settlements, and customer credit ledger tracking.'),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Physical Cash in Hand', '₹ 48,500', Icons.payments, Colors.green, 'Store Safe Float'),
            _metricItem('Bank Account Balance', '₹ 3,42,800', Icons.account_balance, const Color(0xFF4F46E5), 'HDFC Current A/C'),
            _metricItem('Customer Credit Due', '₹ 14,800', Icons.credit_score, Colors.orange, '4 Customers outstanding'),
            _metricItem('Supplier Dues', '₹ 45,000', Icons.pending_actions, Colors.red, 'Metro Traders due'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Daily Cashbook Balance Ledger', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _cashbookRow('12 Nov 2026', 'Opening Cash Balance', '+₹ 5,000.00', Colors.grey.shade700),
                  _cashbookRow('12 Nov 2026', 'Counter 1 Sales Cash Collected', '+₹ 48,920.00', Colors.green),
                  _cashbookRow('12 Nov 2026', 'Packaging Cash Expense Out', '-₹ 4,200.00', Colors.red),
                  _cashbookRow('12 Nov 2026', 'Closing Physical Cash in Safe', '₹ 49,720.00', Colors.indigo, isBold: true),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 17. EMPLOYEE MANAGEMENT (Employees, attendance, salary)
  // =========================================================================
  Widget _buildEmployeeManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('17. Staff Directory, Attendance & Payroll', 'Maintain staff records, biometric attendance logs, monthly salary disbursements, and sales executive incentive commissions.'),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Showroom Staff & Payroll Summary', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _employeeRow('Sunil Patil', 'Store Manager', 'Present (12/12 days)', 'Salary: ₹ 35,000', 'PAID'),
                  _employeeRow('Anita Deshmukh', 'Cashier', 'Present (12/12 days)', 'Salary: ₹ 22,000', 'PAID'),
                  _employeeRow('Vikram Shinde', 'Inventory Manager', 'Present (11/12 days)', 'Salary: ₹ 26,000', 'PAID'),
                  _employeeRow('Rahul Joshi', 'Sales Executive', 'Present (12/12 days)', 'Salary: ₹ 18,000 + ₹ 2,862 Comm', 'PAID'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 18. OFFER MANAGEMENT (Coupons and discounts)
  // =========================================================================
  Widget _buildOfferManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('18. Coupons, Discounts & Promotional Offers', 'Configure percentage coupons (e.g. FESTIVE10), clearance sales, festival campaigns, and minimum purchase thresholds.'),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Active Promotional Campaigns', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _offerRow('FESTIVE10', 'Flat 10% Off on all sneakers & running shoes', 'Min Spend: ₹ 1,999', 'ACTIVE', Colors.green),
                  _offerRow('KHUSHI500', 'Flat 15% Off festive wedding footwear collection', 'Min Spend: ₹ 4,999', 'ACTIVE', Colors.green),
                  _offerRow('CLEARANCE40', 'Clearance 40% Off on last year footwear styles', 'Select SKUs', 'ACTIVE', Colors.orange),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 19. REPORTS (Sales, purchases, stock, GST, profit)
  // =========================================================================
  Widget _buildReportsModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('19. Enterprise Analytics & Financial Reports', 'Comprehensive reporting suite with 23 reports: Daily Sales, GST GSTR-3B, Stock Aging, Profit & Loss, and Fast-Moving Sizes.'),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Sales Report', '₹ 4,58,920', Icons.analytics, Colors.green, 'Export PDF / Excel'),
            _metricItem('Purchase Report', '₹ 2,85,400', Icons.receipt_long, const Color(0xFF4F46E5), '48 Consignments'),
            _metricItem('GST GSTR-3B', '₹ 15,955 Tax', Icons.calculate, Colors.teal, 'Ready for filing'),
            _metricItem('Net P&L Margin', '27.2%', Icons.pie_chart, Colors.indigo, 'Healthy profitability'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Download Operational & Tax Reports', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _reportDownloadRow('Daily Sales Summary Report (Counter + E-Commerce)', 'Format: Excel / PDF'),
                  _reportDownloadRow('Footwear Stock Ageing & Slow-Moving Sizes Report', 'Format: Excel / PDF'),
                  _reportDownloadRow('GST Sales & Input Tax Credit (ITC) Report (HSN 6404)', 'Format: JSON / Excel'),
                  _reportDownloadRow('Consolidated Profit & Loss (P&L) Statement', 'Format: PDF'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 20. NOTIFICATION MANAGEMENT (Stock alerts and payment reminders)
  // =========================================================================
  Widget _buildNotificationManagementModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('20. Notification Management & Live Alerts', 'Automated system triggers: critical stock-out alerts, low size thresholds, due supplier invoices, and customer credit reminders.'),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Critical Stock Alerts', '1 Model Out', Icons.warning_amber, Colors.red, 'Woodland Trekker UK 8'),
            _metricItem('Low Stock Warnings', '1 Model Low', Icons.report_problem, Colors.orange, 'Puma Smash V2 (2 pairs)'),
            _metricItem('Supplier Reminders', '1 Due Soon', Icons.pending_actions, Colors.blue, 'Metro Traders (₹42.5K)'),
            _metricItem('Customer Credit Alert', '1 Customer Due', Icons.schedule, Colors.teal, 'Amit Saxena (₹3.4K)'),
          ]),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Live Notification Broadcast Feed', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _notificationRow('Critical Stock-Out Alert', 'Woodland High Ankle Trekking Boots (UK 8 - Khaki) is completely OUT OF STOCK! Stock inward GRN required.', 'CRITICAL', Colors.red),
                  _notificationRow('Low Stock Threshold Alert', 'Puma Smash V2 Leather (UK 7 - Navy Blue) has only 2 pairs left in showroom rack (Min Alert: 5 pairs).', 'WARNING', Colors.orange),
                  _notificationRow('Supplier Payment Due Reminder', 'Payment of ₹ 42,500 to Metro Footwear Distributors is due on 14 Nov 2026.', 'WARNING', Colors.orange),
                  _notificationRow('Customer Credit Due Alert', 'Amit Saxena has pending store credit balance of ₹ 3,450 for over 15 days.', 'INFO', Colors.blue),
                  _notificationRow('Online Order Dispatched', 'Order #ORD-ONL-20261112 has been handed over to Delhivery Express courier rider.', 'SUCCESS', Colors.green),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 21. SETTINGS (Shop, tax, invoice and system settings)
  // =========================================================================
  Widget _buildSettingsModule() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _moduleHeader('21. System, Tax, Invoice & Shop Settings', 'Configure enterprise metadata, GST rate slabs for footwear, thermal invoice header/footer, WhatsApp bill dispatch, and backup schedules.'),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Configured Enterprise Settings', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _settingItem('Shop Legal Name', 'Khushi Footwear Private Limited'),
                  _settingItem('GSTIN Identification', '27AABCK1234F1Z9 (Maharashtra State)'),
                  _settingItem('Footwear Tax Slabs', 'CGST 6% + SGST 6% (Total 12% on Footwear above ₹1,000)'),
                  _settingItem('Invoice Numbering Prefix', 'KF-INV-2026-'),
                  _settingItem('Invoice Footer Note', 'Thank you for shopping at Khushi Footwear! Exchanges valid within 7 days with original shoebox.'),
                  _settingItem('WhatsApp Automated Billing', 'ENABLED (Auto-send PDF invoice via WhatsApp to customer mobile)'),
                  _settingItem('Thermal Printer Mode', 'ENABLED (80mm ESC/POS High-Speed Thermal Receipt)'),
                  _settingItem('Database Automated Backup', 'ENABLED (Daily Midnight Snapshot to Cloud Storage)'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // HELPER WIDGETS
  // =========================================================================
  Widget _moduleHeader(String title, String subtitle) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
        const SizedBox(height: 4),
        Text(subtitle, style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
      ],
    );
  }

  Widget _buildMetricsGrid(List<Widget> items) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final crossCount = widget.isDesktop ? 4 : 2;
        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: crossCount,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: widget.isDesktop ? 2.1 : 1.5,
          children: items,
        );
      },
    );
  }

  Widget _metricItem(String title, String val, IconData icon, Color color, String sub) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade200)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(child: Text(title, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey.shade600, fontSize: 11, fontWeight: FontWeight.bold))),
              CircleAvatar(backgroundColor: color.withValues(alpha: 0.12), radius: 14, child: Icon(icon, color: color, size: 16)),
            ],
          ),
          Text(val, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          Text(sub, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, color: Colors.grey.shade500)),
        ],
      ),
    );
  }

  Widget _sizeProgressRow(String title, double progress, String val) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title, style: const TextStyle(fontSize: 12)),
              Text(val, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
            ],
          ),
          const SizedBox(height: 4),
          LinearProgressIndicator(value: progress, minHeight: 6, borderRadius: BorderRadius.circular(3), color: const Color(0xFF4F46E5), backgroundColor: const Color(0xFFEEF2FF)),
        ],
      ),
    );
  }

  Widget _tableRow(String name, String role, String branch, String email, String status, Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text('$role • $branch', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(color: col.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)),
            child: Text(status, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 10)),
          ),
        ],
      ),
    );
  }

  Widget _branchRow(String name, String addr, String phone, String info) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              Text('$addr • $phone', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
            ],
          ),
          Text(info, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF4F46E5))),
        ],
      ),
    );
  }

  Widget _categoryRow(String name, String sub, String count) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              Text(sub, style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
            ],
          ),
          Text(count, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: Color(0xFF4F46E5))),
        ],
      ),
    );
  }

  Widget _brandRow(String name, String cat, String models, String sales, Color badgeCol) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              Text('$cat • $models', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
            ],
          ),
          Text(sales, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.green)),
        ],
      ),
    );
  }

  Widget _productVariantTable(String name, String cat, String sizes, String colors, String price, String mrp, String stock) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              Text('$cat • Sizes: $sizes • Colors: $colors', style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(price, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF4F46E5))),
              Text(stock, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: stock.contains('0') ? Colors.red : Colors.green)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _barcodeStickerRow(String barcode, String sku, String name, String spec, String price) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              const Icon(Icons.qr_code_2, size: 36, color: Color(0xFF4F46E5)),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  Text('$spec • SKU: $sku', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                  Text('Barcode: $barcode', style: const TextStyle(fontFamily: 'monospace', fontSize: 10, fontWeight: FontWeight.bold)),
                ],
              ),
            ],
          ),
          OutlinedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.print, size: 14),
            label: const Text('Print Label', style: TextStyle(fontSize: 11)),
          ),
        ],
      ),
    );
  }

  Widget _stockLedgerRow(String type, String item, String qty, String ref, Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(item, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text(ref, style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
            ],
          ),
          Row(
            children: [
              Text(qty, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: col)),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(color: col.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)),
                child: Text(type, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 9)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _poRow(String poNo, String supplier, String items, String amount, String status, Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$poNo: $supplier', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text(items, style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
            ],
          ),
          Row(
            children: [
              Text(amount, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF4F46E5))),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(color: col.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)),
                child: Text(status, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 9)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _customerRow(String name, String phone, String pref, String spend, String pts) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text('$phone • $pref', style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('Spend: $spend', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: Color(0xFF4F46E5))),
              Text(pts, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10, color: Colors.amber.shade900)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _supplierRow(String name, String gst, String due, Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text(gst, style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
            ],
          ),
          Text(due, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: col)),
        ],
      ),
    );
  }

  Widget _invoiceRow(String inv, String cust, String item, String total, String mode, String status) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$inv • $cust', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text('$item • Mode: $mode', style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
            ],
          ),
          Text(total, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Color(0xFF4F46E5))),
        ],
      ),
    );
  }

  Widget _exchangeRow(String id, String cust, String shoe, String action, String status, Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$id • $cust', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text('$shoe • $action', style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(color: col.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)),
            child: Text(status, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 9)),
          ),
        ],
      ),
    );
  }

  Widget _expenseRow(String id, String desc, String amt, String mode, String date) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$id • $desc', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text('$date • Paid via $mode', style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
            ],
          ),
          Text(amt, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.orange)),
        ],
      ),
    );
  }

  Widget _cashbookRow(String date, String desc, String amt, Color col, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(desc, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.w500, fontSize: 12)),
              Text(date, style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
            ],
          ),
          Text(amt, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: col)),
        ],
      ),
    );
  }

  Widget _employeeRow(String name, String role, String attend, String salary, String status) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text('$role • $attend', style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
            ],
          ),
          Text(salary, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: Colors.green)),
        ],
      ),
    );
  }

  Widget _offerRow(String code, String desc, String minSpend, String status, Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Coupon: $code', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF4F46E5))),
              Text('$desc • $minSpend', style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(color: col.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)),
            child: Text(status, style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 9)),
          ),
        ],
      ),
    );
  }

  Widget _reportDownloadRow(String title, String format) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              Text(format, style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
            ],
          ),
          OutlinedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.download, size: 14),
            label: const Text('Export', style: TextStyle(fontSize: 11)),
          ),
        ],
      ),
    );
  }

  Widget _notificationRow(String title, String msg, String type, Color col) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            backgroundColor: col.withValues(alpha: 0.1),
            radius: 14,
            child: Icon(type == 'CRITICAL' ? Icons.error : (type == 'WARNING' ? Icons.warning : Icons.check_circle), color: col, size: 16),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: col)),
                Text(msg, style: TextStyle(color: Colors.grey.shade700, fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _settingItem(String key, String val) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(key, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
          const SizedBox(width: 16),
          Flexible(
            child: Text(val, textAlign: TextAlign.right, style: TextStyle(color: Colors.grey.shade700, fontSize: 11)),
          ),
        ],
      ),
    );
  }
}

