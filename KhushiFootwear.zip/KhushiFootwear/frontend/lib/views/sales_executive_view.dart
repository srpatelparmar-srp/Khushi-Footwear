import 'package:flutter/material.dart';

class SalesExecutiveView extends StatefulWidget {
  final bool isDesktop;
  final int activeModule;

  const SalesExecutiveView({
    super.key,
    required this.isDesktop,
    required this.activeModule,
  });

  @override
  State<SalesExecutiveView> createState() => _SalesExecutiveViewState();
}

class _SalesExecutiveViewState extends State<SalesExecutiveView> {
  // --- STATE DATA ---
  String _productSearchQuery = '';
  String _selectedCategoryFilter = 'All';
  String _customerSearchQuery = '';
  String _enquiryFilterStatus = 'All';

  // Sample Customers
  final List<Map<String, dynamic>> _customers = [
    {
      'id': 1,
      'name': 'Rahul Sharma',
      'mobile': '+91 98765 43210',
      'email': 'rahul.sharma@gmail.com',
      'preferredSize': 'UK 9',
      'preferredBrand': 'Nike',
      'loyaltyPoints': 240,
      'totalSpent': '₹ 24,990',
      'totalVisits': 6,
      'lastVisit': '08 Nov 2026',
    },
    {
      'id': 2,
      'name': 'Pooja Verma',
      'mobile': '+91 98221 55443',
      'email': 'pooja.v@outlook.com',
      'preferredSize': 'UK 6',
      'preferredBrand': 'Puma',
      'loyaltyPoints': 180,
      'totalSpent': '₹ 14,200',
      'totalVisits': 4,
      'lastVisit': '04 Nov 2026',
    },
    {
      'id': 3,
      'name': 'Amit Saxena',
      'mobile': '+91 94230 11998',
      'email': 'amit.saxena@yahoo.com',
      'preferredSize': 'UK 10',
      'preferredBrand': 'Woodland',
      'loyaltyPoints': 520,
      'totalSpent': '₹ 38,500',
      'totalVisits': 9,
      'lastVisit': '11 Nov 2026',
    },
    {
      'id': 4,
      'name': 'Sneha Patil',
      'mobile': '+91 91234 56789',
      'email': 'sneha.patil@gmail.com',
      'preferredSize': 'UK 5',
      'preferredBrand': 'Bata',
      'loyaltyPoints': 95,
      'totalSpent': '₹ 6,800',
      'totalVisits': 2,
      'lastVisit': '02 Nov 2026',
    },
  ];

  // Sample Footwear Products with Sizes & Colors
  final List<Map<String, dynamic>> _footwearCatalog = [
    {
      'id': 101,
      'name': 'Nike Air Max 270 Flyknit',
      'articleNo': 'NK-AM270-WHT',
      'brand': 'Nike',
      'category': 'Sports',
      'price': 8995.0,
      'mrp': 11995.0,
      'totalStock': 24,
      'status': 'IN_STOCK',
      'variants': [
        {'size': 'UK 7', 'color': 'Pure White', 'colorHex': 0xFFFFFFFF, 'stock': 4, 'sku': 'NK-7-WHT'},
        {'size': 'UK 8', 'color': 'Pure White', 'colorHex': 0xFFFFFFFF, 'stock': 8, 'sku': 'NK-8-WHT'},
        {'size': 'UK 9', 'color': 'Pure White', 'colorHex': 0xFFFFFFFF, 'stock': 6, 'sku': 'NK-9-WHT'},
        {'size': 'UK 9', 'color': 'Triple Black', 'colorHex': 0xFF1E1E1E, 'stock': 4, 'sku': 'NK-9-BLK'},
        {'size': 'UK 10', 'color': 'Royal Blue', 'colorHex': 0xFF2563EB, 'stock': 2, 'sku': 'NK-10-BLU'},
      ]
    },
    {
      'id': 102,
      'name': 'Adidas Ultraboost Light',
      'articleNo': 'AD-UBL-BLK',
      'brand': 'Adidas',
      'category': 'Running',
      'price': 9499.0,
      'mrp': 12999.0,
      'totalStock': 15,
      'status': 'IN_STOCK',
      'variants': [
        {'size': 'UK 7', 'color': 'Core Black', 'colorHex': 0xFF111827, 'stock': 3, 'sku': 'AD-7-BLK'},
        {'size': 'UK 8', 'color': 'Core Black', 'colorHex': 0xFF111827, 'stock': 5, 'sku': 'AD-8-BLK'},
        {'size': 'UK 9', 'color': 'Solar Red', 'colorHex': 0xFFEF4444, 'stock': 4, 'sku': 'AD-9-RED'},
        {'size': 'UK 10', 'color': 'Core Black', 'colorHex': 0xFF111827, 'stock': 3, 'sku': 'AD-10-BLK'},
      ]
    },
    {
      'id': 103,
      'name': 'Puma Smash V2 Leather Sneaker',
      'articleNo': 'PM-SMV2-NVY',
      'brand': 'Puma',
      'category': 'Casual',
      'price': 2799.0,
      'mrp': 3999.0,
      'totalStock': 5,
      'status': 'LOW_STOCK',
      'variants': [
        {'size': 'UK 7', 'color': 'Navy Blue', 'colorHex': 0xFF1E3A8A, 'stock': 2, 'sku': 'PM-7-NVY'},
        {'size': 'UK 8', 'color': 'Classic White', 'colorHex': 0xFFF3F4F6, 'stock': 2, 'sku': 'PM-8-WHT'},
        {'size': 'UK 9', 'color': 'Navy Blue', 'colorHex': 0xFF1E3A8A, 'stock': 1, 'sku': 'PM-9-NVY'},
      ]
    },
    {
      'id': 104,
      'name': 'Bata Formal Derby Classic',
      'articleNo': 'BT-FRM-TAN',
      'brand': 'Bata',
      'category': 'Formal',
      'price': 2499.0,
      'mrp': 3299.0,
      'totalStock': 22,
      'status': 'IN_STOCK',
      'variants': [
        {'size': 'UK 7', 'color': 'Oxford Tan', 'colorHex': 0xFF92400E, 'stock': 6, 'sku': 'BT-7-TAN'},
        {'size': 'UK 8', 'color': 'Oxford Tan', 'colorHex': 0xFF92400E, 'stock': 6, 'sku': 'BT-8-TAN'},
        {'size': 'UK 9', 'color': 'Jet Black', 'colorHex': 0xFF000000, 'stock': 5, 'sku': 'BT-9-BLK'},
        {'size': 'UK 10', 'color': 'Oxford Tan', 'colorHex': 0xFF92400E, 'stock': 5, 'sku': 'BT-10-TAN'},
      ]
    },
    {
      'id': 105,
      'name': 'Woodland High Ankle Trekking Boots',
      'articleNo': 'WD-TRK-KHK',
      'brand': 'Woodland',
      'category': 'Outdoor',
      'price': 4695.0,
      'mrp': 5995.0,
      'totalStock': 0,
      'status': 'OUT_OF_STOCK',
      'variants': [
        {'size': 'UK 8', 'color': 'Olive Khaki', 'colorHex': 0xFF4D7C0F, 'stock': 0, 'sku': 'WD-8-KHK'},
        {'size': 'UK 9', 'color': 'Dark Brown', 'colorHex': 0xFF78350F, 'stock': 0, 'sku': 'WD-9-BRN'},
      ]
    },
  ];

  // Sample Customer Enquiries
  final List<Map<String, dynamic>> _enquiries = [
    {
      'id': 1,
      'customer': 'Rahul Sharma',
      'phone': '+91 98765 43210',
      'item': 'Nike Air Max 270 (UK 9 - Pure White)',
      'status': 'FOLLOWED_UP',
      'followUpDate': '14 Nov 2026',
      'notes': 'Requested reminder when next fresh batch arrives.',
    },
    {
      'id': 2,
      'customer': 'Deepak Verma',
      'phone': '+91 98221 11223',
      'item': 'Woodland High Ankle Boots (UK 8 - Olive Khaki)',
      'status': 'OPEN',
      'followUpDate': 'Today',
      'notes': 'Looking for trekking trip next weekend. Need notification on restock.',
    },
    {
      'id': 3,
      'customer': 'Neha Kulkarni',
      'phone': '+91 94230 44556',
      'item': 'Puma High Tops (UK 6 - Pink/White)',
      'status': 'CONVERTED',
      'followUpDate': 'Completed',
      'notes': 'Customer visited store, billed ₹ 3,499 via assisted order.',
    },
    {
      'id': 4,
      'customer': 'Manish Joshi',
      'phone': '+91 97654 32109',
      'item': 'Bata Formal Derby Classic (UK 9 - Tan)',
      'status': 'OPEN',
      'followUpDate': '15 Nov 2026',
      'notes': 'Wedding reception footwear inquiry.',
    },
  ];

  // Sample Assisted Sales Orders
  final List<Map<String, dynamic>> _salesOrders = [
    {
      'orderNo': 'SO-EX-202611-001',
      'customer': 'Amit Saxena',
      'phone': '+91 94230 11998',
      'items': 'Nike Air Max (UK 9) + Sneaker Pro Shield Spray',
      'qty': 2,
      'amount': '₹ 9,494',
      'status': 'READY_FOR_CASHIER',
      'time': '10 mins ago',
    },
    {
      'orderNo': 'SO-EX-202611-002',
      'customer': 'Pooja Verma',
      'phone': '+91 98221 55443',
      'items': 'Puma Smash V2 (UK 6) + 2x Cushion Socks',
      'qty': 3,
      'amount': '₹ 3,297',
      'status': 'READY_FOR_CASHIER',
      'time': '25 mins ago',
    },
    {
      'orderNo': 'SO-EX-202611-003',
      'customer': 'Karan Mehra',
      'phone': '+91 99887 76655',
      'items': 'Bata Formal Derby (UK 10) + Premium Wax',
      'qty': 2,
      'amount': '₹ 2,799',
      'status': 'BILLED_AT_COUNTER',
      'time': '1 hr ago',
    },
  ];

  // Sample Recommendations
  final List<Map<String, dynamic>> _recommendations = [
    {
      'title': 'Top Festive Wedding Pick',
      'product': 'Bata Formal Derby Classic - Oxford Tan',
      'reason': 'High demand with 4.9★ rating. Matches traditional & formal suits.',
      'deal': 'Flat 20% Off + Free Shoe Polish with every pair',
      'badge': 'Festive Trending',
      'color': Colors.amber.shade900,
    },
    {
      'title': 'Best Running Cushion',
      'product': 'Adidas Ultraboost Light - Core Black',
      'reason': 'Energy return boost sole, lightweight, recommended for marathoners.',
      'deal': 'Complementary 2-Pack Performance Running Socks',
      'badge': 'Staff Recommendation',
      'color': const Color(0xFF4F46E5),
    },
    {
      'title': 'High Margin Cross-Sell',
      'product': 'Sneaker Shield Nano Waterproofer & Deodorizer',
      'reason': 'Recommended for all leather and mesh sneakers at billing counter.',
      'deal': 'Combo Price ₹ 499 (MRP ₹ 799) when bought with shoes',
      'badge': 'Upsell Essential',
      'color': Colors.teal,
    },
  ];

  @override
  Widget build(BuildContext context) {
    switch (widget.activeModule) {
      case 0:
        return _buildFootwearCatalogAndAvailability();
      case 1:
        return _buildCustomerManagement();
      case 2:
        return _buildCustomerEnquiriesAndFollowups();
      case 3:
        return _buildSalesOrderAssistance();
      case 4:
        return _buildProductRecommendations();
      case 5:
        return _buildPersonalTargetsAndCommission();
      default:
        return _buildFootwearCatalogAndAvailability();
    }
  }

  // =========================================================================
  // 1. FOOTWEAR CATALOG, SEARCH, PRODUCT AVAILABILITY, SIZES & COLORS
  // =========================================================================
  Widget _buildFootwearCatalogAndAvailability() {
    final filtered = _footwearCatalog.where((item) {
      final matchesQuery = _productSearchQuery.isEmpty ||
          item['name'].toString().toLowerCase().contains(_productSearchQuery.toLowerCase()) ||
          item['brand'].toString().toLowerCase().contains(_productSearchQuery.toLowerCase()) ||
          item['articleNo'].toString().toLowerCase().contains(_productSearchQuery.toLowerCase());
      final matchesCategory = _selectedCategoryFilter == 'All' || item['category'] == _selectedCategoryFilter;
      return matchesQuery && matchesCategory;
    }).toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Footwear Catalog & Size/Color Availability', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('Search models, inspect stock availability, and check shoe size and color combinations', style: TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  OutlinedButton.icon(
                    onPressed: () => _showAddCustomerDialog(),
                    icon: const Icon(Icons.person_add, size: 16),
                    label: const Text('New Customer'),
                    style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF4F46E5)),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton.icon(
                    onPressed: () => _showCreateOrderDialog(),
                    icon: const Icon(Icons.add_shopping_cart, size: 16),
                    label: const Text('Create Order'),
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                  ),
                ],
              )
            ],
          ),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Catalog Models', '${_footwearCatalog.length} Styles', Icons.snowshoeing, const Color(0xFF4F46E5), 'Sports, Casual, Formal'),
            _metricItem('In Stock', '4 Active Lines', Icons.check_circle_outline, Colors.green, 'Ready for instant trial'),
            _metricItem('Low Stock Alert', '1 Model', Icons.warning_amber_rounded, Colors.orange, 'Under 5 pairs remaining'),
            _metricItem('Out of Stock', '1 Model', Icons.highlight_off, Colors.redAccent, 'Trekking boot awaiting GRN'),
          ]),
          const SizedBox(height: 16),

          // Search and Filter Bar
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      decoration: const InputDecoration(
                        hintText: 'Search footwear by name, article number (e.g. NK-AM270), or brand...',
                        prefixIcon: Icon(Icons.search, size: 20, color: Colors.grey),
                        isDense: true,
                        border: InputBorder.none,
                      ),
                      onChanged: (val) => setState(() => _productSearchQuery = val),
                    ),
                  ),
                  const VerticalDivider(width: 20),
                  DropdownButton<String>(
                    value: _selectedCategoryFilter,
                    underline: const SizedBox(),
                    items: ['All', 'Sports', 'Running', 'Casual', 'Formal', 'Outdoor']
                        .map((c) => DropdownMenuItem(value: c, child: Text(c, style: const TextStyle(fontSize: 12))))
                        .toList(),
                    onChanged: (val) => setState(() => _selectedCategoryFilter = val ?? 'All'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Product List with Size & Color Cards
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: filtered.length,
            itemBuilder: (context, idx) {
              final product = filtered[idx];
              final stockColor = product['status'] == 'IN_STOCK'
                  ? Colors.green
                  : (product['status'] == 'LOW_STOCK' ? Colors.orange : Colors.redAccent);
              final statusText = product['status'] == 'IN_STOCK'
                  ? 'In Stock (${product['totalStock']} pairs)'
                  : (product['status'] == 'LOW_STOCK' ? 'Low Stock (${product['totalStock']} left)' : 'Out of Stock');

              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: Colors.grey.shade200),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(product['name'], style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 2),
                              Text('${product['brand']} • ${product['category']} • Article: ${product['articleNo']}',
                                  style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text('₹ ${product['price'].toStringAsFixed(0)}',
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF4F46E5))),
                              Text('MRP ₹ ${product['mrp'].toStringAsFixed(0)}',
                                  style: TextStyle(decoration: TextDecoration.lineThrough, color: Colors.grey.shade500, fontSize: 11)),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(color: stockColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(6)),
                            child: Text(statusText, style: TextStyle(color: stockColor, fontWeight: FontWeight.bold, fontSize: 11)),
                          ),
                          const Spacer(),
                          TextButton.icon(
                            onPressed: () => _showVariantDetailsSheet(product),
                            icon: const Icon(Icons.straighten, size: 14),
                            label: const Text('View All Sizes & Colors', style: TextStyle(fontSize: 12)),
                          )
                        ],
                      ),
                      const Divider(height: 20),

                      // Sizes & Colors Quick Swatches
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: (product['variants'] as List<dynamic>).map((v) {
                          final vStock = v['stock'] as int;
                          final vColor = Color(v['colorHex'] as int);
                          final isAvailable = vStock > 0;

                          return Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: isAvailable ? const Color(0xFFF8FAFC) : Colors.red.shade50,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: isAvailable ? Colors.grey.shade300 : Colors.red.shade200),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 12,
                                  height: 12,
                                  decoration: BoxDecoration(
                                    color: vColor,
                                    shape: BoxShape.circle,
                                    border: Border.all(color: Colors.grey.shade400, width: 0.5),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text('${v['size']} (${v['color']})',
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                      color: isAvailable ? Colors.black87 : Colors.red.shade800,
                                    )),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: isAvailable ? Colors.green.shade50 : Colors.red.shade100,
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(
                                    isAvailable ? '$vStock in stock' : 'Out',
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: isAvailable ? Colors.green.shade800 : Colors.red.shade900,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      )
                    ],
                  ),
                ),
              );
            },
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 2. REGISTER NEW CUSTOMERS & VIEW CUSTOMER DETAILS
  // =========================================================================
  Widget _buildCustomerManagement() {
    final filteredCustomers = _customers.where((c) {
      return _customerSearchQuery.isEmpty ||
          c['name'].toString().toLowerCase().contains(_customerSearchQuery.toLowerCase()) ||
          c['mobile'].toString().contains(_customerSearchQuery);
    }).toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Customer Registration & Profiles', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('Register walk-in buyers, view shoe sizes, purchase history, and loyalty point balances', style: TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
              ElevatedButton.icon(
                onPressed: () => _showAddCustomerDialog(),
                icon: const Icon(Icons.person_add_alt_1, size: 16),
                label: const Text('Register New Customer'),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
              )
            ],
          ),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Total Registered', '${_customers.length} Profiles', Icons.people, const Color(0xFF4F46E5), 'Loyalty members'),
            _metricItem('Active Walk-ins', '14 Today', Icons.directions_walk, Colors.teal, 'Floor visitors'),
            _metricItem('Avg Loyalty Points', '258 Pts', Icons.stars, Colors.amber.shade800, 'Redeemable on footwear'),
            _metricItem('Repeat Buyers', '68%', Icons.repeat, Colors.indigo, 'High brand affinity'),
          ]),
          const SizedBox(height: 16),

          // Search Customers
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                decoration: const InputDecoration(
                  hintText: 'Search customer by name or phone number...',
                  prefixIcon: Icon(Icons.search, size: 20, color: Colors.grey),
                  isDense: true,
                  border: InputBorder.none,
                ),
                onChanged: (val) => setState(() => _customerSearchQuery = val),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Customer Cards
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: filteredCustomers.length,
            itemBuilder: (context, idx) {
              final cust = filteredCustomers[idx];
              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 24,
                        backgroundColor: const Color(0xFF4F46E5).withValues(alpha: 0.1),
                        child: Text(
                          cust['name'].toString().substring(0, 1).toUpperCase(),
                          style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF4F46E5), fontSize: 18),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(cust['name'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(color: Colors.amber.shade50, borderRadius: BorderRadius.circular(4)),
                                  child: Text('${cust['loyaltyPoints']} Pts', style: TextStyle(color: Colors.amber.shade900, fontSize: 10, fontWeight: FontWeight.bold)),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text('${cust['mobile']} • ${cust['email']}', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                            const SizedBox(height: 4),
                            Text('Preferred Shoe Size: ${cust['preferredSize']} • Brand: ${cust['preferredBrand']} • Total Spend: ${cust['totalSpent']}',
                                style: TextStyle(color: Colors.grey.shade700, fontSize: 11, fontWeight: FontWeight.w500)),
                          ],
                        ),
                      ),
                      OutlinedButton(
                        onPressed: () => _showCustomerDetailsModal(cust),
                        child: const Text('View Details', style: TextStyle(fontSize: 12)),
                      )
                    ],
                  ),
                ),
              );
            },
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 3. MANAGE CUSTOMER ENQUIRIES & FOLLOW UP WITH CUSTOMERS
  // =========================================================================
  Widget _buildCustomerEnquiriesAndFollowups() {
    final filtered = _enquiries.where((e) {
      if (_enquiryFilterStatus == 'All') return true;
      return e['status'] == _enquiryFilterStatus;
    }).toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Customer Enquiries & Follow-up Tracker', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('Manage customer footwear requests, size reservations, and record follow-up call outcomes', style: TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
              ElevatedButton.icon(
                onPressed: () => _showAddEnquiryDialog(),
                icon: const Icon(Icons.add_comment, size: 16),
                label: const Text('New Enquiry'),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
              )
            ],
          ),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Active Enquiries', '${_enquiries.where((e) => e['status'] != 'CONVERTED').length} Leads', Icons.mark_chat_unread, Colors.orange, 'Action needed'),
            _metricItem('Converted to Sale', '1 Converted', Icons.check_circle, Colors.green, 'Assisted orders billed'),
            _metricItem('Due for Follow-up', '2 Today', Icons.phone_callback, Colors.indigo, 'WhatsApp / Call reminder'),
            _metricItem('Conversion Rate', '64.5%', Icons.trending_up, const Color(0xFF4F46E5), 'High floor conversion'),
          ]),
          const SizedBox(height: 16),

          // Status filter chips
          Row(
            children: ['All', 'OPEN', 'FOLLOWED_UP', 'CONVERTED'].map((status) {
              final isSel = _enquiryFilterStatus == status;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(status, style: TextStyle(fontSize: 11, fontWeight: isSel ? FontWeight.bold : FontWeight.normal)),
                  selected: isSel,
                  onSelected: (_) => setState(() => _enquiryFilterStatus = status),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 12),

          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: filtered.length,
            itemBuilder: (context, idx) {
              final enquiry = filtered[idx];
              final status = enquiry['status'];
              final statusColor = status == 'CONVERTED' ? Colors.green : (status == 'FOLLOWED_UP' ? Colors.teal : Colors.orange);

              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Text(enquiry['customer'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                              const SizedBox(width: 8),
                              Text('(${enquiry['phone']})', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(6)),
                            child: Text(status, style: TextStyle(color: statusColor, fontSize: 10, fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text('Footwear Requested: ${enquiry['item']}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12, color: Color(0xFF4F46E5))),
                      const SizedBox(height: 4),
                      Text('Notes: ${enquiry['notes']}', style: TextStyle(color: Colors.grey.shade700, fontSize: 11)),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Icon(Icons.calendar_today, size: 12, color: Colors.grey.shade600),
                          const SizedBox(width: 4),
                          Text('Follow-up Date: ${enquiry['followUpDate']}', style: TextStyle(fontSize: 11, color: Colors.grey.shade700)),
                          const Spacer(),
                          OutlinedButton.icon(
                            onPressed: () => _showFollowUpActionDialog(enquiry),
                            icon: const Icon(Icons.phone, size: 12),
                            label: const Text('Update Follow-up', style: TextStyle(fontSize: 11)),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton.icon(
                            onPressed: () => _convertEnquiryToOrder(enquiry),
                            icon: const Icon(Icons.shopping_cart_checkout, size: 12),
                            label: const Text('Convert to Sale', style: TextStyle(fontSize: 11)),
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              );
            },
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 4. CREATE SALES ORDERS & FLOOR HANDOFF
  // =========================================================================
  Widget _buildSalesOrderAssistance() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Assisted Sales Orders & Counter Pre-Billing', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('Prepare customer footwear selections with accessories for instant barcode checkout at the cashier', style: TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
              ElevatedButton.icon(
                onPressed: () => _showCreateOrderDialog(),
                icon: const Icon(Icons.add_shopping_cart, size: 16),
                label: const Text('Create New Sales Order'),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
              )
            ],
          ),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Assisted Orders', '${_salesOrders.length} Today', Icons.handshake, Colors.teal, 'Floor selections'),
            _metricItem('Ready at Cashier', '${_salesOrders.where((o) => o['status'] == 'READY_FOR_CASHIER').length} Orders', Icons.schedule, Colors.orange, 'Waiting for payment'),
            _metricItem('Average Basket', '₹ 5,196', Icons.receipt, const Color(0xFF4F46E5), 'Pairs + Upsell spray'),
            _metricItem('Completed Checkout', '1 Cleared', Icons.done_all, Colors.green, 'Invoice generated'),
          ]),
          const SizedBox(height: 16),

          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Pre-Bill Handoff Queue (Floor to Cashier)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _salesOrders.length,
                    separatorBuilder: (_, _) => const Divider(height: 20),
                    itemBuilder: (context, idx) {
                      final order = _salesOrders[idx];
                      final isReady = order['status'] == 'READY_FOR_CASHIER';
                      return Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: isReady ? Colors.orange.shade50 : Colors.green.shade50,
                            child: Icon(isReady ? Icons.pending_actions : Icons.check, color: isReady ? Colors.orange : Colors.green, size: 18),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Text(order['orderNo'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                                    const SizedBox(width: 8),
                                    Text('• ${order['customer']} (${order['phone']})', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                                  ],
                                ),
                                const SizedBox(height: 2),
                                Text(order['items'], style: TextStyle(color: Colors.grey.shade700, fontSize: 11)),
                                const SizedBox(height: 2),
                                Text('Created: ${order['time']}', style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
                              ],
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(order['amount'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Color(0xFF4F46E5))),
                              const SizedBox(height: 4),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: isReady ? Colors.orange.shade50 : Colors.green.shade50,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  isReady ? 'READY FOR POS' : 'BILLED',
                                  style: TextStyle(
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                    color: isReady ? Colors.orange.shade800 : Colors.green.shade800,
                                  ),
                                ),
                              ),
                            ],
                          )
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 5. MANAGE PRODUCT RECOMMENDATIONS
  // =========================================================================
  Widget _buildProductRecommendations() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Footwear Recommendation Engine', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('Curate intelligent shoe recommendations, festive pairs, and cross-sell combos to boost ticket size', style: TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
              ElevatedButton.icon(
                onPressed: () => _showAddRecommendationDialog(),
                icon: const Icon(Icons.add, size: 16),
                label: const Text('Add Curated Pick'),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
              )
            ],
          ),
          const SizedBox(height: 16),
          _buildMetricsGrid([
            _metricItem('Recommended Deals', '3 Active', Icons.auto_awesome, const Color(0xFF4F46E5), 'Floor specials'),
            _metricItem('Upsell Attached', '42% of Baskets', Icons.add_shopping_cart, Colors.teal, 'Shoe care kit included'),
            _metricItem('Top Brand Affinity', 'Nike & Bata', Icons.star, Colors.amber.shade800, 'Highest repeat conversion'),
            _metricItem('Avg Ticket Boost', '+ ₹ 650', Icons.arrow_upward, Colors.green, 'Via bundle styling'),
          ]),
          const SizedBox(height: 16),

          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _recommendations.length,
            itemBuilder: (context, idx) {
              final rec = _recommendations[idx];
              final color = rec['color'] as Color;

              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(6)),
                            child: Text(rec['badge'], style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold)),
                          ),
                          Text(rec['title'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.grey)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(rec['product'], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text(rec['reason'], style: TextStyle(color: Colors.grey.shade700, fontSize: 12)),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(8)),
                        child: Row(
                          children: [
                            const Icon(Icons.local_offer, color: Colors.orange, size: 16),
                            const SizedBox(width: 8),
                            Expanded(child: Text(rec['deal'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.black87))),
                            ElevatedButton(
                              onPressed: () {
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Recommendation applied to ${rec['product']}!')));
                              },
                              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                              child: const Text('Pitch to Customer', style: TextStyle(fontSize: 11)),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              );
            },
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 6. VIEW PERSONAL SALES TARGETS, SALES PERFORMANCE & COMMISSION REPORTS
  // =========================================================================
  Widget _buildPersonalTargetsAndCommission() {
    const double target = 150000.0;
    const double achieved = 114500.0;
    const double progress = achieved / target;
    const double commRate = 2.5;
    const double commissionEarned = achieved * (commRate / 100);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Personal Sales Targets & Commission Reports', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Track your monthly sales target, performance ranking, and incentive commission earnings', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),

          _buildMetricsGrid([
            _metricItem('Monthly Target', '₹ 1,50,000', Icons.track_changes, const Color(0xFF4F46E5), 'Target for Nov 2026'),
            _metricItem('Sales Achieved', '₹ 1,14,500', Icons.trending_up, Colors.green, '76.3% Achieved (12 days)'),
            _metricItem('Commission Earned', '₹ ${commissionEarned.toStringAsFixed(0)}', Icons.monetization_on, Colors.amber.shade900, '2.5% incentive rate'),
            _metricItem('Performance Tier', 'Gold Executive', Icons.military_tech, Colors.orange, 'Rank 2 across floor team'),
          ]),
          const SizedBox(height: 16),

          // Progress Card
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Monthly Target Progress (November 2026)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      Text('${(progress * 100).toStringAsFixed(1)}%', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xFF4F46E5))),
                    ],
                  ),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: progress,
                    minHeight: 12,
                    borderRadius: BorderRadius.circular(6),
                    color: const Color(0xFF4F46E5),
                    backgroundColor: const Color(0xFFEEF2FF),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Achieved: ₹ 1,14,500', style: TextStyle(color: Colors.grey.shade700, fontSize: 12, fontWeight: FontWeight.w600)),
                      Text('Remaining: ₹ 35,500', style: TextStyle(color: Colors.grey.shade700, fontSize: 12, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Commission Ledger Table
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Monthly Commission & Performance Ledger', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 12),
                  _commissionRow('November 2026 (Ongoing)', '₹ 1,14,500 Achieved (76.3%)', '₹ 2,862 Earned', 'ACCRUED', Colors.orange),
                  const Divider(height: 16),
                  _commissionRow('October 2026', '₹ 1,68,000 Achieved (112.0%)', '₹ 4,200 Commission', 'PAID', Colors.green),
                  const Divider(height: 16),
                  _commissionRow('September 2026', '₹ 1,42,000 Achieved (94.6%)', '₹ 3,550 Commission', 'PAID', Colors.green),
                  const Divider(height: 16),
                  _commissionRow('August 2026', '₹ 1,55,000 Achieved (103.3%)', '₹ 3,875 Commission', 'PAID', Colors.green),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // DIALOGS & ACTION MODALS
  // =========================================================================

  void _showAddCustomerDialog() {
    final nameCtrl = TextEditingController();
    final mobileCtrl = TextEditingController();
    final sizeCtrl = TextEditingController(text: 'UK 8');
    final brandCtrl = TextEditingController(text: 'Nike');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Register New Customer'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Customer Full Name *')),
              const SizedBox(height: 10),
              TextField(controller: mobileCtrl, decoration: const InputDecoration(labelText: 'Mobile Number *')),
              const SizedBox(height: 10),
              TextField(controller: sizeCtrl, decoration: const InputDecoration(labelText: 'Preferred Shoe Size (e.g. UK 8)')),
              const SizedBox(height: 10),
              TextField(controller: brandCtrl, decoration: const InputDecoration(labelText: 'Preferred Brand (e.g. Nike, Puma)')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () {
              if (nameCtrl.text.isNotEmpty && mobileCtrl.text.isNotEmpty) {
                setState(() {
                  _customers.insert(0, {
                    'id': _customers.length + 1,
                    'name': nameCtrl.text,
                    'mobile': mobileCtrl.text,
                    'email': '${nameCtrl.text.toLowerCase().replaceAll(' ', '')}@gmail.com',
                    'preferredSize': sizeCtrl.text,
                    'preferredBrand': brandCtrl.text,
                    'loyaltyPoints': 50,
                    'totalSpent': '₹ 0',
                    'totalVisits': 1,
                    'lastVisit': '12 Nov 2026',
                  });
                });
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Customer successfully registered with 50 Welcome Loyalty Points!')));
              }
            },
            child: const Text('Register & Award 50 Pts'),
          )
        ],
      ),
    );
  }

  void _showCustomerDetailsModal(Map<String, dynamic> cust) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(cust['name'], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: Colors.amber.shade50, borderRadius: BorderRadius.circular(6)),
                  child: Text('${cust['loyaltyPoints']} Loyalty Pts', style: TextStyle(color: Colors.amber.shade900, fontWeight: FontWeight.bold)),
                )
              ],
            ),
            const SizedBox(height: 6),
            Text('Mobile: ${cust['mobile']} • Email: ${cust['email']}', style: TextStyle(color: Colors.grey.shade600)),
            const Divider(height: 24),
            _infoRow('Preferred Shoe Size', cust['preferredSize']),
            _infoRow('Preferred Brand', cust['preferredBrand']),
            _infoRow('Total Lifetime Spend', cust['totalSpent']),
            _infoRow('Total Store Visits', '${cust['totalVisits']} Visits'),
            _infoRow('Last Store Visit', cust['lastVisit']),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.pop(ctx),
                    icon: const Icon(Icons.close),
                    label: const Text('Close'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pop(ctx);
                      _showCreateOrderDialog(prefilledCustomer: cust['name']);
                    },
                    icon: const Icon(Icons.shopping_bag),
                    label: const Text('Create Order for Customer'),
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  void _showVariantDetailsSheet(Map<String, dynamic> product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(product['name'], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('${product['brand']} • Article: ${product['articleNo']}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
            const Divider(height: 20),
            const Text('Size & Color Stock Breakdown:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            const SizedBox(height: 10),
            ...(product['variants'] as List<dynamic>).map((v) {
              final stock = v['stock'] as int;
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Size: ${v['size']} • Color: ${v['color']} (SKU: ${v['sku']})', style: const TextStyle(fontSize: 12)),
                    Text(stock > 0 ? '$stock in stock' : 'OUT OF STOCK',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: stock > 0 ? Colors.green : Colors.red)),
                  ],
                ),
              );
            }),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx),
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white, minimumSize: const Size.fromHeight(42)),
              child: const Text('Close'),
            )
          ],
        ),
      ),
    );
  }

  void _showAddEnquiryDialog() {
    final custCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    final itemCtrl = TextEditingController();
    final notesCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add Customer Footwear Enquiry'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: custCtrl, decoration: const InputDecoration(labelText: 'Customer Name *')),
              const SizedBox(height: 8),
              TextField(controller: phoneCtrl, decoration: const InputDecoration(labelText: 'Phone Number *')),
              const SizedBox(height: 8),
              TextField(controller: itemCtrl, decoration: const InputDecoration(labelText: 'Requested Footwear (Size & Color) *')),
              const SizedBox(height: 8),
              TextField(controller: notesCtrl, decoration: const InputDecoration(labelText: 'Customer Notes / Occasion')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () {
              if (custCtrl.text.isNotEmpty && phoneCtrl.text.isNotEmpty) {
                setState(() {
                  _enquiries.insert(0, {
                    'id': _enquiries.length + 1,
                    'customer': custCtrl.text,
                    'phone': phoneCtrl.text,
                    'item': itemCtrl.text.isNotEmpty ? itemCtrl.text : 'Footwear Size Inquiry',
                    'status': 'OPEN',
                    'followUpDate': 'Tomorrow',
                    'notes': notesCtrl.text.isNotEmpty ? notesCtrl.text : 'Customer waiting for stock arrival',
                  });
                });
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Customer enquiry logged with follow-up reminder!')));
              }
            },
            child: const Text('Save Enquiry'),
          )
        ],
      ),
    );
  }

  void _showFollowUpActionDialog(Map<String, dynamic> enquiry) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Follow-up: ${enquiry['customer']}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Item: ${enquiry['item']}', style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Contact: ${enquiry['phone']}'),
            const SizedBox(height: 12),
            const Text('Select Follow-up Action:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              setState(() => enquiry['status'] = 'FOLLOWED_UP');
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Status updated to FOLLOWED_UP (WhatsApp/Call logged)')));
            },
            child: const Text('Mark Followed Up'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              _convertEnquiryToOrder(enquiry);
            },
            child: const Text('Customer Agreed (Convert to Sale)'),
          )
        ],
      ),
    );
  }

  void _convertEnquiryToOrder(Map<String, dynamic> enquiry) {
    setState(() {
      enquiry['status'] = 'CONVERTED';
      _salesOrders.insert(0, {
        'orderNo': 'SO-EX-202611-00${_salesOrders.length + 1}',
        'customer': enquiry['customer'],
        'phone': enquiry['phone'],
        'items': enquiry['item'],
        'qty': 1,
        'amount': '₹ 3,499',
        'status': 'READY_FOR_CASHIER',
        'time': 'Just now',
      });
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Enquiry converted! Pre-bill handoff order sent to Cashier.')));
  }

  void _showCreateOrderDialog({String? prefilledCustomer}) {
    final custCtrl = TextEditingController(text: prefilledCustomer ?? 'Rahul Sharma');
    final itemCtrl = TextEditingController(text: 'Nike Air Max 270 (UK 9 - Pure White)');
    final qtyCtrl = TextEditingController(text: '1');
    final priceCtrl = TextEditingController(text: '8995');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Create Floor Sales Order'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: custCtrl, decoration: const InputDecoration(labelText: 'Customer Name *')),
              const SizedBox(height: 8),
              TextField(controller: itemCtrl, decoration: const InputDecoration(labelText: 'Shoe Model & Size *')),
              const SizedBox(height: 8),
              TextField(controller: qtyCtrl, decoration: const InputDecoration(labelText: 'Quantity *')),
              const SizedBox(height: 8),
              TextField(controller: priceCtrl, decoration: const InputDecoration(labelText: 'Price (₹) *')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () {
              setState(() {
                _salesOrders.insert(0, {
                  'orderNo': 'SO-EX-202611-00${_salesOrders.length + 1}',
                  'customer': custCtrl.text,
                  'phone': '+91 98765 43210',
                  'items': itemCtrl.text,
                  'qty': int.tryParse(qtyCtrl.text) ?? 1,
                  'amount': '₹ ${priceCtrl.text}',
                  'status': 'READY_FOR_CASHIER',
                  'time': 'Just now',
                });
              });
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Order queued! Ready for cashier billing.')));
            },
            child: const Text('Send to Cashier'),
          )
        ],
      ),
    );
  }

  void _showAddRecommendationDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add Curated Product Recommendation'),
        content: const Text('Select a footwear model, define customer targeting rationale (e.g. festive, running, party wear), and bundle cross-sell offers.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('New curated recommendation saved to floor catalog!')));
            },
            child: const Text('Save Recommendation'),
          )
        ],
      ),
    );
  }

  // --- WIDGET HELPERS ---
  Widget _buildMetricsGrid(List<Widget> items) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final crossCount = widget.isDesktop ? 4 : 2;
        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: crossCount,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: widget.isDesktop ? 2.1 : 1.5,
          children: items,
        );
      },
    );
  }

  Widget _metricItem(String title, String val, IconData icon, Color color, String sub) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade200)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(child: Text(title, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey.shade600, fontSize: 11, fontWeight: FontWeight.bold))),
              CircleAvatar(backgroundColor: color.withValues(alpha: 0.12), radius: 14, child: Icon(icon, color: color, size: 16)),
            ],
          ),
          Text(val, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          Text(sub, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9, color: Colors.grey.shade500)),
        ],
      ),
    );
  }

  Widget _commissionRow(String month, String sales, String comm, String status, Color statusColor) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(month, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
            Text(sales, style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
          ],
        ),
        Row(
          children: [
            Text(comm, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.green)),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)),
              child: Text(status, style: TextStyle(color: statusColor, fontSize: 10, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ],
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
        ],
      ),
    );
  }
}
