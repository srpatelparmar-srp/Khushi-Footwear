import 'package:flutter/material.dart';

class CustomerStoreView extends StatefulWidget {
  final bool isDesktop;
  final int activeModule;

  const CustomerStoreView({
    super.key,
    required this.isDesktop,
    required this.activeModule,
  });

  @override
  State<CustomerStoreView> createState() => _CustomerStoreViewState();
}

class _CustomerStoreViewState extends State<CustomerStoreView> {
  // --- USER PROFILE STATE ---
  String _customerName = 'Rahul Sharma';
  String _customerMobile = '+91 98765 43210';
  String _customerEmail = 'rahul.sharma@gmail.com';
  String _deliveryAddress = 'Flat 402, Royal Palms, MG Road, Pune - 411001';
  String _preferredShoeSize = 'UK 9';
  int _loyaltyPoints = 120; // 120 points = ₹120

  // --- FILTERS STATE ---
  String _searchQuery = '';
  String _selectedCategory = 'All';
  String _selectedBrand = 'All';
  String _selectedSize = 'All';
  String _selectedColor = 'All';
  String _selectedPriceRange = 'All';

  // --- COUPON STATE ---
  String _appliedCoupon = 'FESTIVE10';
  double _couponDiscountPercent = 10.0;
  final TextEditingController _couponCtrl = TextEditingController();

  // --- PAYMENT SELECTION ---
  String _selectedPaymentMethod = 'UPI'; // 'UPI', 'CARD', 'COD'

  // --- CART STATE ---
  final List<Map<String, dynamic>> _cartItems = [
    {
      'id': 1,
      'productId': 101,
      'name': 'Nike Air Max 270 Flyknit',
      'brand': 'Nike',
      'size': 'UK 9',
      'color': 'Pure White',
      'price': 8995.0,
      'mrp': 11995.0,
      'qty': 1,
    },
    {
      'id': 2,
      'productId': 104,
      'name': 'Bata Formal Derby Classic',
      'brand': 'Bata',
      'size': 'UK 9',
      'color': 'Oxford Tan',
      'price': 2499.0,
      'mrp': 3499.0,
      'qty': 1,
    },
  ];

  // --- WISHLIST STATE ---
  final List<Map<String, dynamic>> _wishlist = [
    {
      'id': 102,
      'name': 'Adidas Ultraboost Light',
      'brand': 'Adidas',
      'size': 'UK 8',
      'color': 'Core Black',
      'price': 9499.0,
      'mrp': 12999.0,
      'rating': '4.8 ★',
    },
    {
      'id': 103,
      'name': 'Puma Smash V2 Leather',
      'brand': 'Puma',
      'size': 'UK 7',
      'color': 'Navy Blue',
      'price': 2799.0,
      'mrp': 3999.0,
      'rating': '4.7 ★',
    },
    {
      'id': 105,
      'name': 'Woodland Waterproof Trekker',
      'brand': 'Woodland',
      'size': 'UK 9',
      'color': 'Camouflage Khaki',
      'price': 4295.0,
      'mrp': 5995.0,
      'rating': '4.9 ★',
    },
  ];

  // --- PRODUCT CATALOG ---
  final List<Map<String, dynamic>> _products = [
    {
      'id': 101,
      'name': 'Nike Air Max 270 Flyknit',
      'category': 'Sneakers',
      'brand': 'Nike',
      'price': 8995.0,
      'mrp': 11995.0,
      'rating': 4.9,
      'reviewsCount': 342,
      'sizes': ['UK 7', 'UK 8', 'UK 9', 'UK 10'],
      'colors': ['Pure White', 'Core Black', 'Wolf Grey'],
      'description': 'Iconic Air unit delivers unmatched all-day comfort. Engineered mesh upper hugs foot with breathability.',
      'icon': Icons.sports_tennis,
    },
    {
      'id': 102,
      'name': 'Adidas Ultraboost Light',
      'category': 'Running',
      'brand': 'Adidas',
      'price': 9499.0,
      'mrp': 12999.0,
      'rating': 4.8,
      'reviewsCount': 280,
      'sizes': ['UK 8', 'UK 9', 'UK 10'],
      'colors': ['Core Black', 'Solar Red'],
      'description': 'Lightest Ultraboost ever made with 30% lighter BOOST material. Epic energy in every stride.',
      'icon': Icons.directions_run,
    },
    {
      'id': 103,
      'name': 'Puma Smash V2 Leather',
      'category': 'Casual',
      'brand': 'Puma',
      'price': 2799.0,
      'mrp': 3999.0,
      'rating': 4.7,
      'reviewsCount': 512,
      'sizes': ['UK 6', 'UK 7', 'UK 8', 'UK 9'],
      'colors': ['Navy Blue', 'Pure White'],
      'description': 'Tennis-inspired classic updated for everyday streetwear. Soft cushioned collar and rubber outsole.',
      'icon': Icons.skateboarding,
    },
    {
      'id': 104,
      'name': 'Bata Formal Derby Classic',
      'category': 'Formal',
      'brand': 'Bata',
      'price': 2499.0,
      'mrp': 3499.0,
      'rating': 4.6,
      'reviewsCount': 190,
      'sizes': ['UK 7', 'UK 8', 'UK 9', 'UK 10', 'UK 11'],
      'colors': ['Oxford Tan', 'Core Black'],
      'description': 'Handcrafted premium leather derby shoes. Cushioned insole suited for corporate wear and weddings.',
      'icon': Icons.work,
    },
    {
      'id': 105,
      'name': 'Woodland Waterproof Trekker',
      'category': 'Outdoor',
      'brand': 'Woodland',
      'price': 4295.0,
      'mrp': 5995.0,
      'rating': 4.9,
      'reviewsCount': 620,
      'sizes': ['UK 7', 'UK 8', 'UK 9'],
      'colors': ['Camouflage Khaki', 'Tan Brown'],
      'description': 'Heavy-duty nubuck leather boots with deep lugged rubber sole for extreme trails and monsoon hikes.',
      'icon': Icons.hiking,
    },
    {
      'id': 106,
      'name': 'Campus Oxyfit Walking Sneaker',
      'category': 'Casual',
      'brand': 'Campus',
      'price': 1299.0,
      'mrp': 1899.0,
      'rating': 4.5,
      'reviewsCount': 410,
      'sizes': ['UK 6', 'UK 7', 'UK 8', 'UK 9'],
      'colors': ['Slate Grey', 'Pure White'],
      'description': 'Super lightweight daily walking shoes with Yoga Max insole technology for active lifestyle.',
      'icon': Icons.directions_walk,
    },
  ];

  // --- ORDERS HISTORY & TRACKING ---
  final List<Map<String, dynamic>> _orders = [
    {
      'orderId': 'ORD-ONL-20261112',
      'date': '12 Nov 2026',
      'items': 'Nike Air Max 270 (UK 9) + Bata Derby (UK 9)',
      'qty': 2,
      'amount': '₹ 10,345',
      'paymentMode': 'UPI (Google Pay)',
      'status': 'OUT_FOR_DELIVERY',
      'trackingNo': 'DLH-KF-882310',
      'courier': 'Delhivery Express',
      'estDelivery': 'Today by 6:00 PM',
      'canReturn': true,
    },
    {
      'orderId': 'ORD-ONL-20261028',
      'date': '28 Oct 2026',
      'items': 'Puma Smash V2 Leather (UK 9)',
      'qty': 1,
      'amount': '₹ 2,799',
      'paymentMode': 'Cash on Delivery (COD)',
      'status': 'DELIVERED',
      'trackingNo': 'DLH-KF-771249',
      'courier': 'Delhivery Express',
      'estDelivery': 'Delivered 30 Oct 2026',
      'canReturn': false,
    },
  ];

  // --- REVIEWS STATE ---
  final List<Map<String, dynamic>> _customerReviews = [
    {
      'product': 'Nike Air Max 270 Flyknit',
      'rating': 5,
      'title': 'Best cushioning and premium look!',
      'comment': 'Fits true to size UK 9. The air unit provides incredible support during long walking shifts. Received in 2 days.',
      'date': '02 Nov 2026',
      'verified': true,
    },
    {
      'product': 'Bata Formal Derby Classic',
      'rating': 4,
      'title': 'Comfortable office footwear',
      'comment': 'Good leather quality for this price range. Looks very sharp with suits and formal trousers.',
      'date': '25 Oct 2026',
      'verified': true,
    },
  ];

  @override
  Widget build(BuildContext context) {
    switch (widget.activeModule) {
      case 0:
        return _buildCatalogAndShopView();
      case 1:
        return _buildCartAndCheckoutView();
      case 2:
        return _buildOrderHistoryAndTracking();
      case 3:
        return _buildWishlistAndLoyaltyView();
      case 4:
        return _buildProfileAndReviewsView();
      default:
        return _buildCatalogAndShopView();
    }
  }

  // =========================================================================
  // 1. BROWSE PRODUCTS, SEARCH, CATEGORY, BRAND, SIZE, COLOR, PRICE FILTERS & DETAILS
  // =========================================================================
  Widget _buildCatalogAndShopView() {
    final filtered = _products.where((p) {
      final matchesSearch = _searchQuery.isEmpty ||
          p['name'].toString().toLowerCase().contains(_searchQuery.toLowerCase()) ||
          p['brand'].toString().toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesCategory = _selectedCategory == 'All' || p['category'] == _selectedCategory;
      final matchesBrand = _selectedBrand == 'All' || p['brand'] == _selectedBrand;
      final matchesSize = _selectedSize == 'All' || (p['sizes'] as List<String>).contains(_selectedSize);
      final matchesColor = _selectedColor == 'All' || (p['colors'] as List<String>).contains(_selectedColor);

      bool matchesPrice = true;
      final price = p['price'] as double;
      if (_selectedPriceRange == 'Under ₹2,000') matchesPrice = price < 2000;
      if (_selectedPriceRange == '₹2,000 - ₹5,000') matchesPrice = price >= 2000 && price <= 5000;
      if (_selectedPriceRange == '₹5,000 - ₹10,000') matchesPrice = price > 5000 && price <= 10000;
      if (_selectedPriceRange == 'Above ₹10,000') matchesPrice = price > 10000;

      return matchesSearch && matchesCategory && matchesBrand && matchesSize && matchesColor && matchesPrice;
    }).toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Banner & Offers
          _buildPromotionalBanner(),
          const SizedBox(height: 16),

          // Search Bar
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Search footwear by brand (Nike, Adidas, Bata) or model name...',
                  prefixIcon: const Icon(Icons.search, size: 20, color: Colors.grey),
                  suffixIcon: _searchQuery.isNotEmpty
                      ? IconButton(icon: const Icon(Icons.clear, size: 16), onPressed: () => setState(() => _searchQuery = ''))
                      : null,
                  isDense: true,
                  border: InputBorder.none,
                ),
                onChanged: (val) => setState(() => _searchQuery = val),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Multi-Filter Panel
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.filter_list, size: 16, color: Color(0xFF4F46E5)),
                      const SizedBox(width: 6),
                      const Text('Filter Footwear By:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      const Spacer(),
                      TextButton(
                        onPressed: () {
                          setState(() {
                            _selectedCategory = 'All';
                            _selectedBrand = 'All';
                            _selectedSize = 'All';
                            _selectedColor = 'All';
                            _selectedPriceRange = 'All';
                            _searchQuery = '';
                          });
                        },
                        child: const Text('Reset All', style: TextStyle(fontSize: 11)),
                      )
                    ],
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _filterDropdown('Category', _selectedCategory, ['All', 'Sneakers', 'Running', 'Casual', 'Formal', 'Outdoor'], (v) => setState(() => _selectedCategory = v!)),
                      _filterDropdown('Brand', _selectedBrand, ['All', 'Nike', 'Adidas', 'Puma', 'Bata', 'Woodland', 'Campus'], (v) => setState(() => _selectedBrand = v!)),
                      _filterDropdown('Size', _selectedSize, ['All', 'UK 6', 'UK 7', 'UK 8', 'UK 9', 'UK 10', 'UK 11'], (v) => setState(() => _selectedSize = v!)),
                      _filterDropdown('Color', _selectedColor, ['All', 'Pure White', 'Core Black', 'Navy Blue', 'Oxford Tan', 'Camouflage Khaki'], (v) => setState(() => _selectedColor = v!)),
                      _filterDropdown('Price', _selectedPriceRange, ['All', 'Under ₹2,000', '₹2,000 - ₹5,000', '₹5,000 - ₹10,000', 'Above ₹10,000'], (v) => setState(() => _selectedPriceRange = v!)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Result Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Available Footwear (${filtered.length} Models)', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              Text('Showing matching pairs for ${_preferredShoeSize.isEmpty ? "All Sizes" : _preferredShoeSize}', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
            ],
          ),
          const SizedBox(height: 12),

          // Product Grid
          if (filtered.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(40),
                child: Column(
                  children: [
                    Icon(Icons.search_off, size: 48, color: Colors.grey.shade400),
                    const SizedBox(height: 12),
                    const Text('No shoes found matching these filter criteria.', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text('Try resetting size, brand, or price filters', style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
                  ],
                ),
              ),
            )
          else
            LayoutBuilder(
              builder: (context, constraints) {
                final crossAxisCount = widget.isDesktop ? 3 : 1;
                return GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: filtered.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: crossAxisCount,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: widget.isDesktop ? 1.55 : 2.1,
                  ),
                  itemBuilder: (context, idx) {
                    final p = filtered[idx];
                    return _buildShoeCard(p);
                  },
                );
              },
            ),
        ],
      ),
    );
  }

  // Promotional Banner with Active Offers & Coupons
  Widget _buildPromotionalBanner() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF4F46E5), Color(0xFF7C3AED), Color(0xFFEC4899)],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(20)),
                  child: const Text('FESTIVE CARNIVAL • USE COUPON "FESTIVE10" FOR 10% OFF',
                      style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                ),
                const SizedBox(height: 8),
                const Text('Step into Premium Footwear', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                const Text('Original brands Nike, Adidas, Puma, Skechers, Woodland & Bata. Free express delivery on prepaid orders.',
                    style: TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),
          if (widget.isDesktop)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Icon(Icons.snowshoeing_rounded, size: 54, color: Colors.white24),
            ),
        ],
      ),
    );
  }

  Widget _buildShoeCard(Map<String, dynamic> product) {
    final isInWishlist = _wishlist.any((w) => w['id'] == product['id']);

    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CircleAvatar(
                  backgroundColor: const Color(0xFFEEF2FF),
                  radius: 20,
                  child: Icon(product['icon'] as IconData, color: const Color(0xFF4F46E5), size: 22),
                ),
                IconButton(
                  icon: Icon(isInWishlist ? Icons.favorite : Icons.favorite_border,
                      color: isInWishlist ? Colors.red : Colors.grey, size: 20),
                  onPressed: () => _toggleWishlist(product),
                )
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(product['brand'].toString().toUpperCase(),
                    style: const TextStyle(color: Colors.grey, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                Text(product['name'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Text('${product['rating']} ★', style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold, fontSize: 11)),
                    const SizedBox(width: 4),
                    Text('(${product['reviewsCount']} reviews)', style: TextStyle(color: Colors.grey.shade500, fontSize: 10)),
                  ],
                ),
                const SizedBox(height: 2),
                Text('Sizes: ${(product['sizes'] as List).join(", ")}', style: TextStyle(color: Colors.grey.shade600, fontSize: 10)),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('₹ ${(product['price'] as double).toStringAsFixed(0)}',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xFF4F46E5))),
                    Text('MRP ₹ ${(product['mrp'] as double).toStringAsFixed(0)}',
                        style: const TextStyle(decoration: TextDecoration.lineThrough, color: Colors.grey, fontSize: 10)),
                  ],
                ),
                Row(
                  children: [
                    OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        visualDensity: VisualDensity.compact,
                      ),
                      onPressed: () => _showProductDetailsModal(product),
                      child: const Text('Details', style: TextStyle(fontSize: 11)),
                    ),
                    const SizedBox(width: 6),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF4F46E5),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        visualDensity: VisualDensity.compact,
                      ),
                      onPressed: () => _showAddToCartDialog(product),
                      icon: const Icon(Icons.shopping_bag, size: 14),
                      label: const Text('Add', style: TextStyle(fontSize: 11)),
                    )
                  ],
                )
              ],
            )
          ],
        ),
      ),
    );
  }

  // =========================================================================
  // 2. SHOPPING CART, APPLY COUPONS, LOYALTY REDEMPTION, PAYMENTS (ONLINE / COD)
  // =========================================================================
  Widget _buildCartAndCheckoutView() {
    double subtotal = 0.0;
    for (var item in _cartItems) {
      subtotal += (item['price'] as double) * (item['qty'] as int);
    }
    final discount = (subtotal * _couponDiscountPercent) / 100.0;
    final loyaltyDeduction = _loyaltyPoints > 0 ? (_loyaltyPoints.toDouble() > 100 ? 100.0 : _loyaltyPoints.toDouble()) : 0.0;
    final grandTotal = (subtotal - discount - loyaltyDeduction).clamp(0.0, 999999.0);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Shopping Cart & Fast Checkout', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Review selected sizes, apply coupons, select online UPI/Card or Cash on Delivery, and place order', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),

          if (_cartItems.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(40),
                child: Column(
                  children: [
                    Icon(Icons.shopping_bag_outlined, size: 54, color: Colors.grey.shade400),
                    const SizedBox(height: 12),
                    const Text('Your cart is empty', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 6),
                    const Text('Explore our latest shoes and add your preferred size to cart.'),
                  ],
                ),
              ),
            )
          else
            LayoutBuilder(
              builder: (context, constraints) {
                final isWide = constraints.maxWidth >= 800;
                return isWide
                    ? Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(flex: 3, child: _buildCartItemsList()),
                          const SizedBox(width: 16),
                          Expanded(flex: 2, child: _buildOrderCheckoutSummary(subtotal, discount, loyaltyDeduction, grandTotal)),
                        ],
                      )
                    : Column(
                        children: [
                          _buildCartItemsList(),
                          const SizedBox(height: 16),
                          _buildOrderCheckoutSummary(subtotal, discount, loyaltyDeduction, grandTotal),
                        ],
                      );
              },
            ),
        ],
      ),
    );
  }

  Widget _buildCartItemsList() {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Items in Cart (${_cartItems.length} Pairs)', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                TextButton(
                  onPressed: () => setState(() => _cartItems.clear()),
                  child: const Text('Clear All', style: TextStyle(color: Colors.red, fontSize: 11)),
                )
              ],
            ),
            const Divider(),
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _cartItems.length,
              separatorBuilder: (_, _) => const Divider(height: 16),
              itemBuilder: (context, idx) {
                final item = _cartItems[idx];
                return Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(8)),
                      child: const Icon(Icons.snowshoeing, color: Color(0xFF4F46E5), size: 24),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item['name'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                          Text('Size: ${item['size']} • Color: ${item['color']}', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                          Text('₹ ${(item['price'] as double).toStringAsFixed(0)} each',
                              style: const TextStyle(color: Color(0xFF4F46E5), fontWeight: FontWeight.bold, fontSize: 12)),
                        ],
                      ),
                    ),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.remove_circle_outline, size: 18),
                          onPressed: () {
                            setState(() {
                              if (item['qty'] > 1) {
                                item['qty']--;
                              } else {
                                _cartItems.removeAt(idx);
                              }
                            });
                          },
                        ),
                        Text('${item['qty']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                        IconButton(
                          icon: const Icon(Icons.add_circle_outline, size: 18),
                          onPressed: () => setState(() => item['qty']++),
                        ),
                      ],
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOrderCheckoutSummary(double subtotal, double discount, double loyaltyDeduction, double grandTotal) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Delivery & Payment Summary', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 12),

            // Delivery Address Preview
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(8)),
              child: Row(
                children: [
                  const Icon(Icons.location_on, size: 18, color: Colors.teal),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Deliver to:', style: TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)),
                        Text('$_customerName • $_customerMobile', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
                        Text(_deliveryAddress, style: TextStyle(fontSize: 10, color: Colors.grey.shade600), maxLines: 1, overflow: TextOverflow.ellipsis),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: () => _showEditAddressDialog(),
                    child: const Text('Change', style: TextStyle(fontSize: 11)),
                  )
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Coupon Code Application
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _couponCtrl,
                    decoration: InputDecoration(
                      hintText: 'Enter Coupon (e.g. FESTIVE10)',
                      isDense: true,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                  onPressed: () {
                    final code = _couponCtrl.text.trim().toUpperCase();
                    if (code == 'FESTIVE10') {
                      setState(() {
                        _appliedCoupon = 'FESTIVE10';
                        _couponDiscountPercent = 10.0;
                      });
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Coupon "FESTIVE10" applied! 10% discount deducted.')));
                    } else if (code == 'KHUSHI500') {
                      setState(() {
                        _appliedCoupon = 'KHUSHI500';
                        _couponDiscountPercent = 15.0;
                      });
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Coupon "KHUSHI500" applied! 15% discount deducted.')));
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invalid coupon code. Try "FESTIVE10".')));
                    }
                  },
                  child: const Text('Apply', style: TextStyle(fontSize: 11)),
                )
              ],
            ),
            const SizedBox(height: 12),

            // Payment Mode Selector (UPI, Card, COD)
            const Text('Choose Payment Option:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('UPI (GPay/PhonePe)', style: TextStyle(fontSize: 11)),
                  selected: _selectedPaymentMethod == 'UPI',
                  onSelected: (_) => setState(() => _selectedPaymentMethod = 'UPI'),
                ),
                ChoiceChip(
                  label: const Text('Card / Net Banking', style: TextStyle(fontSize: 11)),
                  selected: _selectedPaymentMethod == 'CARD',
                  onSelected: (_) => setState(() => _selectedPaymentMethod = 'CARD'),
                ),
                ChoiceChip(
                  label: const Text('Cash on Delivery (COD)', style: TextStyle(fontSize: 11)),
                  selected: _selectedPaymentMethod == 'COD',
                  onSelected: (_) => setState(() => _selectedPaymentMethod = 'COD'),
                ),
              ],
            ),
            const Divider(height: 20),

            _summaryRow('Subtotal (${_cartItems.length} pairs)', '₹ ${subtotal.toStringAsFixed(0)}'),
            if (discount > 0)
              _summaryRow('Coupon Discount ($_appliedCoupon)', '-₹ ${discount.toStringAsFixed(0)}', color: Colors.green),
            if (loyaltyDeduction > 0)
              _summaryRow('Loyalty Points Redeemed', '-₹ ${loyaltyDeduction.toStringAsFixed(0)}', color: Colors.amber.shade900),
            _summaryRow('GST on Footwear (12%)', 'Included in Price'),
            _summaryRow('Express Courier Shipping', 'FREE', color: Colors.green),
            const Divider(),
            _summaryRow('Total Payable Amount', '₹ ${grandTotal.toStringAsFixed(0)}', isBold: true, color: const Color(0xFF4F46E5)),
            const SizedBox(height: 16),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF4F46E5),
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(44),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: () => _placeOrder(grandTotal),
              child: Text(
                _selectedPaymentMethod == 'COD' ? 'Place Order with Cash on Delivery' : 'Pay ₹ ${grandTotal.toStringAsFixed(0)} Online Now',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            )
          ],
        ),
      ),
    );
  }

  void _placeOrder(double amount) {
    final orderId = 'ORD-ONL-${DateTime.now().millisecondsSinceEpoch.toString().substring(5)}';
    setState(() {
      _orders.insert(0, {
        'orderId': orderId,
        'date': 'Today',
        'items': _cartItems.map((c) => '${c['name']} (${c['size']})').join(' + '),
        'qty': _cartItems.length,
        'amount': '₹ ${amount.toStringAsFixed(0)}',
        'paymentMode': _selectedPaymentMethod == 'COD' ? 'Cash on Delivery (COD)' : 'Online Payment ($_selectedPaymentMethod)',
        'status': 'CONFIRMED',
        'trackingNo': 'DLH-KF-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}',
        'courier': 'Delhivery Express',
        'estDelivery': 'Expected in 3 days',
        'canReturn': true,
      });
      // Award loyalty points
      _loyaltyPoints += (amount / 100).toInt();
      _cartItems.clear();
    });

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green),
            SizedBox(width: 8),
            Text('Order Confirmed!'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Thank you, $_customerName! Your footwear order #$orderId is confirmed.', style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Payment Method: $_selectedPaymentMethod'),
            Text('Delivery to: $_deliveryAddress'),
            const SizedBox(height: 8),
            Text('You earned ${(amount / 100).toInt()} Khushi Loyalty Points on this purchase!', style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx),
            child: const Text('View in Orders & Tracking'),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 3. TRACK ORDERS, ORDER HISTORY, DOWNLOAD INVOICES, RETURNS & EXCHANGES
  // =========================================================================
  Widget _buildOrderHistoryAndTracking() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('My Orders, Live Tracking & Exchanges', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Track real-time courier dispatch status, download GST PDF invoices, or request size/color exchange within 7 days', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),

          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _orders.length,
            itemBuilder: (context, idx) {
              final order = _orders[idx];
              final isOut = order['status'] == 'OUT_FOR_DELIVERY';
              final isDelivered = order['status'] == 'DELIVERED';
              final badgeColor = isDelivered ? Colors.green : (isOut ? Colors.teal : Colors.orange);

              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(order['orderId'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                              Text('Placed on ${order['date']} • Mode: ${order['paymentMode']}', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: badgeColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(6)),
                            child: Text(order['status'], style: TextStyle(color: badgeColor, fontWeight: FontWeight.bold, fontSize: 10)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text('Footwear: ${order['items']}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                      Text('Grand Total: ${order['amount']} (${order['qty']} items)', style: const TextStyle(color: Color(0xFF4F46E5), fontWeight: FontWeight.bold, fontSize: 12)),
                      const SizedBox(height: 12),

                      // Live Tracking Timeline
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(8)),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text('Courier: ${order['courier']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
                                Text('AWB: ${order['trackingNo']}', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                              ],
                            ),
                            const SizedBox(height: 8),
                            _trackingStep('Order Placed & Confirmed', 'Khushi Footwear Main Warehouse', true),
                            _trackingStep('Quality Checked & Packed in Box', 'Barcode Verification Complete', true),
                            _trackingStep('Dispatched with Delhivery Air', 'In Transit to Destination Hub', true),
                            _trackingStep(
                              isDelivered ? 'Package Delivered' : 'Out for Delivery (Rider: Vikas)',
                              order['estDelivery'],
                              true,
                              isCurrent: !isDelivered,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Action Buttons: Invoice, Exchange, Return
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          OutlinedButton.icon(
                            onPressed: () => _downloadInvoice(order),
                            icon: const Icon(Icons.download, size: 14),
                            label: const Text('Download GST Invoice', style: TextStyle(fontSize: 11)),
                          ),
                          OutlinedButton.icon(
                            onPressed: () => _showExchangeDialog(order),
                            icon: const Icon(Icons.swap_horiz, size: 14),
                            label: const Text('Request Size/Color Exchange', style: TextStyle(fontSize: 11)),
                          ),
                          OutlinedButton.icon(
                            onPressed: () => _showReturnDialog(order),
                            icon: const Icon(Icons.replay, size: 14),
                            label: const Text('Return Footwear', style: TextStyle(fontSize: 11)),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // =========================================================================
  // 4. WISHLIST & LOYALTY CLUB
  // =========================================================================
  Widget _buildWishlistAndLoyaltyView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Wishlist & Khushi Loyalty Points Club', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Save favorite shoe models, earn 1 point for every ₹100 spent, and redeem points for direct checkout savings', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),

          // Loyalty Wallet Card
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.amber.shade700, Colors.orange.shade800],
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 26,
                  backgroundColor: Colors.white24,
                  child: Icon(Icons.stars, color: Colors.white, size: 30),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Khushi Footwear Rewards Club', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.bold)),
                      Text('$_loyaltyPoints Available Points (Worth ₹ $_loyaltyPoints)',
                          style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                      const Text('Points apply automatically on checkout as instant balance deduction.', style: TextStyle(color: Colors.white70, fontSize: 10)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Wishlist Items
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Saved in Wishlist (${_wishlist.length} Pairs)', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      if (_wishlist.isNotEmpty)
                        TextButton(
                          onPressed: () => setState(() => _wishlist.clear()),
                          child: const Text('Clear Wishlist', style: TextStyle(fontSize: 11, color: Colors.red)),
                        )
                    ],
                  ),
                  const Divider(),
                  if (_wishlist.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(24),
                      child: Center(child: Text('Your wishlist is empty. Tap the heart icon on any shoe card to save it!')),
                    )
                  else
                    ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _wishlist.length,
                      separatorBuilder: (_, _) => const Divider(height: 16),
                      itemBuilder: (context, idx) {
                        final item = _wishlist[idx];
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item['name'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                                Text('${item['brand']} • Size: ${item['size']} • Color: ${item['color']}', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                                Text('₹ ${(item['price'] as double).toStringAsFixed(0)} (MRP ₹ ${(item['mrp'] as double).toStringAsFixed(0)})',
                                    style: const TextStyle(color: Color(0xFF4F46E5), fontWeight: FontWeight.bold, fontSize: 12)),
                              ],
                            ),
                            Row(
                              children: [
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                                  onPressed: () {
                                    setState(() {
                                      _cartItems.add({
                                        'id': DateTime.now().millisecondsSinceEpoch,
                                        'productId': item['id'],
                                        'name': item['name'],
                                        'brand': item['brand'],
                                        'size': item['size'],
                                        'color': item['color'],
                                        'price': item['price'],
                                        'mrp': item['mrp'],
                                        'qty': 1,
                                      });
                                      _wishlist.removeAt(idx);
                                    });
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Moved ${item['name']} to cart!')));
                                  },
                                  child: const Text('Move to Cart', style: TextStyle(fontSize: 11)),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline, color: Colors.grey, size: 18),
                                  onPressed: () => setState(() => _wishlist.removeAt(idx)),
                                )
                              ],
                            )
                          ],
                        );
                      },
                    ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // 5. PROFILE MANAGEMENT & SUBMIT PRODUCT REVIEWS
  // =========================================================================
  Widget _buildProfileAndReviewsView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Customer Profile & Verified Reviews', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Text('Manage delivery address, shoe fit preferences, and submit ratings for purchased pairs', style: TextStyle(color: Colors.grey, fontSize: 11)),
          const SizedBox(height: 16),

          // Profile Details Card
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          CircleAvatar(
                            radius: 24,
                            backgroundColor: const Color(0xFF4F46E5).withValues(alpha: 0.1),
                            child: const Icon(Icons.person, color: Color(0xFF4F46E5), size: 28),
                          ),
                          const SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(_customerName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                              Text('$_customerMobile • $_customerEmail', style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                            ],
                          ),
                        ],
                      ),
                      ElevatedButton.icon(
                        onPressed: () => _showEditAddressDialog(),
                        icon: const Icon(Icons.edit, size: 14),
                        label: const Text('Edit Profile'),
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                      )
                    ],
                  ),
                  const Divider(height: 24),
                  _infoRow('Preferred Shoe Size', _preferredShoeSize),
                  _infoRow('Default Delivery Address', _deliveryAddress),
                  _infoRow('Reward Club Membership', 'Gold Footwear Tier (120 Pts)'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Reviews Section
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Your Footwear Reviews & Ratings', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      ElevatedButton.icon(
                        onPressed: () => _showWriteReviewDialog(),
                        icon: const Icon(Icons.rate_review, size: 14),
                        label: const Text('Write a Review'),
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                      )
                    ],
                  ),
                  const Divider(height: 20),
                  ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _customerReviews.length,
                    separatorBuilder: (_, _) => const Divider(height: 16),
                    itemBuilder: (context, idx) {
                      final r = _customerReviews[idx];
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(r['product'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                              Row(
                                children: List.generate(
                                  5,
                                  (i) => Icon(
                                    i < (r['rating'] as int) ? Icons.star : Icons.star_border,
                                    size: 14,
                                    color: Colors.amber,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(r['title'], style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                          Text(r['comment'], style: TextStyle(color: Colors.grey.shade700, fontSize: 11)),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const Icon(Icons.verified, size: 12, color: Colors.green),
                              const SizedBox(width: 4),
                              Text('Verified Purchase • ${r['date']}', style: const TextStyle(fontSize: 10, color: Colors.green, fontWeight: FontWeight.bold)),
                            ],
                          )
                        ],
                      );
                    },
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // =========================================================================
  // DIALOGS & MODALS (PRODUCT DETAILS, ADD TO CART, EXCHANGES, REVIEWS, ADDRESS)
  // =========================================================================

  void _toggleWishlist(Map<String, dynamic> product) {
    setState(() {
      final idx = _wishlist.indexWhere((w) => w['id'] == product['id']);
      if (idx >= 0) {
        _wishlist.removeAt(idx);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Removed ${product['name']} from wishlist.')));
      } else {
        _wishlist.add({
          'id': product['id'],
          'name': product['name'],
          'brand': product['brand'],
          'size': (product['sizes'] as List).first,
          'color': (product['colors'] as List).first,
          'price': product['price'],
          'mrp': product['mrp'],
          'rating': '${product['rating']} ★',
        });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Saved ${product['name']} to wishlist!')));
      }
    });
  }

  void _showAddToCartDialog(Map<String, dynamic> product) {
    String selectedSize = (product['sizes'] as List).first;
    String selectedColor = (product['colors'] as List).first;
    int qty = 1;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDlgState) => AlertDialog(
          title: Text('Select Size & Color: ${product['name']}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Shoe Size (UK):', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                children: (product['sizes'] as List).map<Widget>((s) {
                  final isSel = selectedSize == s;
                  return ChoiceChip(
                    label: Text(s, style: const TextStyle(fontSize: 11)),
                    selected: isSel,
                    onSelected: (_) => setDlgState(() => selectedSize = s),
                  );
                }).toList(),
              ),
              const SizedBox(height: 12),
              const Text('Color Variant:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                children: (product['colors'] as List).map<Widget>((c) {
                  final isSel = selectedColor == c;
                  return ChoiceChip(
                    label: Text(c, style: const TextStyle(fontSize: 11)),
                    selected: isSel,
                    onSelected: (_) => setDlgState(() => selectedColor = c),
                  );
                }).toList(),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Quantity:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                  Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.remove_circle_outline),
                        onPressed: qty > 1 ? () => setDlgState(() => qty--) : null,
                      ),
                      Text('$qty', style: const TextStyle(fontWeight: FontWeight.bold)),
                      IconButton(
                        icon: const Icon(Icons.add_circle_outline),
                        onPressed: () => setDlgState(() => qty++),
                      ),
                    ],
                  )
                ],
              )
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
              onPressed: () {
                setState(() {
                  _cartItems.add({
                    'id': DateTime.now().millisecondsSinceEpoch,
                    'productId': product['id'],
                    'name': product['name'],
                    'brand': product['brand'],
                    'size': selectedSize,
                    'color': selectedColor,
                    'price': product['price'],
                    'mrp': product['mrp'],
                    'qty': qty,
                  });
                });
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Added ${product['name']} ($selectedSize - $selectedColor) to cart!')));
              },
              child: const Text('Add to Cart'),
            )
          ],
        ),
      ),
    );
  }

  void _showProductDetailsModal(Map<String, dynamic> product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(product['brand'].toString().toUpperCase(), style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.bold, fontSize: 10)),
                      Text(product['name'], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                Text('₹ ${(product['price'] as double).toStringAsFixed(0)}',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Color(0xFF4F46E5))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Text('${product['rating']} ★', style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold)),
                const SizedBox(width: 6),
                Text('Verified Customer Reviews (${product['reviewsCount']})', style: const TextStyle(color: Colors.grey, fontSize: 12)),
              ],
            ),
            const Divider(height: 20),
            Text(product['description'], style: TextStyle(color: Colors.grey.shade800, fontSize: 13)),
            const SizedBox(height: 12),
            _infoRow('Available UK Sizes', (product['sizes'] as List).join(', ')),
            _infoRow('Available Colors', (product['colors'] as List).join(', ')),
            _infoRow('Category', product['category']),
            _infoRow('Warranty & Return', '7-Day Hassle-Free Size/Color Exchange'),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.pop(ctx);
                      _toggleWishlist(product);
                    },
                    child: const Text('Save to Wishlist'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                    onPressed: () {
                      Navigator.pop(ctx);
                      _showAddToCartDialog(product);
                    },
                    child: const Text('Select Size & Add to Cart'),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  void _showExchangeDialog(Map<String, dynamic> order) {
    String selectedReplacementSize = 'UK 8';
    String selectedReplacementColor = 'Pure White';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDlgState) => AlertDialog(
          title: Text('Request Exchange for ${order['orderId']}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Select Replacement Size:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                children: ['UK 7', 'UK 8', 'UK 9', 'UK 10'].map((s) {
                  return ChoiceChip(
                    label: Text(s, style: const TextStyle(fontSize: 11)),
                    selected: selectedReplacementSize == s,
                    onSelected: (_) => setDlgState(() => selectedReplacementSize = s),
                  );
                }).toList(),
              ),
              const SizedBox(height: 10),
              const Text('Select Replacement Color:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                children: ['Pure White', 'Core Black', 'Navy Blue'].map((c) {
                  return ChoiceChip(
                    label: Text(c, style: const TextStyle(fontSize: 11)),
                    selected: selectedReplacementColor == c,
                    onSelected: (_) => setDlgState(() => selectedReplacementColor = c),
                  );
                }).toList(),
              ),
              const SizedBox(height: 10),
              const Text('Doorstep pickup will be scheduled with Delhivery within 24 hours at no extra charge.',
                  style: TextStyle(fontSize: 11, color: Colors.grey)),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
              onPressed: () {
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('Exchange request lodged for $selectedReplacementSize ($selectedReplacementColor)! Pickup scheduled.')));
              },
              child: const Text('Confirm Exchange'),
            )
          ],
        ),
      ),
    );
  }

  void _showReturnDialog(Map<String, dynamic> order) {
    String reason = 'Size too small';
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Return Footwear: ${order['orderId']}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Reason for Return:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(height: 6),
            DropdownButton<String>(
              value: reason,
              isExpanded: true,
              items: ['Size too small', 'Size too large', 'Color mismatch', 'Defective/Damaged Pair']
                  .map((r) => DropdownMenuItem(value: r, child: Text(r, style: const TextStyle(fontSize: 12))))
                  .toList(),
              onChanged: (v) => reason = v ?? reason,
            ),
            const SizedBox(height: 10),
            const Text('Refund of purchase amount will be credited back to your original payment method / UPI within 48 hours.',
                style: TextStyle(fontSize: 11, color: Colors.grey)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Return request accepted! Courier rider will collect the shoebox.')));
            },
            child: const Text('Submit Return'),
          )
        ],
      ),
    );
  }

  void _downloadInvoice(Map<String, dynamic> order) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.picture_as_pdf, color: Colors.red),
            const SizedBox(width: 8),
            Text('GST Tax Invoice: ${order['orderId']}'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('KHUSHI FOOTWEAR PVT. LTD.', style: TextStyle(fontWeight: FontWeight.bold)),
            const Text('GSTIN: 27AABCK1234F1Z9 • HSN Code: 6404'),
            const Divider(),
            _infoRow('Billed To', _customerName),
            _infoRow('Date', order['date']),
            _infoRow('Items', order['items']),
            _infoRow('Total Amount', order['amount']),
            _infoRow('Payment Mode', order['paymentMode']),
            _infoRow('Status', 'PAID & TAX INVOICE GENERATED'),
          ],
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Invoice ${order['orderId']}.pdf downloaded to your device!')));
            },
            child: const Text('Download PDF'),
          )
        ],
      ),
    );
  }

  void _showWriteReviewDialog() {
    final titleCtrl = TextEditingController();
    final commentCtrl = TextEditingController();
    int rating = 5;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDlgState) => AlertDialog(
          title: const Text('Submit Footwear Review'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Rate your purchase:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                const SizedBox(height: 6),
                Row(
                  children: List.generate(5, (i) {
                    return IconButton(
                      icon: Icon(i < rating ? Icons.star : Icons.star_border, color: Colors.amber, size: 28),
                      onPressed: () => setDlgState(() => rating = i + 1),
                    );
                  }),
                ),
                const SizedBox(height: 8),
                TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Review Headline *')),
                const SizedBox(height: 8),
                TextField(controller: commentCtrl, maxLines: 3, decoration: const InputDecoration(labelText: 'Detailed Experience & Fit Details *')),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
              onPressed: () {
                if (titleCtrl.text.isNotEmpty && commentCtrl.text.isNotEmpty) {
                  setState(() {
                    _customerReviews.insert(0, {
                      'product': 'Nike Air Max 270 Flyknit',
                      'rating': rating,
                      'title': titleCtrl.text,
                      'comment': commentCtrl.text,
                      'date': 'Today',
                      'verified': true,
                    });
                  });
                  Navigator.pop(ctx);
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Review submitted successfully! Thank you for rating.')));
                }
              },
              child: const Text('Submit Review'),
            )
          ],
        ),
      ),
    );
  }

  void _showEditAddressDialog() {
    final nameCtrl = TextEditingController(text: _customerName);
    final mobileCtrl = TextEditingController(text: _customerMobile);
    final emailCtrl = TextEditingController(text: _customerEmail);
    final addrCtrl = TextEditingController(text: _deliveryAddress);
    final sizeCtrl = TextEditingController(text: _preferredShoeSize);

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit Delivery Address & Preferences'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Full Name *')),
              const SizedBox(height: 8),
              TextField(controller: mobileCtrl, decoration: const InputDecoration(labelText: 'Mobile Number *')),
              const SizedBox(height: 8),
              TextField(controller: emailCtrl, decoration: const InputDecoration(labelText: 'Email Address *')),
              const SizedBox(height: 8),
              TextField(controller: addrCtrl, maxLines: 2, decoration: const InputDecoration(labelText: 'Delivery Address *')),
              const SizedBox(height: 8),
              TextField(controller: sizeCtrl, decoration: const InputDecoration(labelText: 'Preferred Shoe Size (e.g. UK 9)')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
            onPressed: () {
              setState(() {
                _customerName = nameCtrl.text;
                _customerMobile = mobileCtrl.text;
                _customerEmail = emailCtrl.text;
                _deliveryAddress = addrCtrl.text;
                _preferredShoeSize = sizeCtrl.text;
              });
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile and delivery address updated!')));
            },
            child: const Text('Save Details'),
          )
        ],
      ),
    );
  }

  // --- WIDGET HELPERS ---
  Widget _filterDropdown(String title, String val, List<String> options, ValueChanged<String?> onChanged) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
      decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(8)),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: val,
          isDense: true,
          style: const TextStyle(color: Colors.black87, fontSize: 11),
          onChanged: onChanged,
          items: options.map((o) => DropdownMenuItem(value: o, child: Text('$title: $o'))).toList(),
        ),
      ),
    );
  }

  Widget _summaryRow(String title, String val, {bool isBold = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: TextStyle(fontSize: 12, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
          Text(val, style: TextStyle(fontSize: 12, fontWeight: isBold ? FontWeight.bold : FontWeight.normal, color: color)),
        ],
      ),
    );
  }

  Widget _trackingStep(String title, String time, bool isDone, {bool isCurrent = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(isDone ? Icons.check_circle : Icons.radio_button_unchecked,
              size: 16, color: isCurrent ? Colors.teal : (isDone ? const Color(0xFF4F46E5) : Colors.grey)),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: TextStyle(fontSize: 11, fontWeight: isCurrent ? FontWeight.bold : FontWeight.normal, color: isCurrent ? Colors.teal : Colors.black87)),
              Text(time, style: TextStyle(fontSize: 9, color: Colors.grey.shade500)),
            ],
          )
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}
