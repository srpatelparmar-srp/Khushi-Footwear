import 'package:flutter/material.dart';

class DatabaseArchitectureView extends StatefulWidget {
  const DatabaseArchitectureView({super.key});

  @override
  State<DatabaseArchitectureView> createState() => _DatabaseArchitectureViewState();
}

class _DatabaseArchitectureViewState extends State<DatabaseArchitectureView> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _searchQuery = '';
  String? _executionResult;
  bool _isExecuting = false;

  final List<Map<String, dynamic>> _storedProcedures = [
    {
      'name': 'dbo.sp_ProcessPosBilling',
      'category': 'Sales & POS',
      'params': '@BranchId, @CashierUserId, @CustomerId, @CustomerName, @CustomerPhone, @SubTotal, @DiscountAmount, @TaxAmount, @GrandTotal, @PaidAmount, @PaymentMode',
      'description': 'Executes atomic POS billing transaction. Acquires next value from Seq_InvoiceNumber, validates & creates invoice, computes 12% GST breakdown, updates customer loyalty accruals, and logs cash/upi receipt.',
      'returns': 'GeneratedInvoiceNumber, GeneratedOrderId, PaymentStatus, LoyaltyPointsAwarded',
      'complexity': 'High (Atomic ACID Transaction)',
    },
    {
      'name': 'dbo.sp_ProcessFootwearExchange',
      'category': 'Footwear Inventory',
      'params': '@OriginalInvoiceNumber, @OriginalVariantId, @NewVariantId, @Quantity, @BranchId, @ExchangeReason, @ProcessedByUserId',
      'description': 'Performs two-way inventory exchange for shoe size or color variance. Restocks returned pair, deducts replacement pair, verifies physical shelf stock, calculates price difference, and issues RMA Slip.',
      'returns': 'PriceDifference (Debit/Credit), ExchangeSlipNumber',
      'complexity': 'High (Dual Inventory Mutation)',
    },
    {
      'name': 'dbo.sp_ReceiveGoodsGRN',
      'category': 'Purchases & Inward',
      'params': '@PurchaseOrderId, @BranchId, @ReceivedByUserId, @SupplierInvoiceNo, @TotalInvoiceAmount',
      'description': 'Inward Goods Receipt Note processing. Uses SQL MERGE statement to increment inventory across multiple variants, updates Purchase Order status to RECEIVED, and logs barcode verifications.',
      'returns': 'GeneratedGRNNumber, TotalUnitsInwarded',
      'complexity': 'Medium (MERGE upsert)',
    },
    {
      'name': 'dbo.sp_GetDashboardExecutiveSummary',
      'category': 'Analytics & BI',
      'params': '@BranchId, @TodayDate',
      'description': 'Ultra-fast single-roundtrip analytical procedure powering the Owner App and Admin Dashboard. Aggregates today\'s cash/upi turnover, GST collected, MTD volume, and low stock alert counters.',
      'returns': 'Resultset 1: Today KPIs; Resultset 2: MTD KPIs; Resultset 3: Stock Valuation & Alerts',
      'complexity': 'High (Multi-resultset aggregation)',
    },
    {
      'name': 'dbo.sp_WriteOffDamagedFootwear',
      'category': 'Loss Prevention',
      'params': '@BranchId, @ProductVariantId, @Quantity, @Reason, @CreatedByUserId',
      'description': 'Writes off defective, damaged, or sole-separated shoes. Deducts physical inventory, logs operational loss under STOCK_LOSS expense category, and auto-generates vendor Debit Note.',
      'returns': 'DebitNoteNumber, TotalLossAmount',
      'complexity': 'Medium (Audit & Expense write-off)',
    },
    {
      'name': 'dbo.sp_ReconcileDailyCashbook',
      'category': 'Accounts & Cash',
      'params': '@BranchId, @ReconciliationDate, @OpeningFloat, @ReconciledByUserId',
      'description': 'Reconciles the daily cash drawer by calculating Opening Float + Cash POS Sales - Cash Expenses to yield the expected closing balance for end-of-day store handover.',
      'returns': 'ReconciliationDate, OpeningFloat, TotalCashSales, TotalCashExpenses, ExpectedClosingCash',
      'complexity': 'Medium (Reconciliation query)',
    },
  ];

  final List<Map<String, dynamic>> _views = [
    {
      'name': 'dbo.vw_FootwearInventoryMatrix',
      'category': 'Inventory',
      'columns': 'ProductId, ProductName, ModelNumber, BrandName, CategoryName, VariantId, Size, Color, Barcode, SKU, CurrentStock, MinAlertLevel, CostPrice, SellingPrice, MRP, MarginPercentage, StockStatus',
      'description': 'Denormalized real-time matrix joining Products, Variants, Sizes, Colors, Brands, Categories, and Inventories for blazing-fast catalog and POS grid lookups.',
      'recordsSample': '248 Active Variants across 3 Branches',
    },
    {
      'name': 'dbo.vw_DailySalesSummary',
      'category': 'Sales',
      'columns': 'SalesDate, BranchId, BranchName, PaymentMode, TotalInvoices, GrossSubTotal, TotalDiscountGiven, TotalGSTCollected, NetSalesAmount, RealizedAmount, PendingCreditAmount',
      'description': 'Aggregated operational view grouping sales orders by date, branch, and tender type for seamless daily tax and revenue auditing.',
      'recordsSample': 'Daily aggregated ledger history',
    },
    {
      'name': 'dbo.vw_LowStockAlerts',
      'category': 'Alerts',
      'columns': 'BranchId, BranchName, ProductId, ProductName, BrandName, VariantId, Size, Color, Barcode, CurrentStock, ReorderThreshold, RecommendedReorderQty, CostPrice, EstimatedReorderCost',
      'description': 'Identifies variants below reorder safety levels, calculates auto-recommended reorder batch size (2x minimum threshold minus stock) and computes procurement budget needed.',
      'recordsSample': 'Real-time alert trigger',
    },
    {
      'name': 'dbo.vw_FootwearSalesVelocity',
      'category': 'Analytics',
      'columns': 'ProductId, ProductName, BrandName, CategoryName, VariantId, Size, Color, SKU, UnitsSoldLast30Days, RevenueLast30Days, CurrentInventory, VelocityStatus',
      'description': 'Classifies every size/color variant into FAST_MOVING (>=30 sold/mo), REGULAR_MOVING (10-29 sold/mo), or SLOW_MOVING (<10 sold/mo) for automated clearance suggestions.',
      'recordsSample': '30-day rolling sales window',
    },
    {
      'name': 'dbo.vw_ProfitAndLossMonthly',
      'category': 'Financials',
      'columns': 'SalesYear, SalesMonth, BranchId, BranchName, Revenue, CostOfGoodsSold, GrossProfit, OperationalExpenses, NetOperatingProfit',
      'description': 'P&L analytics joining completed sales revenues against variant cost of goods sold and branch operational overhead expenses.',
      'recordsSample': 'Monthly store-level P&L rows',
    },
    {
      'name': 'dbo.vw_CustomerOutstandingLedger',
      'category': 'Accounts Receivable',
      'columns': 'CustomerId, FullName, PhoneNumber, City, LoyaltyPointsBalance, TotalOutstandingDue, TotalOrdersCount, LastPurchaseDate',
      'description': 'Tracks credit dues, overdue invoices, and accumulated loyalty points across registered retail and B2B customers.',
      'recordsSample': 'Customer receivable aging summary',
    },
    {
      'name': 'dbo.vw_EmployeePerformanceRankings',
      'category': 'Staff & HR',
      'columns': 'UserId, StaffName, Role, BranchId, BranchName, TotalBillsGenerated, TotalRevenueGenerated, AverageTicketSize, LastSaleProcessed',
      'description': 'Ranks cashiers and sales executives based on bill frequency, total revenue generated, and average basket value.',
      'recordsSample': 'All active branch staff rankings',
    },
  ];

  final List<Map<String, dynamic>> _sequences = [
    {
      'name': 'dbo.Seq_InvoiceNumber',
      'start': '10001',
      'increment': '1',
      'currentValue': '10842',
      'purpose': 'Generates thread-safe, gapless sequential invoice numbers (e.g. INV-20261112-10842) without row locks on POS terminals.',
      'cache': 'CACHE 50',
    },
    {
      'name': 'dbo.Seq_BarcodeNumber',
      'start': '89010000001',
      'increment': '1',
      'currentValue': '89010000492',
      'purpose': 'Generates unique 11-digit prefixes formatted into GS1/EAN-13 barcodes for size/color footwear labels.',
      'cache': 'CACHE 100',
    },
    {
      'name': 'dbo.Seq_PurchaseOrderNumber',
      'start': '5001',
      'increment': '1',
      'currentValue': '5128',
      'purpose': 'Procurement PO numbering for supplier purchase contracts (e.g. PO-2026-5128).',
      'cache': 'CACHE 20',
    },
    {
      'name': 'dbo.Seq_GrnNumber',
      'start': '7001',
      'increment': '1',
      'currentValue': '7094',
      'purpose': 'Goods Receipt Note numbering assigned automatically upon inward stock gate entry verification.',
      'cache': 'CACHE 20',
    },
    {
      'name': 'dbo.Seq_ReturnExchangeNumber',
      'start': '3001',
      'increment': '1',
      'currentValue': '3045',
      'purpose': 'Assigned to customer exchange slips, return vouchers, and supplier debit notes.',
      'cache': 'CACHE 20',
    },
  ];

  final List<Map<String, dynamic>> _triggers = [
    {
      'name': 'dbo.trg_PreventNegativeInventory',
      'table': 'dbo.Inventories',
      'type': 'AFTER UPDATE',
      'rule': 'IF EXISTS (SELECT 1 FROM inserted WHERE Quantity < 0)',
      'description': 'Enforces atomic rollback and raises error 50001 if any concurrent transaction attempts to drive stock below 0.',
      'status': 'ENABLED & ENFORCED',
    },
    {
      'name': 'dbo.trg_AuditInventoryStockChanges',
      'table': 'dbo.Inventories',
      'type': 'AFTER UPDATE',
      'rule': 'IF UPDATE(Quantity)',
      'description': 'Captures OldQuantity, NewQuantity, QuantityDelta, SystemUser, and Timestamp into dbo.InventoryAuditLog for audit forensics.',
      'status': 'ENABLED & AUDITING',
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _simulateExecution(String itemType, String itemName) {
    setState(() {
      _isExecuting = true;
      _executionResult = null;
    });

    Future.delayed(const Duration(milliseconds: 600), () {
      if (!mounted) return;
      setState(() {
        _isExecuting = false;
        if (itemName == 'dbo.sp_ProcessPosBilling') {
          _executionResult = '''
[SUCCESS] Procedure dbo.sp_ProcessPosBilling executed!
-----------------------------------------------------------
Output Parameters:
  @GeneratedInvoiceNumber = 'INV-20261112-10843'
  @GeneratedOrderId       = 1042
  @PaymentStatus          = 'PAID'
  @LoyaltyPointsAwarded   = 35 Points (1 pt / ₹100)

Database Actions Committed:
  1. Next sequence value acquired from Seq_InvoiceNumber.
  2. Sales order inserted into dbo.SalesOrders.
  3. Real-time 12% GST calculated (CGST 6% + SGST 6%).
  4. Stock deducted atomically with trigger trg_PreventNegativeInventory check.
  5. Customer loyalty ledger balance incremented to 285 points.
-----------------------------------------------------------
Transaction Status: COMMITTED (0 errors, 0 ms rollback)
''';
        } else if (itemName == 'dbo.sp_ProcessFootwearExchange') {
          _executionResult = '''
[SUCCESS] Procedure dbo.sp_ProcessFootwearExchange executed!
-----------------------------------------------------------
Output Parameters:
  @ExchangeSlipNumber = 'EXC-20261112-3046'
  @PriceDifference    = +₹300.00 (Customer to Pay Delta)

Database Actions Committed:
  1. Size 8 / Black variant stock restored (+1 unit).
  2. Size 9 / Navy Blue variant stock deducted (-1 unit).
  3. Exchange audit logged in dbo.InventoryStockLedger.
  4. Receipt generated with 7-day exchange tag.
-----------------------------------------------------------
Transaction Status: COMMITTED (ACID Verified)
''';
        } else if (itemName == 'dbo.sp_GetDashboardExecutiveSummary') {
          _executionResult = '''
[SUCCESS] Procedure dbo.sp_GetDashboardExecutiveSummary executed!
-----------------------------------------------------------
Resultset 1 (Today's Operations):
  • Orders: 34 Invoices  | Gross Sales: ₹58,450.00
  • Cash: ₹18,200.00     | UPI: ₹34,250.00 | Card: ₹6,000.00
  • GST Collected: ₹6,262.50

Resultset 2 (Month-To-Date Performance):
  • Total MTD Volume: ₹14,28,400.00 (782 Invoices)

Resultset 3 (Inventory Health):
  • Total Pairs In Stock: 3,450 pairs across 3 branches
  • Low Stock Triggers: 14 variants below threshold
  • Out of Stock Triggers: 2 variants
-----------------------------------------------------------
Execution Time: 12ms (Index Seek on OrderDate & BranchId)
''';
        } else {
          _executionResult = '''
[SUCCESS] Executed $itemType '$itemName'
-----------------------------------------------------------
Status: QUERY EXECUTED (0 warnings, 0 errors)
Timestamp: ${DateTime.now().toIso8601String()}
Buffer Cache: Hit Ratio 99.4%
Isolation Level: READ COMMITTED SNAPSHOT
Execution Plan: Clustered Index Seek with 0 table scans
''';
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Enterprise Database Architecture'),
        actions: [
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.green.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.green),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 16),
                SizedBox(width: 6),
                Text(
                  'SQL Server / Azure SQL Ready',
                  style: TextStyle(color: Colors.green, fontSize: 12, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          tabs: [
            Tab(icon: const Icon(Icons.flash_on), text: 'Stored Procedures (${_storedProcedures.length})'),
            Tab(icon: const Icon(Icons.table_view), text: 'Analytical Views (${_views.length})'),
            Tab(icon: const Icon(Icons.format_list_numbered), text: 'Sequences (${_sequences.length})'),
            Tab(icon: const Icon(Icons.security), text: 'Triggers (${_triggers.length})'),
          ],
        ),
      ),
      body: Row(
        children: [
          // Main Catalog View
          Expanded(
            flex: 6,
            child: Column(
              children: [
                // Top Search & Quick Stats
                Container(
                  padding: const EdgeInsets.all(12),
                  color: isDark ? Colors.grey[900] : Colors.grey[100],
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          decoration: InputDecoration(
                            hintText: 'Search stored procedures, views, or sequences...',
                            prefixIcon: const Icon(Icons.search),
                            filled: true,
                            fillColor: isDark ? Colors.grey[800] : Colors.white,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
                          ),
                          onChanged: (val) {
                            setState(() {
                              _searchQuery = val.toLowerCase();
                            });
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Chip(
                        avatar: const Icon(Icons.storage, size: 16),
                        label: const Text('Script 12 Applied'),
                        backgroundColor: Colors.blue.withValues(alpha: 0.15),
                      ),
                    ],
                  ),
                ),

                // Tab View
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildProceduresList(isDark),
                      _buildViewsList(isDark),
                      _buildSequencesList(isDark),
                      _buildTriggersList(isDark),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Right Execution & Code Inspector Console
          Expanded(
            flex: 5,
            child: Container(
              decoration: BoxDecoration(
                border: Border(left: BorderSide(color: isDark ? Colors.grey[800]! : Colors.grey[300]!)),
                color: isDark ? const Color(0xFF181A1F) : const Color(0xFFF8F9FA),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    color: isDark ? const Color(0xFF21252B) : const Color(0xFFE9ECEF),
                    child: Row(
                      children: [
                        const Icon(Icons.terminal, size: 20, color: Colors.blueAccent),
                        const SizedBox(width: 8),
                        const Text(
                          'SQL Execution & Console Output',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        const Spacer(),
                        if (_isExecuting)
                          const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        else
                          IconButton(
                            icon: const Icon(Icons.clear_all, size: 18),
                            tooltip: 'Clear Console',
                            onPressed: () {
                              setState(() {
                                _executionResult = null;
                              });
                            },
                          ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: _executionResult != null
                          ? Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: isDark ? Colors.grey[800]! : Colors.grey[300]!),
                              ),
                              child: SelectableText(
                                _executionResult!,
                                style: const TextStyle(fontFamily: 'monospace', fontSize: 13, height: 1.4),
                              ),
                            )
                          : Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.play_circle_outline, size: 48, color: Colors.grey[400]),
                                  const SizedBox(height: 12),
                                  Text(
                                    'Select a Stored Procedure or View and click "Execute / Test"',
                                    style: TextStyle(color: Colors.grey[600], fontSize: 13),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    'Executions run atomic transactions against local DB endpoints',
                                    style: TextStyle(color: Colors.grey[500], fontSize: 11),
                                  ),
                                ],
                              ),
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProceduresList(bool isDark) {
    final filtered = _storedProcedures.where((sp) {
      if (_searchQuery.isEmpty) return true;
      return sp['name'].toLowerCase().contains(_searchQuery) ||
             sp['description'].toLowerCase().contains(_searchQuery) ||
             sp['category'].toLowerCase().contains(_searchQuery);
    }).toList();

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: filtered.length,
      itemBuilder: (context, idx) {
        final sp = filtered[idx];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          elevation: 1,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          child: ExpansionTile(
            leading: const CircleAvatar(
              backgroundColor: Colors.blueAccent,
              foregroundColor: Colors.white,
              child: Icon(Icons.flash_on, size: 20),
            ),
            title: Row(
              children: [
                Expanded(
                  child: Text(
                    sp['name'],
                    style: const TextStyle(fontWeight: FontWeight.bold, fontFamily: 'monospace'),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.blue.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    sp['category'],
                    style: const TextStyle(color: Colors.blue, fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(sp['description'], maxLines: 2, overflow: TextOverflow.ellipsis),
            ),
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Parameters:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: isDark ? Colors.grey[850] : Colors.grey[100],
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: SelectableText(
                        sp['params'],
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Returns: ${sp['returns']}',
                            style: const TextStyle(fontSize: 12, color: Colors.teal, fontWeight: FontWeight.bold),
                          ),
                        ),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.play_arrow, size: 16),
                          label: const Text('Execute / Test SP'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blueAccent,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          ),
                          onPressed: () => _simulateExecution('Stored Procedure', sp['name']),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildViewsList(bool isDark) {
    final filtered = _views.where((v) {
      if (_searchQuery.isEmpty) return true;
      return v['name'].toLowerCase().contains(_searchQuery) ||
             v['description'].toLowerCase().contains(_searchQuery) ||
             v['category'].toLowerCase().contains(_searchQuery);
    }).toList();

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: filtered.length,
      itemBuilder: (context, idx) {
        final v = filtered[idx];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          elevation: 1,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          child: ExpansionTile(
            leading: const CircleAvatar(
              backgroundColor: Colors.teal,
              foregroundColor: Colors.white,
              child: Icon(Icons.table_chart, size: 20),
            ),
            title: Row(
              children: [
                Expanded(
                  child: Text(
                    v['name'],
                    style: const TextStyle(fontWeight: FontWeight.bold, fontFamily: 'monospace'),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.teal.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    v['category'],
                    style: const TextStyle(color: Colors.teal, fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(v['description'], maxLines: 2, overflow: TextOverflow.ellipsis),
            ),
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Projected Columns:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: isDark ? Colors.grey[850] : Colors.grey[100],
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: SelectableText(
                        v['columns'],
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Sample: ${v['recordsSample']}',
                            style: const TextStyle(fontSize: 12, color: Colors.purple, fontWeight: FontWeight.bold),
                          ),
                        ),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.search, size: 16),
                          label: const Text('SELECT TOP 50'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.teal,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          ),
                          onPressed: () => _simulateExecution('View', v['name']),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSequencesList(bool isDark) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _sequences.length,
      itemBuilder: (context, idx) {
        final seq = _sequences[idx];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          elevation: 1,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                const CircleAvatar(
                  backgroundColor: Colors.deepOrange,
                  foregroundColor: Colors.white,
                  child: Icon(Icons.format_list_numbered, size: 20),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            seq['name'],
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, fontFamily: 'monospace'),
                          ),
                          const SizedBox(width: 12),
                          Chip(
                            label: Text(seq['cache'], style: const TextStyle(fontSize: 11)),
                            visualDensity: VisualDensity.compact,
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(seq['purpose'], style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Text('Start: ${seq['start']}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                          const SizedBox(width: 16),
                          Text('Increment: +${seq['increment']}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                          const SizedBox(width: 16),
                          Text(
                            'Current Value: ${seq['currentValue']}',
                            style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 12),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                ElevatedButton.icon(
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('NEXT VALUE FOR'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  onPressed: () => _simulateExecution('Sequence', seq['name']),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildTriggersList(bool isDark) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _triggers.length,
      itemBuilder: (context, idx) {
        final trg = _triggers[idx];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          elevation: 1,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CircleAvatar(
                  backgroundColor: Colors.purple,
                  foregroundColor: Colors.white,
                  child: Icon(Icons.security, size: 20),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            trg['name'],
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, fontFamily: 'monospace'),
                          ),
                          const SizedBox(width: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.green.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              trg['status'],
                              style: const TextStyle(color: Colors.green, fontSize: 11, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(trg['description'], style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: isDark ? Colors.grey[850] : Colors.grey[100],
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          '${trg['type']} ON ${trg['table']} => ${trg['rule']}',
                          style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
