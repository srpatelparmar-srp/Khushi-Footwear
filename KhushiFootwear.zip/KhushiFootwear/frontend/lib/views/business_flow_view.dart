import 'package:flutter/material.dart';

class BusinessFlowView extends StatefulWidget {
  final bool isDesktop;

  const BusinessFlowView({super.key, required this.isDesktop});

  @override
  State<BusinessFlowView> createState() => _BusinessFlowViewState();
}

class _BusinessFlowViewState extends State<BusinessFlowView> {
  int _currentStep = 0;

  final List<Map<String, dynamic>> _flowSteps = [
    {
      'step': 1,
      'title': 'Super Admin creates shop and owner',
      'role': 'Super Admin',
      'icon': Icons.admin_panel_settings,
      'color': const Color(0xFF4F46E5),
      'description': 'Super Admin registers "Khushi Footwear Pvt. Ltd.", sets up the Pune Central Flagship outlet, and creates the Shop Owner account for Rajesh Khushi with master tenant credentials.',
      'dbTables': 'Shops, Branches, Users, Roles, AuditLogs',
      'apiEndpoint': 'POST /api/SuperAdmin/shops & POST /api/SuperAdmin/users',
      'status': 'COMPLETED',
      'output': 'Created Shop #1 ("Khushi Footwear"), Branch #1 ("Pune Flagship"), Owner User #2 ("rajesh.owner")',
    },
    {
      'step': 2,
      'title': 'Owner creates employees and assigns roles',
      'role': 'Shop Owner',
      'icon': Icons.people,
      'color': Colors.blue,
      'description': 'Shop Owner sets up store staff: Store Manager (Sunil Patil), Head Cashier (Anita Deshmukh), Inventory Manager (Vikram Shinde), and Sales Executive (Rahul Joshi) with branch bindings.',
      'dbTables': 'Users, Roles (9 Granular Roles), AuditLogs',
      'apiEndpoint': 'POST /api/Auth/register & GET /api/ShopOwner/employees',
      'status': 'COMPLETED',
      'output': '4 Store Staff onboarded with encrypted credentials, assigned roles and salary structures.',
    },
    {
      'step': 3,
      'title': 'Owner adds brands, categories and products',
      'role': 'Shop Owner',
      'icon': Icons.snowshoeing,
      'color': Colors.indigo,
      'description': 'Owner populates footwear catalog: Brands (Nike, Adidas, Puma, Bata, Woodland), Categories (Sports, Formal, Casual, Outdoor), Sizes (UK 6-11), Colors, MRP, and unique SKUs & Barcodes.',
      'dbTables': 'Brands, Categories, ShoeSizes, ShoeColors, Products, ProductVariants',
      'apiEndpoint': 'POST /api/SuperAdmin/brands & POST /api/Erp/products',
      'status': 'COMPLETED',
      'output': 'Configured 84 shoe models across sizes UK 6 to 11 with EAN-13 barcodes generated.',
    },
    {
      'step': 4,
      'title': 'Purchase Manager creates purchase orders',
      'role': 'Purchase Manager',
      'icon': Icons.shopping_cart_checkout,
      'color': Colors.teal,
      'description': 'Purchase Manager creates wholesale Purchase Order #PO-2026-088 for Nike India Wholesale Ltd. requesting 180 pairs of Air Max 270 (UK 8, 9, 10) valued at ₹ 1,42,000.00.',
      'dbTables': 'Suppliers, PurchaseOrders, PurchaseOrderItems',
      'apiEndpoint': 'POST /api/PurchaseManager/orders',
      'status': 'COMPLETED',
      'output': 'PO-2026-088 submitted for manufacturer shipment with 15-day credit terms.',
    },
    {
      'step': 5,
      'title': 'Inventory Manager receives products and updates stock',
      'role': 'Inventory Manager',
      'icon': Icons.inventory,
      'color': Colors.amber.shade900,
      'description': 'Inventory Manager inspects factory delivery at warehouse, conducts barcode box verification, accepts shipment via GRN #GRN-088, and updates shelf inventory automatically.',
      'dbTables': 'Inventory, StockLedger, GoodsReceiptNotes',
      'apiEndpoint': 'POST /api/InventoryManager/grn/inward',
      'status': 'COMPLETED',
      'output': '180 Pairs added to inventory ledger; physical shelf stock reflected across UK 8, 9, 10.',
    },
    {
      'step': 6,
      'title': 'Cashier generates customer bills',
      'role': 'Cashier',
      'icon': Icons.point_of_sale,
      'color': Colors.green,
      'description': 'Customer Amit Saxena walks into the showroom. Cashier Anita Deshmukh scans shoe box barcode (8901234567890) for Nike Air Max 270 UK 9 and adds care kit spray.',
      'dbTables': 'SalesInvoices, SalesInvoiceItems, CashCounterShifts',
      'apiEndpoint': 'POST /api/Erp/barcode/scan & POST /api/Cashier/pos/checkout',
      'status': 'COMPLETED',
      'output': 'Invoice #KF-INV-88231 generated; customer selected UPI digital payment.',
    },
    {
      'step': 7,
      'title': 'System calculates GST and payments',
      'role': 'System Automation',
      'icon': Icons.calculate,
      'color': Colors.purple,
      'description': 'POS engine automatically computes GST under HSN 6404 (CGST 6% = ₹ 569.64 + SGST 6% = ₹ 569.64 = Total GST ₹ 1,139.28). Applies coupon "FESTIVE10" (-₹ 949.00) and prints thermal receipt.',
      'dbTables': 'TaxSettings, SalesInvoices, InvoicePayments',
      'apiEndpoint': 'POST /api/Erp/pos/checkout',
      'status': 'COMPLETED',
      'output': 'Tax breakdown computed; ₹ 9,494.00 collected via UPI; thermal receipt printed.',
    },
    {
      'step': 8,
      'title': 'System automatically updates inventory',
      'role': 'System Automation',
      'icon': Icons.sync,
      'color': Colors.deepOrange,
      'description': 'Simultaneously on invoice settlement, the inventory system atomicaly decrements Nike Air Max 270 (UK 9 - Pure White) stock from 7 pairs to 6 pairs. Outward stock ledger recorded.',
      'dbTables': 'Inventory, StockLedger, AuditLogs',
      'apiEndpoint': 'Database Trigger / StockLedger Atomic Deduction',
      'status': 'COMPLETED',
      'output': 'Live stock updated on shelf and showroom matrix without manual intervention.',
    },
    {
      'step': 9,
      'title': 'Accountant manages income and expenses',
      'role': 'Accountant',
      'icon': Icons.account_balance_wallet,
      'color': Colors.cyan.shade800,
      'description': 'Accountant Mahesh Jadhav reconciles daily cashbook (₹ 37,230 cash in safe + ₹ 96,798 UPI in HDFC A/C), approves showroom rent expense voucher (₹ 32,000), and records GST ITC.',
      'dbTables': 'CashbookLedgers, BankTransactions, Expenses, SalaryDisbursements',
      'apiEndpoint': 'GET /api/Accountant/cashbook & POST /api/Accountant/expenses',
      'status': 'COMPLETED',
      'output': 'Cashbook balanced; operating expenses audited; Input Tax Credit ledger posted.',
    },
    {
      'step': 10,
      'title': 'Owner monitors business performance through dashboard and reports',
      'role': 'Shop Owner',
      'icon': Icons.insights,
      'color': Colors.green.shade800,
      'description': 'Shop Owner opens the mobile/desktop app to review real-time revenue (₹ 1,48,920 today), checks gross profit margin (37.8%), reviews stock alerts, and downloads 23 automated reports.',
      'dbTables': 'DailyClosingReports, SalesInvoices, Inventory, 23 Analytics Reports',
      'apiEndpoint': 'GET /api/ShopOwner/dashboard-summary & GET /api/Reports/profit-and-loss',
      'status': 'COMPLETED',
      'output': 'Owner has 100% full visibility into cash, profit, stock aging, and employee rankings.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('7. Main Business Flow Lifecycle', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF0F172A))),
                  Text('Step-by-step end-to-end enterprise lifecycle of Khushi Footwear Shop across all 9 roles and system automation', style: TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4F46E5), foregroundColor: Colors.white),
                onPressed: () {
                  setState(() {
                    _currentStep = (_currentStep + 1) % _flowSteps.length;
                  });
                },
                icon: const Icon(Icons.play_arrow, size: 16),
                label: Text('Next Stage (Step ${_currentStep + 1}/10)'),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Lifecycle Progress Stepper Bar
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Enterprise Lifecycle Progression: Stage ${_currentStep + 1} of 10', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    Text('${((_currentStep + 1) * 10)}% Flow Complete', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF4F46E5), fontSize: 12)),
                  ],
                ),
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: (_currentStep + 1) / 10.0,
                  minHeight: 8,
                  borderRadius: BorderRadius.circular(4),
                  color: const Color(0xFF4F46E5),
                  backgroundColor: const Color(0xFFEEF2FF),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // 10 Detailed Stages List
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _flowSteps.length,
            itemBuilder: (context, idx) {
              final step = _flowSteps[idx];
              final isCurrent = _currentStep == idx;
              final isPast = _currentStep > idx;
              final col = step['color'] as Color;

              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(
                    color: isCurrent ? col : (isPast ? Colors.green.shade300 : Colors.grey.shade200),
                    width: isCurrent ? 2.0 : 1.0,
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          CircleAvatar(
                            radius: 18,
                            backgroundColor: col.withValues(alpha: 0.12),
                            child: Icon(step['icon'] as IconData, color: col, size: 20),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(color: col.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)),
                                      child: Text('STAGE ${step['step']}', style: TextStyle(color: col, fontWeight: FontWeight.bold, fontSize: 10)),
                                    ),
                                    const SizedBox(width: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(4)),
                                      child: Text('ROLE: ${step['role']}', style: TextStyle(color: Colors.grey.shade800, fontWeight: FontWeight.bold, fontSize: 10)),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Text(step['title'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: isPast ? Colors.green.shade50 : (isCurrent ? col.withValues(alpha: 0.1) : Colors.grey.shade100),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              isPast ? 'COMPLETED' : (isCurrent ? 'ACTIVE STAGE' : 'PENDING'),
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: isPast ? Colors.green : (isCurrent ? col : Colors.grey),
                              ),
                            ),
                          )
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(step['description'], style: TextStyle(color: Colors.grey.shade800, fontSize: 12)),
                      const Divider(height: 20),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('Database Tables Involved:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10, color: Colors.grey)),
                                Text(step['dbTables'], style: const TextStyle(fontSize: 11, fontFamily: 'monospace')),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('REST API Endpoints Executed:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10, color: Colors.grey)),
                                Text(step['apiEndpoint'], style: const TextStyle(fontSize: 11, fontFamily: 'monospace', color: Color(0xFF4F46E5))),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(6)),
                        child: Row(
                          children: [
                            const Icon(Icons.done_all, color: Colors.green, size: 16),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text('Execution Output: ${step['output']}', style: TextStyle(fontSize: 11, color: Colors.grey.shade700, fontWeight: FontWeight.w500)),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
