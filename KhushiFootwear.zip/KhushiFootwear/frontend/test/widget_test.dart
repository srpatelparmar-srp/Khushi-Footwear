import 'package:flutter_test/flutter_test.dart';
import 'package:khushi_footwear/main.dart';

void main() {
  testWidgets('Khushi Footwear app initial smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const KhushiFootwearApp());
    expect(find.text('KHUSHI FOOTWEAR'), findsWidgets);
  });
}
