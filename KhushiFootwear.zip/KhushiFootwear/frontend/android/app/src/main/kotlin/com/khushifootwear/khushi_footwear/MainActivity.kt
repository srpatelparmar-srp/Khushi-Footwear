package com.khushifootwear.khushi_footwear

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
