using System.ComponentModel.DataAnnotations;

namespace KhushiFootwear.API.Models
{
    public class Role
    {
        [Key]
        public int RoleId { get; set; }
        [Required, MaxLength(50)]
        public string RoleName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public bool IsActive { get; set; } = true;
    }

    public class Shop
    {
        [Key]
        public int ShopId { get; set; }
        [Required, MaxLength(20)]
        public string ShopCode { get; set; } = string.Empty;
        [Required, MaxLength(150)]
        public string ShopName { get; set; } = string.Empty;
        public string OwnerName { get; set; } = string.Empty;
        public string ContactNumber { get; set; } = string.Empty;
        public string? Email { get; set; }
        public string? GSTIN { get; set; }
        public string? Address { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public bool IsActive { get; set; } = true;
    }

    public class Branch
    {
        [Key]
        public int BranchId { get; set; }
        public int ShopId { get; set; }
        public string BranchCode { get; set; } = string.Empty;
        public string BranchName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public bool IsMainBranch { get; set; }
        public bool IsActive { get; set; } = true;
    }

    public class User
    {
        [Key]
        public int UserId { get; set; }
        public int? ShopId { get; set; }
        public int? BranchId { get; set; }
        public int RoleId { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public decimal CommissionRate { get; set; } = 0.00m;
        public decimal Salary { get; set; } = 0.00m;
        public bool IsActive { get; set; } = true;
    }

    public class Brand
    {
        [Key]
        public int BrandId { get; set; }
        public int? ShopId { get; set; }
        public string BrandName { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
    }

    public class Category
    {
        [Key]
        public int CategoryId { get; set; }
        public int? ShopId { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public string? GenderTarget { get; set; }
        public bool IsActive { get; set; } = true;
    }

    public class ShoeSize
    {
        [Key]
        public int SizeId { get; set; }
        public string SizeStandard { get; set; } = "UK/IND";
        public string SizeValue { get; set; } = string.Empty;
        public string SizeNumber { get; set; } = string.Empty;
        public string StandardUnit { get; set; } = "UK";
    }

    public class ShoeColor
    {
        [Key]
        public int ColorId { get; set; }
        public string ColorName { get; set; } = string.Empty;
        public string HexCode { get; set; } = string.Empty;
        public string ColorHex { get; set; } = string.Empty;
    }

    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        public int ShopId { get; set; }
        public int BrandId { get; set; }
        public int CategoryId { get; set; }
        public string ProductCode { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public string? ModelNumber { get; set; }
        public string? Brand { get; set; }
        public string? ArticleNumber { get; set; }
        public string? ImageUrl { get; set; }
        public decimal GSTPercentage { get; set; } = 12.00m;
        public decimal BasePrice { get; set; }
        public decimal MRP { get; set; }
        public bool IsActive { get; set; } = true;
    }

    public class ProductVariant
    {
        [Key]
        public int VariantId { get; set; }
        public int ProductId { get; set; }
        public int SizeId { get; set; }
        public int ColorId { get; set; }
        public string SKU { get; set; } = string.Empty;
        public string Barcode { get; set; } = string.Empty;
        public decimal PurchasePrice { get; set; }
        public decimal SellingPrice { get; set; }
        public decimal MRP { get; set; }
        public bool IsActive { get; set; } = true;
    }

    public class Inventory
    {
        [Key]
        public int InventoryId { get; set; }
        public int BranchId { get; set; }
        public int VariantId { get; set; }
        public int QuantityOnHand { get; set; }
        public int MinStockAlert { get; set; } = 5;
    }

    public class Customer
    {
        [Key]
        public int CustomerId { get; set; }
        public int ShopId { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string Mobile { get; set; } = string.Empty;
        public string? PreferredShoeSize { get; set; }
        public int LoyaltyPoints { get; set; } = 0;
        public decimal OutstandingBalance { get; set; } = 0.00m;
    }

    public class Supplier
    {
        [Key]
        public int SupplierId { get; set; }
        public int ShopId { get; set; }
        public string SupplierName { get; set; } = string.Empty;
        public string ContactPerson { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string? GSTIN { get; set; }
        public decimal OutstandingAmount { get; set; } = 0.00m;
        public bool IsActive { get; set; } = true;
    }

    public class SalesInvoice
    {
        [Key]
        public long InvoiceId { get; set; }
        public string InvoiceNumber { get; set; } = string.Empty;
        public int BranchId { get; set; }
        public int? CustomerId { get; set; }
        public int CashierUserId { get; set; }
        public int? SalesExecutiveId { get; set; }
        public decimal SubTotal { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }
        public decimal GrandTotal { get; set; }
        public string PaymentMode { get; set; } = "CASH";
        public string Status { get; set; } = "CONFIRMED";
        public string? CustomerMobile { get; set; }
        public DateTime InvoiceDate { get; set; } = DateTime.UtcNow;
    }

    public class PurchaseOrder
    {
        [Key]
        public long PurchaseOrderId { get; set; }
        public string PONumber { get; set; } = string.Empty;
        public int ShopId { get; set; }
        public int BranchId { get; set; }
        public int SupplierId { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal PaidAmount { get; set; }
        public string Status { get; set; } = "PENDING";
        public DateTime OrderDate { get; set; } = DateTime.UtcNow;
    }

    public class PurchaseInvoice
    {
        [Key]
        public long PurchaseInvoiceId { get; set; }
        public string InvoiceNumber { get; set; } = string.Empty;
        public long? PurchaseOrderId { get; set; }
        public int SupplierId { get; set; }
        public int BranchId { get; set; }
        public DateTime InvoiceDate { get; set; } = DateTime.UtcNow.Date;
        public decimal SubTotal { get; set; }
        public decimal GSTAmount { get; set; }
        public decimal GrandTotal { get; set; }
        public decimal PaidAmount { get; set; } = 0.00m;
        public decimal OutstandingBalance { get; set; }
        public string PaymentStatus { get; set; } = "PENDING";
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class PurchaseReturn
    {
        [Key]
        public long ReturnId { get; set; }
        public string DebitNoteNumber { get; set; } = string.Empty;
        public int SupplierId { get; set; }
        public int VariantId { get; set; }
        public int Quantity { get; set; }
        public decimal UnitCost { get; set; }
        public decimal TotalRefundAmount { get; set; }
        public string Reason { get; set; } = string.Empty;
        public string Status { get; set; } = "APPROVED";
        public int CreatedByUserId { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class SupplierPayment
    {
        [Key]
        public long PaymentId { get; set; }
        public string PaymentNumber { get; set; } = string.Empty;
        public int SupplierId { get; set; }
        public decimal AmountPaid { get; set; }
        public string PaymentMode { get; set; } = "NEFT";
        public string? TransactionRefNumber { get; set; }
        public DateTime PaymentDate { get; set; } = DateTime.UtcNow.Date;
        public string? Remarks { get; set; }
        public int RecordedByUserId { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class Expense
    {
        [Key]
        public long ExpenseId { get; set; }
        public int ShopId { get; set; }
        public int BranchId { get; set; }
        public decimal Amount { get; set; }
        public string PaymentMode { get; set; } = "CASH";
        public string? Description { get; set; }
        public DateTime ExpenseDate { get; set; } = DateTime.UtcNow;
    }

    public class ReturnOrExchange
    {
        [Key]
        public long ReturnId { get; set; }
        public string ReturnNumber { get; set; } = string.Empty;
        public long OriginalInvoiceId { get; set; }
        public string Type { get; set; } = "SIZE_EXCHANGE";
        public int ReturnedVariantId { get; set; }
        public int? ExchangedVariantId { get; set; }
        public int Quantity { get; set; } = 1;
        public decimal RefundAmount { get; set; } = 0.00m;
        public string? Reason { get; set; }
        public string ActionTaken { get; set; } = "PENDING_APPROVAL";
        public DateTime ReturnDate { get; set; } = DateTime.UtcNow;
    }

    // ACCOUNTANT SPECIFIC MODELS
    public class CashbookLedger
    {
        [Key]
        public long EntryId { get; set; }
        public int BranchId { get; set; }
        public DateTime TransactionDate { get; set; } = DateTime.UtcNow.Date;
        public string VoucherNumber { get; set; } = string.Empty;
        public string EntryType { get; set; } = "INFLOW_RECEIPT"; // INFLOW_RECEIPT, OUTFLOW_PAYMENT
        public string AccountHead { get; set; } = "POS_CASH_SALES";
        public decimal Amount { get; set; }
        public string? Narration { get; set; }
        public int RecordedByUserId { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class BankTransaction
    {
        [Key]
        public long TxnId { get; set; }
        public string BankName { get; set; } = "HDFC Bank Ltd";
        public string AccountNumber { get; set; } = "50200012345678";
        public DateTime TxnDate { get; set; } = DateTime.UtcNow.Date;
        public string ReferenceNumber { get; set; } = string.Empty;
        public string TxnType { get; set; } = "DEPOSIT"; // DEPOSIT, WITHDRAWAL, UPI_COLLECTION
        public decimal Amount { get; set; }
        public string ReconciliationStatus { get; set; } = "RECONCILED"; // PENDING, RECONCILED
        public string? Description { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class SalaryDisbursement
    {
        [Key]
        public long SalaryId { get; set; }
        public int UserId { get; set; }
        public string MonthYear { get; set; } = "October 2026";
        public decimal BasicSalary { get; set; }
        public decimal CommissionAmount { get; set; } = 0.00m;
        public decimal Deductions { get; set; } = 0.00m;
        public decimal NetSalaryPaid { get; set; }
        public string PaymentMode { get; set; } = "BANK_TRANSFER";
        public DateTime DisbursedDate { get; set; } = DateTime.UtcNow.Date;
        public string Status { get; set; } = "PAID";
        public int ProcessedByUserId { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    // INVENTORY MANAGER SPECIFIC MODELS
    public class StockAudit
    {
        [Key]
        public long AuditId { get; set; }
        public string AuditNumber { get; set; } = string.Empty;
        public int BranchId { get; set; }
        public DateTime AuditDate { get; set; } = DateTime.UtcNow.Date;
        public int AuditorUserId { get; set; }
        public int TotalItemsScanned { get; set; }
        public int DiscrepancyCount { get; set; }
        public string Status { get; set; } = "COMPLETED";
        public string? AuditNotes { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class DamagedProduct
    {
        [Key]
        public long DamageId { get; set; }
        public string DamageNumber { get; set; } = string.Empty;
        public int BranchId { get; set; }
        public int VariantId { get; set; }
        public int Quantity { get; set; } = 1;
        public string DamageType { get; set; } = "SOLE_PEEL";
        public string ActionTaken { get; set; } = "RETURN_TO_VENDOR";
        public int ReportedByUserId { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    // CASHIER / POS SPECIFIC MODELS
    public class CashCounterShift
    {
        [Key]
        public long ShiftId { get; set; }
        public int BranchId { get; set; }
        public string CounterNumber { get; set; } = "Counter 1";
        public int CashierUserId { get; set; }
        public DateTime OpenedAt { get; set; } = DateTime.UtcNow;
        public DateTime? ClosedAt { get; set; }
        public decimal OpeningFloatCash { get; set; }
        public decimal TotalCashCollected { get; set; }
        public decimal TotalUPICollected { get; set; }
        public decimal TotalCardCollected { get; set; }
        public decimal TotalCreditSales { get; set; }
        public decimal TotalSalesReturns { get; set; }
        public decimal? ClosingPhysicalCashCounted { get; set; }
        public decimal CashDiscrepancy { get; set; } = 0.00m;
        public string ShiftStatus { get; set; } = "OPEN";
        public string? CashierNotes { get; set; }
    }

    public class InvoicePayment
    {
        [Key]
        public long PaymentId { get; set; }
        public long InvoiceId { get; set; }
        public string PaymentMode { get; set; } = "CASH";
        public decimal AmountPaid { get; set; }
        public string? TransactionRefNumber { get; set; }
        public string? CardLast4Digits { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class InvoiceDispatch
    {
        [Key]
        public long DispatchId { get; set; }
        public long InvoiceId { get; set; }
        public string RecipientMobile { get; set; } = string.Empty;
        public string DispatchChannel { get; set; } = "WHATSAPP";
        public string? PdfUrl { get; set; }
        public string DeliveryStatus { get; set; } = "SENT";
        public DateTime SentAt { get; set; } = DateTime.UtcNow;
    }

    // STORE MANAGER SPECIFIC MODELS
    public class StockAdjustment
    {
        [Key]
        public long AdjustmentId { get; set; }
        public string AdjustmentNumber { get; set; } = string.Empty;
        public int BranchId { get; set; }
        public int VariantId { get; set; }
        public int CurrentStock { get; set; }
        public int AdjustedQuantity { get; set; }
        public int NewStock { get; set; }
        public string Reason { get; set; } = string.Empty;
        public int RequestedByUserId { get; set; }
        public int? ApprovedByUserId { get; set; }
        public string Status { get; set; } = "PENDING";
        public string? ApprovalNotes { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? ApprovedAt { get; set; }
    }

    public class StockTransfer
    {
        [Key]
        public long TransferId { get; set; }
        public string TransferNumber { get; set; } = string.Empty;
        public int SourceBranchId { get; set; }
        public int DestinationBranchId { get; set; }
        public int VariantId { get; set; }
        public int Quantity { get; set; }
        public string Status { get; set; } = "IN_TRANSIT";
        public int DispatchedByUserId { get; set; }
        public int? ReceivedByUserId { get; set; }
        public DateTime DispatchDate { get; set; } = DateTime.UtcNow;
        public DateTime? ReceivedDate { get; set; }
    }

    public class EmployeeAttendance
    {
        [Key]
        public long AttendanceId { get; set; }
        public int BranchId { get; set; }
        public int UserId { get; set; }
        public DateTime WorkDate { get; set; } = DateTime.UtcNow.Date;
        public TimeSpan? CheckInTime { get; set; }
        public TimeSpan? CheckOutTime { get; set; }
        public string Status { get; set; } = "PRESENT";
        public string? Remarks { get; set; }
    }

    public class DiscountApproval
    {
        [Key]
        public long ApprovalId { get; set; }
        public int BranchId { get; set; }
        public int RequestedByCashierId { get; set; }
        public int? ApprovedByManagerId { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public decimal InvoiceAmount { get; set; }
        public decimal DiscountRequestedPercent { get; set; }
        public decimal DiscountAmount { get; set; }
        public string Reason { get; set; } = string.Empty;
        public string Status { get; set; } = "PENDING";
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class DailyClosingReport
    {
        [Key]
        public long ReportId { get; set; }
        public int BranchId { get; set; }
        public DateTime ClosingDate { get; set; } = DateTime.UtcNow.Date;
        public decimal OpeningCashBalance { get; set; }
        public decimal TotalCashCollected { get; set; }
        public decimal TotalUPICollected { get; set; }
        public decimal TotalCardCollected { get; set; }
        public decimal TotalDailySales { get; set; }
        public decimal TotalDayExpenses { get; set; }
        public decimal ClosingPhysicalCash { get; set; }
        public decimal CashShortageOrSurplus { get; set; }
        public int TotalPairsSold { get; set; }
        public int TotalReturnsProcessed { get; set; }
        public int ClosedByManagerId { get; set; }
        public string? ManagerNotes { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    // SHOP OWNER SPECIFIC MODELS
    public class DiscountAndOffer
    {
        [Key]
        public int OfferId { get; set; }
        public int ShopId { get; set; }
        public string OfferTitle { get; set; } = string.Empty;
        public string OfferCode { get; set; } = string.Empty;
        public string OfferType { get; set; } = "PERCENTAGE";
        public decimal DiscountValue { get; set; }
        public decimal MinOrderAmount { get; set; } = 0.00m;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool IsActive { get; set; } = true;
    }

    public class CustomerCreditLedger
    {
        [Key]
        public long CreditId { get; set; }
        public int CustomerId { get; set; }
        public int ShopId { get; set; }
        public long? InvoiceId { get; set; }
        public string TransactionType { get; set; } = "CREDIT_ISSUED";
        public decimal Amount { get; set; }
        public decimal BalanceRemaining { get; set; }
        public string? PaymentMode { get; set; }
        public string? Notes { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class ShopBusinessSetting
    {
        [Key]
        public int ShopSettingId { get; set; }
        public int ShopId { get; set; }
        public string InvoicePrefix { get; set; } = "KF-INV-";
        public string InvoiceFooterNote { get; set; } = "Thank you for shopping at Khushi Footwear! Exchange valid within 7 days.";
        public bool EnableWhatsAppBill { get; set; } = true;
        public bool EnableLoyaltyProgram { get; set; } = true;
        public int PointsPerHundredRupees { get; set; } = 2;
        public decimal MaxDiscountApprovalPercent { get; set; } = 15.00m;
        public int LowStockThresholdDefault { get; set; } = 5;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }

    // SUPER ADMIN SPECIFIC MODELS
    public class SubscriptionPlan
    {
        [Key]
        public int PlanId { get; set; }
        public string PlanName { get; set; } = string.Empty;
        public string BillingCycle { get; set; } = "MONTHLY";
        public decimal Price { get; set; }
        public int MaxShops { get; set; } = 1;
        public int MaxBranches { get; set; } = 3;
        public int MaxUsers { get; set; } = 10;
        public string? Features { get; set; }
        public bool IsActive { get; set; } = true;
    }

    public class TaxSetting
    {
        [Key]
        public int TaxSettingId { get; set; }
        public string TaxName { get; set; } = string.Empty;
        public decimal CGSTRate { get; set; } = 6.00m;
        public decimal SGSTRate { get; set; } = 6.00m;
        public decimal IGSTRate { get; set; } = 12.00m;
        public decimal FootwearPriceThreshold { get; set; } = 1000.00m;
        public decimal BelowThresholdRate { get; set; } = 5.00m;
        public decimal AboveThresholdRate { get; set; } = 12.00m;
        public bool IsActive { get; set; } = true;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }

    public class SystemSetting
    {
        [Key]
        public int SettingId { get; set; }
        public string SettingKey { get; set; } = string.Empty;
        public string SettingValue { get; set; } = string.Empty;
        public string Category { get; set; } = "GENERAL";
        public string? Description { get; set; }
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }

    public class DatabaseBackup
    {
        [Key]
        public long BackupId { get; set; }
        public string BackupName { get; set; } = string.Empty;
        public string FileName { get; set; } = string.Empty;
        public long FileSizeBytes { get; set; }
        public string BackupType { get; set; } = "FULL";
        public string StoragePath { get; set; } = string.Empty;
        public string Status { get; set; } = "COMPLETED";
        public string InitiatedBy { get; set; } = "Super Admin";
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class AuditLog
    {
        [Key]
        public long LogId { get; set; }
        public int? ShopId { get; set; }
        public int? UserId { get; set; }
        public string Action { get; set; } = string.Empty;
        public string TableName { get; set; } = string.Empty;
        public string? RecordId { get; set; }
        public string? OldValues { get; set; }
        public string? NewValues { get; set; }
        public string? IpAddress { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }

    // SALES EXECUTIVE SPECIFIC MODELS
    public class CustomerEnquiry
    {
        [Key]
        public int EnquiryId { get; set; }
        public int? CustomerId { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public string CustomerPhone { get; set; } = string.Empty;
        public string? PreferredBrand { get; set; }
        public string? PreferredSize { get; set; }
        public string? PreferredColor { get; set; }
        public string? Notes { get; set; }
        public string Status { get; set; } = "OPEN"; // OPEN, FOLLOWED_UP, CONVERTED_TO_SALE, LOST
        public int AssignedExecutiveId { get; set; }
        public DateTime? NextFollowUpDate { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class SalesTarget
    {
        [Key]
        public int TargetId { get; set; }
        public int UserId { get; set; }
        public string MonthYear { get; set; } = "November 2026";
        public decimal TargetAmount { get; set; }
        public decimal AchievedAmount { get; set; }
        public decimal CommissionRatePercent { get; set; } = 2.50m;
        public decimal CommissionEarned { get; set; }
        public string Status { get; set; } = "IN_PROGRESS";
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    // CUSTOMER SPECIFIC MODELS (E-COMMERCE)
    public class CustomerWishlist
    {
        [Key]
        public long WishlistId { get; set; }
        public int CustomerId { get; set; }
        public int ProductId { get; set; }
        public int? VariantId { get; set; }
        public DateTime AddedAt { get; set; } = DateTime.UtcNow;
    }

    public class CustomerCartItem
    {
        [Key]
        public long CartItemId { get; set; }
        public int CustomerId { get; set; }
        public int VariantId { get; set; }
        public int Quantity { get; set; } = 1;
        public DateTime AddedAt { get; set; } = DateTime.UtcNow;
    }

    public class CustomerReview
    {
        [Key]
        public long ReviewId { get; set; }
        public int ProductId { get; set; }
        public int CustomerId { get; set; }
        public int Rating { get; set; } = 5;
        public string Headline { get; set; } = string.Empty;
        public string? ReviewText { get; set; }
        public bool IsVerifiedPurchase { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class CustomerLoyaltyLedger
    {
        [Key]
        public long PointId { get; set; }
        public int CustomerId { get; set; }
        public int PointsEarned { get; set; }
        public int PointsRedeemed { get; set; }
        public int CurrentBalance { get; set; }
        public string TransactionReason { get; set; } = string.Empty;
        public long? InvoiceId { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class OnlineOrderTracking
    {
        [Key]
        public long TrackingId { get; set; }
        public long InvoiceId { get; set; }
        public string TrackingNumber { get; set; } = string.Empty;
        public string CourierPartner { get; set; } = "Delhivery Express";
        public string CurrentStatus { get; set; } = "ORDER_CONFIRMED"; // ORDER_CONFIRMED, PACKED, SHIPPED, OUT_FOR_DELIVERY, DELIVERED
        public string CurrentLocation { get; set; } = "Khushi Footwear Central Hub";
        public DateTime EstimatedDeliveryDate { get; set; } = DateTime.UtcNow.AddDays(2);
        public string? StatusRemarks { get; set; }
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }

    public class SystemNotification
    {
        [Key]
        public long NotificationId { get; set; }
        public int ShopId { get; set; } = 1;
        public int? BranchId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string NotificationType { get; set; } = "STOCK_ALERT"; // 'STOCK_ALERT', 'PAYMENT_REMINDER', 'ORDER_DISPATCH', 'SYSTEM_ALERT'
        public string Severity { get; set; } = "INFO"; // 'INFO', 'WARNING', 'CRITICAL', 'SUCCESS'
        public string? ReferenceEntity { get; set; }
        public string? ReferenceId { get; set; }
        public bool IsRead { get; set; } = false;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    // 13. WHATSAPP DIGITAL BILL & 7-DAY EXCHANGE BARCODE PASS
    public class ExchangePass
    {
        [Key]
        public long PassId { get; set; }
        public long InvoiceId { get; set; }
        public string ExchangeToken { get; set; } = string.Empty;
        public DateTime IssuedAt { get; set; } = DateTime.UtcNow;
        public DateTime ValidUntil { get; set; } = DateTime.UtcNow.AddDays(7);
        public int MaxAllowedItems { get; set; } = 1;
        public int UsedItemsCount { get; set; } = 0;
        public string Status { get; set; } = "ACTIVE"; // ACTIVE, PARTIALLY_USED, EXCHANGED, EXPIRED, VOID
        public string? Notes { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class WhatsAppDeliveryLog
    {
        [Key]
        public long LogId { get; set; }
        public long InvoiceId { get; set; }
        public long? PassId { get; set; }
        public string RecipientMobile { get; set; } = string.Empty;
        public string TemplateName { get; set; } = "FOOTWEAR_GST_BILL_V2";
        public string WhatsAppMessageText { get; set; } = string.Empty;
        public string PdfUrl { get; set; } = string.Empty;
        public string DeliveryStatus { get; set; } = "DELIVERED";
        public string? MessageId { get; set; }
        public DateTime SentAt { get; set; } = DateTime.UtcNow;
    }

    // 14. SMART FOOTWEAR SIZE FINDER & RACK LOCATION TRACKING
    public class FootwearSizeChartConversion
    {
        [Key]
        public int ConversionId { get; set; }
        public string GenderTarget { get; set; } = "MEN";
        public decimal FootLengthCmMin { get; set; }
        public decimal FootLengthCmMax { get; set; }
        public decimal FootLengthInchesMin { get; set; }
        public decimal FootLengthInchesMax { get; set; }
        public string UkIndSize { get; set; } = string.Empty;
        public string UsSize { get; set; } = string.Empty;
        public string EuroSize { get; set; } = string.Empty;
        public string FitProfile { get; set; } = "REGULAR";
        public string? FitAdvice { get; set; }
    }

    public class FootwearRackLocation
    {
        [Key]
        public int LocationId { get; set; }
        public int BranchId { get; set; }
        public int VariantId { get; set; }
        public string ZoneArea { get; set; } = "RETAIL_FLOOR";
        public string RackCode { get; set; } = string.Empty;
        public string ShelfTier { get; set; } = "TIER-2";
        public string BinNumber { get; set; } = "BIN-01";
        public int MaxBoxCapacity { get; set; } = 12;
        public int CurrentBoxCount { get; set; } = 8;
        public DateTime LastAuditedAt { get; set; } = DateTime.UtcNow;
    }

    // 15. AI FOOTWEAR VISUAL SEARCH & CAMERA SCANNER
    public class AiVisualProductAttribute
    {
        [Key]
        public int AttributeId { get; set; }
        public int ProductId { get; set; }
        public string ShoeSilhouette { get; set; } = "LOW_TOP_SNEAKER";
        public string DominantColors { get; set; } = "WHITE,NAVY";
        public string MaterialType { get; set; } = "SYNTHETIC_MESH";
        public string SoleType { get; set; } = "AIR_CUSHION";
        public string? VisualEmbeddingVector { get; set; }
        public decimal MatchConfidenceThreshold { get; set; } = 85.00m;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class AiVisualSearchLog
    {
        [Key]
        public long SearchLogId { get; set; }
        public int BranchId { get; set; }
        public string ScannedImageSource { get; set; } = "CAMERA_CAPTURE";
        public string DetectedSilhouette { get; set; } = string.Empty;
        public string DetectedColors { get; set; } = string.Empty;
        public int? MatchedProductId { get; set; }
        public decimal ConfidenceScore { get; set; } = 94.50m;
        public int? SearchedByUserId { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    // 16. AI PREDICTIVE FOOTWEAR DEMAND FORECASTER & RESTOCK OPTIMIZER
    public class AiDemandForecast
    {
        [Key]
        public long ForecastId { get; set; }
        public int BranchId { get; set; }
        public int VariantId { get; set; }
        public string ForecastPeriod { get; set; } = "DIWALI_FESTIVAL";
        public int TargetMonth { get; set; } = 11;
        public int TargetYear { get; set; } = 2026;
        public int HistoricalMonthlyRunRate { get; set; } = 25;
        public int PredictedDemandPairs { get; set; }
        public decimal StockoutRiskScore { get; set; }
        public int RecommendedOrderPairs { get; set; }
        public decimal EstimatedInvestment { get; set; }
        public int SupplierId { get; set; }
        public string Status { get; set; } = "PENDING_APPROVAL";
        public DateTime GeneratedAt { get; set; } = DateTime.UtcNow;
    }

    public class AiFestivalSeasonRule
    {
        [Key]
        public int RuleId { get; set; }
        public string SeasonName { get; set; } = string.Empty;
        public string CategoryTarget { get; set; } = "ETHNIC_MOJARI";
        public decimal DemandMultiplier { get; set; } = 2.50m;
        public string KeySizeFocus { get; set; } = "UK 7, 8, 9";
        public int LeadTimeDays { get; set; } = 14;
        public string? Notes { get; set; }
    }

    // 17. AI SMART CROSS-SELLING & FOOTWEAR STYLIST ENGINE AT POS
    public class AiCrossSellRule
    {
        [Key]
        public int RuleId { get; set; }
        public string TriggerCategory { get; set; } = "SNEAKERS";
        public string RecommendedAddonName { get; set; } = string.Empty;
        public string AddonCategory { get; set; } = "SHOE_CARE";
        public decimal AddonPrice { get; set; }
        public decimal BundleDiscountPercent { get; set; } = 20.00m;
        public decimal BundlePrice { get; set; }
        public string PitchMessage { get; set; } = string.Empty;
        public decimal AttachRateTargetPercent { get; set; } = 35.00m;
        public bool IsActive { get; set; } = true;
    }

    public class AiCrossSellConversionLog
    {
        [Key]
        public long ConversionLogId { get; set; }
        public long InvoiceId { get; set; }
        public int TriggerProductId { get; set; }
        public int AddonRuleId { get; set; }
        public int CashierUserId { get; set; }
        public bool WasAccepted { get; set; } = true;
        public decimal AddonAmountAdded { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    // 18. AI CUSTOMER SHOE-WEAR CYCLE PREDICTOR & WHATSAPP RETENTION
    public class AiShoeWearLifecycle
    {
        [Key]
        public int LifecycleId { get; set; }
        public string CategoryTarget { get; set; } = "RUNNING_SPORTS";
        public int EstimatedLifespanDays { get; set; } = 180;
        public int WearMileageKm { get; set; } = 650;
        public int ReplacementAlertThresholdDays { get; set; } = 160;
        public string RetentionOfferTemplate { get; set; } = "FOOTWEAR_UPGRADE_LOYALTY_V1";
        public decimal VoucherDiscountPercent { get; set; } = 15.00m;
        public string? Notes { get; set; }
    }

    public class AiCustomerRetentionVoucher
    {
        [Key]
        public long VoucherId { get; set; }
        public int CustomerId { get; set; }
        public long LastInvoiceId { get; set; }
        public string VoucherCode { get; set; } = string.Empty;
        public decimal DiscountPercent { get; set; } = 15.00m;
        public string PreferredSize { get; set; } = "UK 8";
        public string PreferredCategory { get; set; } = "RUNNING_SPORTS";
        public int DaysSinceLastPurchase { get; set; }
        public string PredictedWearStatus { get; set; } = "DUE_FOR_RENEWAL";
        public string WhatsAppSentStatus { get; set; } = "DISPATCHED";
        public DateTime ValidUntil { get; set; } = DateTime.UtcNow.AddDays(15);
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    // 19. AI DEAD-STOCK MARKDOWN & FLASH CLEARANCE ENGINE
    public class AiDeadStockMarkdown
    {
        [Key]
        public long MarkdownId { get; set; }
        public int VariantId { get; set; }
        public int BranchId { get; set; }
        public int DaysUnsold { get; set; }
        public string AgingBracket { get; set; } = "60_TO_90_DAYS";
        public decimal OriginalSellingPrice { get; set; }
        public decimal PurchasePrice { get; set; }
        public decimal RecommendedDiscountPercent { get; set; }
        public decimal ProposedMarkdownPrice { get; set; }
        public decimal GrossMarginRecovered { get; set; }
        public string ClearanceStrategy { get; set; } = "TIERED_MARKDOWN";
        public string Status { get; set; } = "ACTIVE";
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    // 20. AI VOICE-ASSISTED WAREHOUSE INVENTORY ASSISTANT
    public class AiVoiceQueryLog
    {
        [Key]
        public long VoiceLogId { get; set; }
        public int BranchId { get; set; }
        public int? StaffUserId { get; set; }
        public string SpokenTranscript { get; set; } = string.Empty;
        public string ParsedIntent { get; set; } = "STOCK_AND_LOCATION_LOOKUP";
        public string? ExtractedBrand { get; set; }
        public string? ExtractedSize { get; set; }
        public string? ExtractedColor { get; set; }
        public int? MatchedVariantId { get; set; }
        public string SynthesizedSpeechResponse { get; set; } = string.Empty;
        public int ResponseLatencyMs { get; set; } = 120;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
