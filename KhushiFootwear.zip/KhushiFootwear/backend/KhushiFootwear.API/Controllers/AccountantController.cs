using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using KhushiFootwear.API.Data;
using KhushiFootwear.API.Models;

namespace KhushiFootwear.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class AccountantController : ControllerBase
    {
        private readonly KhushiDbContext _context;

        public AccountantController(KhushiDbContext context)
        {
            _context = context;
        }

        // 1. Manage Daily Income & Inflows
        [HttpGet("daily-income")]
        public async Task<IActionResult> GetDailyIncome([FromQuery] DateTime? date)
        {
            var targetDate = date?.Date ?? DateTime.UtcNow.Date;
            var posSales = await _context.SalesInvoices
                .Where(s => s.InvoiceDate.Date == targetDate)
                .SumAsync(s => s.GrandTotal);

            var cashbookInflows = await _context.CashbookLedgers
                .Where(c => c.TransactionDate.Date == targetDate && c.EntryType == "INFLOW_RECEIPT")
                .SumAsync(c => c.Amount);

            var upiDeposits = await _context.BankTransactions
                .Where(b => b.TxnDate.Date == targetDate && (b.TxnType == "UPI_COLLECTION" || b.TxnType == "DEPOSIT"))
                .SumAsync(b => b.Amount);

            return Ok(new
            {
                Date = targetDate,
                PosSales = posSales,
                CashbookInflows = cashbookInflows,
                UpiAndBankDeposits = upiDeposits,
                TotalGrossIncome = posSales + cashbookInflows
            });
        }

        // 2. Manage Business Expenses
        [HttpGet("expenses")]
        public async Task<IActionResult> GetExpenses([FromQuery] int? branchId)
        {
            var query = _context.Expenses.AsQueryable();
            if (branchId.HasValue)
            {
                query = query.Where(e => e.BranchId == branchId.Value);
            }
            var list = await query.OrderByDescending(e => e.ExpenseDate).ToListAsync();
            return Ok(list);
        }

        [HttpPost("expenses")]
        public async Task<IActionResult> AddExpense([FromBody] Expense expense)
        {
            if (expense.Amount <= 0) return BadRequest("Expense amount must be positive.");
            _context.Expenses.Add(expense);
            await _context.SaveChangesAsync();
            return Ok(expense);
        }

        // 3. Manage Cashbook
        [HttpGet("cashbook")]
        public async Task<IActionResult> GetCashbook([FromQuery] int? branchId, [FromQuery] DateTime? fromDate, [FromQuery] DateTime? toDate)
        {
            var query = _context.CashbookLedgers.AsQueryable();
            if (branchId.HasValue)
            {
                query = query.Where(c => c.BranchId == branchId.Value);
            }
            if (fromDate.HasValue)
            {
                query = query.Where(c => c.TransactionDate >= fromDate.Value.Date);
            }
            if (toDate.HasValue)
            {
                query = query.Where(c => c.TransactionDate <= toDate.Value.Date);
            }

            var entries = await query.OrderByDescending(c => c.TransactionDate).ToListAsync();
            var totalInflows = entries.Where(e => e.EntryType == "INFLOW_RECEIPT").Sum(e => e.Amount);
            var totalOutflows = entries.Where(e => e.EntryType == "OUTFLOW_PAYMENT").Sum(e => e.Amount);
            var netCashBalance = totalInflows - totalOutflows;

            return Ok(new
            {
                TotalInflows = totalInflows,
                TotalOutflows = totalOutflows,
                NetCashBalance = netCashBalance,
                Entries = entries
            });
        }

        [HttpPost("cashbook")]
        public async Task<IActionResult> CreateCashbookEntry([FromBody] CashbookLedger entry)
        {
            if (string.IsNullOrWhiteSpace(entry.VoucherNumber))
            {
                entry.VoucherNumber = $"VCH-{DateTime.UtcNow:yyyyMMddHHmmss}";
            }
            _context.CashbookLedgers.Add(entry);
            await _context.SaveChangesAsync();
            return Ok(entry);
        }

        // 4. Manage Bank Transactions
        [HttpGet("bank-transactions")]
        public async Task<IActionResult> GetBankTransactions([FromQuery] string? reconciliationStatus)
        {
            var query = _context.BankTransactions.AsQueryable();
            if (!string.IsNullOrWhiteSpace(reconciliationStatus))
            {
                query = query.Where(b => b.ReconciliationStatus == reconciliationStatus);
            }
            var transactions = await query.OrderByDescending(b => b.TxnDate).ToListAsync();
            return Ok(transactions);
        }

        [HttpPost("bank-transactions")]
        public async Task<IActionResult> AddBankTransaction([FromBody] BankTransaction txn)
        {
            _context.BankTransactions.Add(txn);
            await _context.SaveChangesAsync();
            return Ok(txn);
        }

        // 5. Manage UPI Transactions
        [HttpGet("upi-transactions")]
        public async Task<IActionResult> GetUpiTransactions()
        {
            var upiTxns = await _context.BankTransactions
                .Where(b => b.TxnType == "UPI_COLLECTION" || b.ReferenceNumber.StartsWith("UPI"))
                .OrderByDescending(b => b.TxnDate)
                .ToListAsync();
            return Ok(upiTxns);
        }

        // 6. Manage Customer Outstanding
        [HttpGet("customer-outstanding")]
        public async Task<IActionResult> GetCustomerOutstanding()
        {
            var customers = await _context.Customers
                .Where(c => c.OutstandingBalance > 0)
                .OrderByDescending(c => c.OutstandingBalance)
                .Select(c => new
                {
                    c.CustomerId,
                    c.FullName,
                    c.Mobile,
                    c.OutstandingBalance,
                    c.LoyaltyPoints
                })
                .ToListAsync();

            var totalOutstanding = customers.Sum(c => c.OutstandingBalance);
            return Ok(new
            {
                TotalCustomerOutstanding = totalOutstanding,
                Customers = customers
            });
        }

        // 7. Manage Supplier Outstanding
        [HttpGet("supplier-outstanding")]
        public async Task<IActionResult> GetSupplierOutstanding()
        {
            var suppliers = await _context.Suppliers
                .Where(s => s.OutstandingAmount > 0)
                .OrderByDescending(s => s.OutstandingAmount)
                .Select(s => new
                {
                    s.SupplierId,
                    s.SupplierName,
                    s.ContactPerson,
                    s.Phone,
                    s.GSTIN,
                    s.OutstandingAmount
                })
                .ToListAsync();

            var totalSupplierOutstanding = suppliers.Sum(s => s.OutstandingAmount);
            return Ok(new
            {
                TotalSupplierOutstanding = totalSupplierOutstanding,
                Suppliers = suppliers
            });
        }

        // 8. Manage GST Records
        [HttpGet("gst-records")]
        public async Task<IActionResult> GetGstRecords([FromQuery] DateTime? fromDate, [FromQuery] DateTime? toDate)
        {
            var from = fromDate?.Date ?? DateTime.UtcNow.AddDays(-30).Date;
            var to = toDate?.Date ?? DateTime.UtcNow.Date;

            var sales = await _context.SalesInvoices
                .Where(s => s.InvoiceDate >= from && s.InvoiceDate <= to)
                .ToListAsync();

            var purchases = await _context.PurchaseInvoices
                .Where(p => p.InvoiceDate >= from && p.InvoiceDate <= to)
                .ToListAsync();

            var outputTax = sales.Sum(s => s.CGST + s.SGST);
            var inputTaxCredit = purchases.Sum(p => p.GSTAmount);
            var netGstPayable = outputTax - inputTaxCredit;

            return Ok(new
            {
                PeriodFrom = from,
                PeriodTo = to,
                OutputTaxCollected = outputTax,
                InputTaxCreditITC = inputTaxCredit,
                NetGstPayableLiability = netGstPayable > 0 ? netGstPayable : 0,
                AvailableRefundITC = netGstPayable < 0 ? Math.Abs(netGstPayable) : 0,
                SalesCount = sales.Count,
                PurchasesCount = purchases.Count
            });
        }

        // 9. Manage Employee Salaries
        [HttpGet("salaries")]
        public async Task<IActionResult> GetSalaries([FromQuery] string? monthYear)
        {
            var query = _context.SalaryDisbursements.AsQueryable();
            if (!string.IsNullOrWhiteSpace(monthYear))
            {
                query = query.Where(s => s.MonthYear == monthYear);
            }
            var list = await query.OrderByDescending(s => s.DisbursedDate).ToListAsync();
            return Ok(list);
        }

        [HttpPost("salaries/disburse")]
        public async Task<IActionResult> DisburseSalary([FromBody] SalaryDisbursement salary)
        {
            salary.NetSalaryPaid = salary.BasicSalary + salary.CommissionAmount - salary.Deductions;
            salary.Status = "PAID";
            salary.DisbursedDate = DateTime.UtcNow.Date;
            _context.SalaryDisbursements.Add(salary);
            await _context.SaveChangesAsync();
            return Ok(salary);
        }

        // 10. View Sales Reports
        [HttpGet("reports/sales")]
        public async Task<IActionResult> GetSalesReports([FromQuery] int? branchId)
        {
            var query = _context.SalesInvoices.AsQueryable();
            if (branchId.HasValue) query = query.Where(s => s.BranchId == branchId.Value);

            var totalSales = await query.SumAsync(s => s.GrandTotal);
            var totalBills = await query.CountAsync();
            var totalDiscount = await query.SumAsync(s => s.DiscountAmount);

            return Ok(new
            {
                TotalRevenue = totalSales,
                TotalBillsCount = totalBills,
                TotalDiscountGiven = totalDiscount
            });
        }

        // 11. View Purchase Reports
        [HttpGet("reports/purchase")]
        public async Task<IActionResult> GetPurchaseReports()
        {
            var totalPurchases = await _context.PurchaseInvoices.SumAsync(p => p.GrandTotal);
            var invoiceCount = await _context.PurchaseInvoices.CountAsync();
            var pendingOrders = await _context.PurchaseOrders.CountAsync(p => p.Status != "RECEIVED");

            return Ok(new
            {
                TotalPurchasedValue = totalPurchases,
                TotalPurchaseInvoices = invoiceCount,
                PendingPurchaseOrders = pendingOrders
            });
        }

        // 12. View Profit and Loss Reports
        [HttpGet("reports/profit-and-loss")]
        public async Task<IActionResult> GetProfitAndLoss([FromQuery] DateTime? fromDate, [FromQuery] DateTime? toDate)
        {
            var from = fromDate?.Date ?? DateTime.UtcNow.AddDays(-30).Date;
            var to = toDate?.Date ?? DateTime.UtcNow.Date;

            var revenue = await _context.SalesInvoices
                .Where(s => s.InvoiceDate >= from && s.InvoiceDate <= to)
                .SumAsync(s => s.GrandTotal);

            var cogs = await _context.PurchaseInvoices
                .Where(p => p.InvoiceDate >= from && p.InvoiceDate <= to)
                .SumAsync(p => p.GrandTotal);

            var operatingExpenses = await _context.Expenses
                .Where(e => e.ExpenseDate >= from && e.ExpenseDate <= to)
                .SumAsync(e => e.Amount);

            var salaries = await _context.SalaryDisbursements
                .Where(s => s.DisbursedDate >= from && s.DisbursedDate <= to)
                .SumAsync(s => s.NetSalaryPaid);

            var grossProfit = revenue - cogs;
            var totalExpenses = operatingExpenses + salaries;
            var netProfit = grossProfit - totalExpenses;

            return Ok(new
            {
                PeriodFrom = from,
                PeriodTo = to,
                TotalRevenue = revenue,
                CostOfGoodsPurchased = cogs,
                GrossProfit = grossProfit,
                OperatingExpenses = operatingExpenses,
                SalariesPaid = salaries,
                TotalOperatingExpenses = totalExpenses,
                NetProfit = netProfit,
                ProfitMarginPercent = revenue > 0 ? Math.Round((netProfit / revenue) * 100, 2) : 0
            });
        }

        // 13. Manage Payment Reconciliation (BRS)
        [HttpPost("reconciliation/reconcile-transaction/{txnId}")]
        public async Task<IActionResult> ReconcileTransaction(long txnId, [FromQuery] string status = "RECONCILED")
        {
            var txn = await _context.BankTransactions.FindAsync(txnId);
            if (txn == null) return NotFound("Bank transaction not found.");

            txn.ReconciliationStatus = status;
            await _context.SaveChangesAsync();
            return Ok(new { Message = $"Bank transaction {txn.ReferenceNumber} status updated to {status}.", Transaction = txn });
        }

        // 14. Generate Comprehensive Financial Reports
        [HttpGet("financial-summary")]
        public async Task<IActionResult> GetFinancialSummary()
        {
            var cashBalance = await _context.CashbookLedgers.Where(c => c.EntryType == "INFLOW_RECEIPT").SumAsync(c => c.Amount)
                - await _context.CashbookLedgers.Where(c => c.EntryType == "OUTFLOW_PAYMENT").SumAsync(c => c.Amount);

            var bankBalance = await _context.BankTransactions.Where(b => b.TxnType == "DEPOSIT" || b.TxnType == "UPI_COLLECTION").SumAsync(b => b.Amount)
                - await _context.BankTransactions.Where(b => b.TxnType == "WITHDRAWAL").SumAsync(b => b.Amount);

            var customerReceivables = await _context.Customers.SumAsync(c => c.OutstandingBalance);
            var supplierPayables = await _context.Suppliers.SumAsync(s => s.OutstandingAmount);

            return Ok(new
            {
                LiquidCashBalance = cashBalance,
                TotalBankAndUpiBalance = bankBalance,
                AccountsReceivableFromCustomers = customerReceivables,
                AccountsPayableToSuppliers = supplierPayables,
                NetLiquidWorth = (cashBalance + bankBalance + customerReceivables) - supplierPayables
            });
        }
    }
}
