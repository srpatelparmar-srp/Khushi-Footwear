using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using KhushiFootwear.API.Data;
using KhushiFootwear.API.Models;

namespace KhushiFootwear.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class NotificationController : ControllerBase
    {
        private readonly KhushiDbContext _db;

        public NotificationController(KhushiDbContext db)
        {
            _db = db;
        }

        // 1. Get all notifications with filter
        [HttpGet]
        public async Task<IActionResult> GetNotifications([FromQuery] string? type, [FromQuery] bool? unreadOnly, [FromQuery] int shopId = 1)
        {
            var query = _db.SystemNotifications.Where(n => n.ShopId == shopId).AsQueryable();

            if (!string.IsNullOrWhiteSpace(type))
            {
                query = query.Where(n => n.NotificationType == type);
            }
            if (unreadOnly.HasValue && unreadOnly.Value)
            {
                query = query.Where(n => !n.IsRead);
            }

            var list = await query.OrderByDescending(n => n.CreatedAt).ToListAsync();
            return Ok(list);
        }

        // 2. Stock Alerts specifically
        [HttpGet("stock-alerts")]
        public async Task<IActionResult> GetStockAlerts([FromQuery] int shopId = 1)
        {
            var alerts = await _db.SystemNotifications
                .Where(n => n.ShopId == shopId && n.NotificationType == "STOCK_ALERT")
                .OrderByDescending(n => n.CreatedAt)
                .ToListAsync();
            return Ok(alerts);
        }

        // 3. Payment Reminders specifically (Suppliers & Customers)
        [HttpGet("payment-reminders")]
        public async Task<IActionResult> GetPaymentReminders([FromQuery] int shopId = 1)
        {
            var reminders = await _db.SystemNotifications
                .Where(n => n.ShopId == shopId && n.NotificationType == "PAYMENT_REMINDER")
                .OrderByDescending(n => n.CreatedAt)
                .ToListAsync();
            return Ok(reminders);
        }

        // 4. Mark notification as read
        [HttpPatch("{id}/read")]
        public async Task<IActionResult> MarkAsRead(long id)
        {
            var notification = await _db.SystemNotifications.FindAsync(id);
            if (notification == null) return NotFound("Notification not found.");

            notification.IsRead = true;
            await _db.SaveChangesAsync();
            return Ok(notification);
        }

        // 5. Create new system notification / alert
        [HttpPost]
        public async Task<IActionResult> CreateNotification([FromBody] SystemNotification notification)
        {
            notification.CreatedAt = DateTime.UtcNow;
            _db.SystemNotifications.Add(notification);
            await _db.SaveChangesAsync();
            return Ok(notification);
        }
    }
}

