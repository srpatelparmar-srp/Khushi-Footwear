using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using KhushiFootwear.API.Data;

namespace KhushiFootwear.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReportsController : ControllerBase
    {
        private readonly KhushiDbContext _db;

        public ReportsController(KhushiDbContext db)
        {
            _db = db;
        }

        // 1. Daily Sales Report
        [HttpGet("daily-sales")]
        public IActionResult GetDailySalesReport([FromQuery] DateTime? date)
        {
            return Ok(new
            {
                ReportName = "Daily Sales Report",
                Date = date ?? DateTime.UtcNow.Date,
                TotalInvoices = 54,
                TotalPairsSold = 342,
                GrossSales = 148920.00,
                DiscountsGiven = 5400.00,
                GSTCollected = 15955.00,
                NetSales = 148920.00,
                PaymentBreakdown = new { UPI = 96798.00, Cash = 37230.00, Card = 14892.00 }
            });
        }

        // 2. Monthly Sales Report
        [HttpGet("monthly-sales")]
        public IActionResult GetMonthlySalesReport([FromQuery] string month = "November 2026")
        {
            return Ok(new
            {
                ReportName = "Monthly Sales Report",
                Month = month,
                TotalSales = 458920.00,
                TotalTransactions = 168,
                AverageTicketSize = 2731.66,
                DailyRunRate = 38243.33,
                TargetAttainmentPercent = 76.3
            });
        }

        // 3. Yearly Sales Report
        [HttpGet("yearly-sales")]
        public IActionResult GetYearlySalesReport([FromQuery] int year = 2026)
        {
            return Ok(new
            {
                ReportName = "Yearly Sales Report",
                Year = year,
                AnnualRevenue = 5240000.00,
                GrowthOverPreviousYear = 22.4,
                PeakQuarter = "Q3 Festive (Oct-Dec)",
                TotalFootwearPairsSold = 18450
            });
        }

        // 4. Brand-wise Sales Report
        [HttpGet("brand-sales")]
        public IActionResult GetBrandSalesReport()
        {
            return Ok(new[]
            {
                new { Brand = "Nike", Revenue = 142000.00, Pairs = 120, Share = "31.0%" },
                new { Brand = "Adidas", Revenue = 98500.00, Pairs = 85, Share = "21.5%" },
                new { Brand = "Puma", Revenue = 64200.00, Pairs = 72, Share = "14.0%" },
                new { Brand = "Bata", Revenue = 58900.00, Pairs = 94, Share = "12.8%" },
                new { Brand = "Woodland", Revenue = 45600.00, Pairs = 38, Share = "9.9%" },
                new { Brand = "Campus", Revenue = 38400.00, Pairs = 64, Share = "8.4%" },
            });
        }

        // 5. Category-wise Sales Report
        [HttpGet("category-sales")]
        public IActionResult GetCategorySalesReport()
        {
            return Ok(new[]
            {
                new { Category = "Sports & Running", Revenue = 206514.00, Share = "45.0%" },
                new { Category = "Men Formal", Revenue = 128497.00, Share = "28.0%" },
                new { Category = "Outdoor & Boots", Revenue = 68838.00, Share = "15.0%" },
                new { Category = "Casual & Slip-on", Revenue = 55071.00, Share = "12.0%" },
            });
        }

        // 6. Product-wise Sales Report
        [HttpGet("product-sales")]
        public IActionResult GetProductSalesReport()
        {
            return Ok(new[]
            {
                new { Model = "Nike Air Max 270 Flyknit", Revenue = 89950.00, Pairs = 10, Rank = 1 },
                new { Model = "Adidas Ultraboost Light", Revenue = 75992.00, Pairs = 8, Rank = 2 },
                new { Model = "Bata Formal Derby Classic", Revenue = 44982.00, Pairs = 18, Rank = 3 },
                new { Model = "Puma Smash V2 Leather", Revenue = 39186.00, Pairs = 14, Rank = 4 },
            });
        }

        // 7. Size-wise Sales Report
        [HttpGet("size-sales")]
        public IActionResult GetSizeSalesReport()
        {
            return Ok(new[]
            {
                new { Size = "UK 8", PairsSold = 188, Share = "38.0%", Revenue = 412000.00 },
                new { Size = "UK 9", PairsSold = 158, Share = "31.9%", Revenue = 378000.00 },
                new { Size = "UK 7", PairsSold = 88, Share = "17.8%", Revenue = 176000.00 },
                new { Size = "UK 6", PairsSold = 42, Share = "8.5%", Revenue = 84000.00 },
                new { Size = "UK 10 & 11", PairsSold = 19, Share = "3.8%", Revenue = 45000.00 },
            });
        }

        // 8. Color-wise Sales Report
        [HttpGet("color-sales")]
        public IActionResult GetColorSalesReport()
        {
            return Ok(new[]
            {
                new { Color = "Pure White", Pairs = 194, Share = "39.2%" },
                new { Color = "Core Black", Pairs = 168, Share = "33.9%" },
                new { Color = "Oxford Tan", Pairs = 68, Share = "13.7%" },
                new { Color = "Navy Blue", Pairs = 44, Share = "8.9%" },
                new { Color = "Olive Khaki", Pairs = 21, Share = "4.3%" },
            });
        }

        // 9. Cashier-wise Sales Report
        [HttpGet("cashier-sales")]
        public IActionResult GetCashierSalesReport()
        {
            return Ok(new[]
            {
                new { Cashier = "Anita Deshmukh", Terminal = "Counter 1", Invoices = 54, Collection = 148920.00, ShiftHours = 8.5 },
                new { Cashier = "Sunil Patil", Terminal = "Counter 2", Invoices = 38, Collection = 98450.00, ShiftHours = 7.0 },
            });
        }

        // 10. Purchase Report
        [HttpGet("purchase-summary")]
        public IActionResult GetPurchaseReport()
        {
            return Ok(new
            {
                TotalPurchases = 285400.00,
                Consignments = 48,
                TotalPairsInward = 580,
                PendingGRNApprovals = 2,
                TotalITCClaimable = 34248.00
            });
        }

        // 11. Supplier Report
        [HttpGet("supplier-summary")]
        public IActionResult GetSupplierReport()
        {
            return Ok(new[]
            {
                new { Supplier = "Nike India Wholesale", Billed = 142000.00, Outstanding = 0.00, FulfillmentRate = "100%" },
                new { Supplier = "Metro Leather Traders", Billed = 85400.00, Outstanding = 45000.00, FulfillmentRate = "96%" },
                new { Supplier = "Crocs Regional Logistics", Billed = 58000.00, Outstanding = 0.00, FulfillmentRate = "100%" },
            });
        }

        // 12. Customer Report
        [HttpGet("customer-summary")]
        public IActionResult GetCustomerReport()
        {
            return Ok(new
            {
                TotalRegisteredCustomers = 1240,
                ActiveWalkInsThisMonth = 428,
                RepeatPurchaseRate = "68.5%",
                TotalLoyaltyPointsIssued = 48500,
                TotalLoyaltyPointsRedeemed = 18200
            });
        }

        // 13. Stock Report
        [HttpGet("stock-summary")]
        public IActionResult GetStockReport()
        {
            return Ok(new
            {
                TotalStockValuation = 1850000.00,
                TotalPairsInStock = 4280,
                PuneFlagshipStock = 1450,
                MumbaiOutletStock = 1120,
                NashikOutletStock = 890,
                CentralWarehouseStock = 820
            });
        }

        // 14. Low Stock Report
        [HttpGet("low-stock")]
        public IActionResult GetLowStockReport()
        {
            return Ok(new[]
            {
                new { Product = "Woodland Trekker (UK 8)", Available = 0, AlertThreshold = 5, Status = "OUT_OF_STOCK" },
                new { Product = "Puma Smash V2 (UK 7)", Available = 2, AlertThreshold = 5, Status = "LOW_STOCK" },
                new { Product = "Campus Oxyfit (UK 9)", Available = 3, AlertThreshold = 6, Status = "LOW_STOCK" },
            });
        }

        // 15. Damaged Stock Report
        [HttpGet("damaged-stock")]
        public IActionResult GetDamagedStockReport()
        {
            return Ok(new[]
            {
                new { DamageId = "DAM-012", Item = "Bata Formal Derby (UK 9)", Reason = "Sole delamination", Value = 2499.00, Status = "DEBIT_NOTE_SETTLED" },
                new { DamageId = "DAM-011", Item = "Nike Air Max 270 (UK 8)", Reason = "Air cushion puncture", Value = 8995.00, Status = "VENDOR_CLAIM_APPROVED" },
            });
        }

        // 16. Sales Return Report
        [HttpGet("sales-returns")]
        public IActionResult GetSalesReturnReport()
        {
            return Ok(new
            {
                TotalReturns = 8,
                TotalRefundAmount = 14200.00,
                ReturnRatePercent = 1.8,
                PrimaryReason = "Size Fit Issue (75%)"
            });
        }

        // 17. Exchange Report
        [HttpGet("exchanges")]
        public IActionResult GetExchangeReport()
        {
            return Ok(new
            {
                TotalExchanges = 18,
                SizeSwaps = 14,
                ColorSwaps = 4,
                CustomerRetentionThroughExchange = "94.4%"
            });
        }

        // 18. GST Report
        [HttpGet("gst-tax")]
        public IActionResult GetGstReport()
        {
            return Ok(new
            {
                TaxPeriod = "November 2026",
                HSNCode = "6404 (Footwear)",
                TaxableTurnover = 132965.00,
                CGSTCollected = 7977.50,
                SGSTCollected = 7977.50,
                TotalOutputGST = 15955.00,
                InputTaxCredit = 34248.00,
                NetGSTPayable = 0.00 // Offset by ITC
            });
        }

        // 19. Expense Report
        [HttpGet("expenses")]
        public IActionResult GetExpenseReport()
        {
            return Ok(new
            {
                TotalExpenses = 48720.00,
                ShowroomRent = 32000.00,
                ElectricityPower = 6450.00,
                PackagingShoeBoxes = 4200.00,
                CourierLogistics = 4220.00,
                HospitalityTea = 1850.00
            });
        }

        // 20. Profit and Loss Report
        [HttpGet("profit-and-loss")]
        public IActionResult GetProfitAndLossReport()
        {
            return Ok(new
            {
                GrossRevenue = 458920.00,
                CostOfGoodsSold = 285400.00,
                GrossProfit = 173520.00,
                GrossMarginPercent = 37.8,
                TotalOperatingExpenses = 48720.00,
                NetOperatingProfit = 124800.00,
                NetMarginPercent = 27.2
            });
        }

        // 21. Customer Outstanding Report
        [HttpGet("customer-outstanding")]
        public IActionResult GetCustomerOutstandingReport()
        {
            return Ok(new[]
            {
                new { Customer = "Amit Saxena", Phone = "+91 94230 11998", PendingAmount = 3450.00, DueDays = 15, Status = "OVERDUE" },
                new { Customer = "Pooja Verma", Phone = "+91 98221 55443", PendingAmount = 1800.00, DueDays = 8, Status = "PENDING" },
                new { Customer = "Karan Mehra", Phone = "+91 99887 76655", PendingAmount = 2200.00, DueDays = 12, Status = "PENDING" },
            });
        }

        // 22. Supplier Outstanding Report
        [HttpGet("supplier-outstanding")]
        public IActionResult GetSupplierOutstandingReport()
        {
            return Ok(new[]
            {
                new { Supplier = "Metro Leather Goods Traders", InvoiceNo = "METRO-INV-881", DueAmount = 45000.00, DueDate = DateTime.UtcNow.AddDays(2), Status = "DUE_IN_2_DAYS" },
                new { Supplier = "Nike India Wholesale Ltd.", InvoiceNo = "NIKE-INV-442", DueAmount = 0.00, DueDate = DateTime.UtcNow, Status = "CLEARED" },
            });
        }

        // 23. Employee Performance Report
        [HttpGet("employee-performance")]
        public IActionResult GetEmployeePerformanceReport()
        {
            return Ok(new[]
            {
                new { Staff = "Rahul Joshi", Role = "Sales Executive", Target = 150000.00, Achieved = 114500.00, Attainment = "76.3%", Commission = 2862.50, Tier = "Gold" },
                new { Staff = "Vikas Kulkarni", Role = "Floor Assistant", Target = 120000.00, Achieved = 89400.00, Attainment = "74.5%", Commission = 2235.00, Tier = "Silver" },
                new { Staff = "Priya Nair", Role = "Sales Executive", Target = 120000.00, Achieved = 76200.00, Attainment = "63.5%", Commission = 1905.00, Tier = "Bronze" },
            });
        }
    }
}

