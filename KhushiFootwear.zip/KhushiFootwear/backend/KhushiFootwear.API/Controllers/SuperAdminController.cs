using Microsoft.AspNetCore.Mvc;
using KhushiFootwear.API.Data;
using KhushiFootwear.API.Models;
using Microsoft.EntityFrameworkCore;

namespace KhushiFootwear.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SuperAdminController : ControllerBase
    {
        private readonly KhushiDbContext _db;

        public SuperAdminController(KhushiDbContext db)
        {
            _db = db;
        }

        // 1. Manage all shop owners & shops
        [HttpGet("shops")]
        public async Task<IActionResult> GetAllShops()
        {
            var shops = await _db.Shops.ToListAsync();
            return Ok(shops);
        }

        [HttpPost("shops")]
        public async Task<IActionResult> CreateShop([FromBody] Shop shop)
        {
            _db.Shops.Add(shop);
            await _db.SaveChangesAsync();

            // Log in Audit
            _db.AuditLogs.Add(new AuditLog
            {
                Action = "CREATE_SHOP",
                TableName = "Shops",
                RecordId = shop.ShopId.ToString(),
                NewValues = $"ShopName: {shop.ShopName}, Owner: {shop.OwnerName}"
            });
            await _db.SaveChangesAsync();

            return Ok(new { message = "Shop created successfully", shopId = shop.ShopId });
        }

        [HttpPut("shops/{id}")]
        public async Task<IActionResult> UpdateShop(int id, [FromBody] Shop shop)
        {
            var existing = await _db.Shops.FindAsync(id);
            if (existing == null) return NotFound();

            existing.ShopName = shop.ShopName;
            existing.OwnerName = shop.OwnerName;
            existing.ContactNumber = shop.ContactNumber;
            existing.GSTIN = shop.GSTIN;
            existing.IsActive = shop.IsActive;

            await _db.SaveChangesAsync();
            return Ok(new { message = "Shop updated successfully" });
        }

        // 2. Manage branches
        [HttpGet("branches")]
        public async Task<IActionResult> GetAllBranches([FromQuery] int? shopId)
        {
            var query = _db.Branches.AsQueryable();
            if (shopId.HasValue) query = query.Where(b => b.ShopId == shopId.Value);
            return Ok(await query.ToListAsync());
        }

        // 3. Manage users, roles & permissions
        [HttpGet("users")]
        public async Task<IActionResult> GetAllUsers()
        {
            var users = await (from u in _db.Users
                               join r in _db.Roles on u.RoleId equals r.RoleId
                               select new
                               {
                                   u.UserId,
                                   u.FullName,
                                   u.Username,
                                   u.PhoneNumber,
                                   u.ShopId,
                                   u.BranchId,
                                   RoleName = r.RoleName,
                                   u.IsActive
                               }).ToListAsync();
            return Ok(users);
        }

        // 4. Manage product categories and brands
        [HttpPost("brands")]
        public async Task<IActionResult> AddBrand([FromBody] Brand brand)
        {
            _db.Brands.Add(brand);
            await _db.SaveChangesAsync();
            return Ok(brand);
        }

        [HttpPost("categories")]
        public async Task<IActionResult> AddCategory([FromBody] Category category)
        {
            _db.Categories.Add(category);
            await _db.SaveChangesAsync();
            return Ok(category);
        }

        // 5. Manage subscription plans
        [HttpGet("subscriptions/plans")]
        public async Task<IActionResult> GetPlans() => Ok(await _db.SubscriptionPlans.ToListAsync());

        [HttpPost("subscriptions/plans")]
        public async Task<IActionResult> CreatePlan([FromBody] SubscriptionPlan plan)
        {
            _db.SubscriptionPlans.Add(plan);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Subscription plan created", planId = plan.PlanId });
        }

        // 6. Configure GST and tax settings
        [HttpGet("tax-settings")]
        public async Task<IActionResult> GetTaxSettings() => Ok(await _db.TaxSettings.ToListAsync());

        [HttpPut("tax-settings/{id}")]
        public async Task<IActionResult> UpdateTaxSetting(int id, [FromBody] TaxSetting tax)
        {
            var existing = await _db.TaxSettings.FindAsync(id);
            if (existing == null) return NotFound();

            existing.TaxName = tax.TaxName;
            existing.CGSTRate = tax.CGSTRate;
            existing.SGSTRate = tax.SGSTRate;
            existing.IGSTRate = tax.IGSTRate;
            existing.FootwearPriceThreshold = tax.FootwearPriceThreshold;
            existing.BelowThresholdRate = tax.BelowThresholdRate;
            existing.AboveThresholdRate = tax.AboveThresholdRate;
            existing.UpdatedAt = DateTime.UtcNow;

            await _db.SaveChangesAsync();
            return Ok(new { message = "Footwear GST rules updated successfully" });
        }

        // 7. View all shop sales and reports
        [HttpGet("analytics/all-shops-summary")]
        public IActionResult GetAllShopsSales()
        {
            return Ok(new
            {
                totalRegisteredShops = 12,
                totalActiveBranches = 28,
                allTimeSalesVolume = 18450920.00,
                monthlySubscriptionRevenue = 145000.00,
                activeFootwearSKUs = 4850,
                systemHealth = "Healthy (100% SLA)"
            });
        }

        // 8. Manage system settings
        [HttpGet("system-settings")]
        public async Task<IActionResult> GetSystemSettings() => Ok(await _db.SystemSettings.ToListAsync());

        [HttpPost("system-settings")]
        public async Task<IActionResult> SaveSystemSetting([FromBody] SystemSetting setting)
        {
            var existing = await _db.SystemSettings.FirstOrDefaultAsync(s => s.SettingKey == setting.SettingKey);
            if (existing != null)
            {
                existing.SettingValue = setting.SettingValue;
                existing.UpdatedAt = DateTime.UtcNow;
            }
            else
            {
                _db.SystemSettings.Add(setting);
            }
            await _db.SaveChangesAsync();
            return Ok(new { message = "System setting saved" });
        }

        // 9. View audit logs
        [HttpGet("audit-logs")]
        public async Task<IActionResult> GetAuditLogs([FromQuery] int limit = 50)
        {
            var logs = await _db.AuditLogs
                .OrderByDescending(l => l.Timestamp)
                .Take(limit)
                .ToListAsync();
            return Ok(logs);
        }

        // 10. Manage backups
        [HttpGet("backups")]
        public async Task<IActionResult> GetBackups() => Ok(await _db.DatabaseBackups.ToListAsync());

        [HttpPost("backups/trigger")]
        public async Task<IActionResult> TriggerBackup()
        {
            var timestamp = DateTime.UtcNow.ToString("yyyyMMdd_HHmmss");
            var backup = new DatabaseBackup
            {
                BackupName = $"KhushiFootwear_AutoBackup_{timestamp}",
                FileName = $"KhushiFootwear_{timestamp}.bak",
                FileSizeBytes = 54820100, // ~52 MB
                BackupType = "FULL",
                StoragePath = @$"D:\Sonali Projects\KhushiFootwear\database\backups\KhushiFootwear_{timestamp}.bak",
                Status = "COMPLETED",
                InitiatedBy = "Super Admin"
            };

            _db.DatabaseBackups.Add(backup);
            await _db.SaveChangesAsync();

            return Ok(new { message = "Database snapshot created successfully", fileName = backup.FileName });
        }
    }
}
