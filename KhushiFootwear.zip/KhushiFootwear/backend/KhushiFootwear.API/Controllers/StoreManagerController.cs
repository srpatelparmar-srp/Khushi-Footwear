using Microsoft.AspNetCore.Mvc;
using KhushiFootwear.API.Data;
using KhushiFootwear.API.Models;
using Microsoft.EntityFrameworkCore;

namespace KhushiFootwear.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StoreManagerController : ControllerBase
    {
        private readonly KhushiDbContext _db;

        public StoreManagerController(KhushiDbContext db)
        {
            _db = db;
        }

        // 1. View store dashboard & monitor daily sales and purchases
        [HttpGet("dashboard-summary")]
        public IActionResult GetStoreDashboard([FromQuery] int branchId = 1)
        {
            return Ok(new
            {
                branchId,
                branchName = "Central Flagship Store",
                todaySales = 148920.00,
                todayPurchases = 84500.00,
                todayTransactions = 54,
                pairsSoldToday = 342,
                pendingStockAdjustments = 3,
                activeTransfers = 2,
                staffPresent = "11 / 12 Staff",
                pendingDiscountApprovals = 1,
                lowStockCount = 6,
                dailyCashBalance = 48500.00
            });
        }

        // 2. Manage product stock & monitor low-stock products
        [HttpGet("stock")]
        public async Task<IActionResult> GetBranchStock([FromQuery] int branchId = 1, [FromQuery] bool onlyLowStock = false)
        {
            var query = from inv in _db.Inventory
                        join v in _db.ProductVariants on inv.VariantId equals v.VariantId
                        join p in _db.Products on v.ProductId equals p.ProductId
                        join s in _db.ShoeSizes on v.SizeId equals s.SizeId
                        join c in _db.ShoeColors on v.ColorId equals c.ColorId
                        where inv.BranchId == branchId
                        select new
                        {
                            inv.InventoryId,
                            inv.VariantId,
                            p.ProductName,
                            v.SKU,
                            v.Barcode,
                            s.SizeValue,
                            c.ColorName,
                            inv.QuantityOnHand,
                            inv.MinStockAlert,
                            IsLowStock = inv.QuantityOnHand <= inv.MinStockAlert
                        };

            if (onlyLowStock)
                query = query.Where(q => q.IsLowStock);

            return Ok(await query.ToListAsync());
        }

        // 3. Approve stock adjustments (damages, discrepancies)
        [HttpGet("stock-adjustments")]
        public async Task<IActionResult> GetStockAdjustments([FromQuery] int branchId = 1)
        {
            var adjustments = await _db.StockAdjustments
                .Where(a => a.BranchId == branchId)
                .OrderByDescending(a => a.CreatedAt)
                .ToListAsync();
            return Ok(adjustments);
        }

        [HttpPost("stock-adjustments/approve/{id}")]
        public async Task<IActionResult> ApproveStockAdjustment(long id, [FromQuery] int managerUserId = 3, [FromBody] string? notes = null)
        {
            var adj = await _db.StockAdjustments.FindAsync(id);
            if (adj == null) return NotFound(new { message = "Stock adjustment not found" });

            adj.Status = "APPROVED";
            adj.ApprovedByUserId = managerUserId;
            adj.ApprovalNotes = notes ?? "Approved by Store Manager";
            adj.ApprovedAt = DateTime.UtcNow;

            // Update physical inventory
            var inv = await _db.Inventory.FirstOrDefaultAsync(i => i.BranchId == adj.BranchId && i.VariantId == adj.VariantId);
            if (inv != null)
            {
                inv.QuantityOnHand = adj.NewStock;
            }

            await _db.SaveChangesAsync();
            return Ok(new { message = "Stock adjustment approved and inventory quantity adjusted", adjustmentNumber = adj.AdjustmentNumber });
        }

        // 4. Manage stock transfers
        [HttpGet("stock-transfers")]
        public async Task<IActionResult> GetStockTransfers([FromQuery] int branchId = 1)
        {
            var transfers = await _db.StockTransfers
                .Where(t => t.SourceBranchId == branchId || t.DestinationBranchId == branchId)
                .OrderByDescending(t => t.DispatchDate)
                .ToListAsync();
            return Ok(transfers);
        }

        [HttpPost("stock-transfers")]
        public async Task<IActionResult> CreateStockTransfer([FromBody] StockTransfer transfer)
        {
            transfer.TransferNumber = "TRF-" + DateTime.UtcNow.Ticks.ToString()[^6..];
            transfer.DispatchDate = DateTime.UtcNow;
            transfer.Status = "IN_TRANSIT";

            _db.StockTransfers.Add(transfer);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Inter-branch transfer dispatched", transferNumber = transfer.TransferNumber });
        }

        // 5. Manage employee attendance
        [HttpGet("attendance")]
        public async Task<IActionResult> GetDailyAttendance([FromQuery] int branchId = 1, [FromQuery] DateTime? date = null)
        {
            var targetDate = date?.Date ?? DateTime.UtcNow.Date;
            var attendance = await (from a in _db.EmployeeAttendances
                                   join u in _db.Users on a.UserId equals u.UserId
                                   join r in _db.Roles on u.RoleId equals r.RoleId
                                   where a.BranchId == branchId && a.WorkDate == targetDate
                                   select new
                                   {
                                       a.AttendanceId,
                                       u.FullName,
                                       RoleName = r.RoleName,
                                       a.WorkDate,
                                       a.CheckInTime,
                                       a.CheckOutTime,
                                       a.Status,
                                       a.Remarks
                                   }).ToListAsync();
            return Ok(attendance);
        }

        [HttpPost("attendance/mark")]
        public async Task<IActionResult> MarkAttendance([FromBody] EmployeeAttendance attendance)
        {
            var existing = await _db.EmployeeAttendances
                .FirstOrDefaultAsync(a => a.UserId == attendance.UserId && a.WorkDate == attendance.WorkDate.Date);

            if (existing != null)
            {
                existing.CheckInTime = attendance.CheckInTime ?? existing.CheckInTime;
                existing.CheckOutTime = attendance.CheckOutTime ?? existing.CheckOutTime;
                existing.Status = attendance.Status;
                existing.Remarks = attendance.Remarks;
            }
            else
            {
                _db.EmployeeAttendances.Add(attendance);
            }

            await _db.SaveChangesAsync();
            return Ok(new { message = "Employee attendance recorded successfully" });
        }

        // 6. Approve cashier discounts
        [HttpGet("discounts/pending")]
        public async Task<IActionResult> GetPendingDiscountApprovals([FromQuery] int branchId = 1)
        {
            var pending = await _db.DiscountApprovals
                .Where(d => d.BranchId == branchId && d.Status == "PENDING")
                .ToListAsync();
            return Ok(pending);
        }

        [HttpPost("discounts/decision/{id}")]
        public async Task<IActionResult> DecideDiscount(long id, [FromQuery] bool approve = true, [FromQuery] int managerId = 3)
        {
            var discount = await _db.DiscountApprovals.FindAsync(id);
            if (discount == null) return NotFound();

            discount.Status = approve ? "APPROVED" : "REJECTED";
            discount.ApprovedByManagerId = managerId;

            await _db.SaveChangesAsync();
            return Ok(new { message = $"Discount request {discount.Status}", approvalId = discount.ApprovalId });
        }

        // 7. Manage returns and exchanges
        [HttpGet("returns-and-exchanges")]
        public async Task<IActionResult> GetBranchReturns([FromQuery] int branchId = 1)
        {
            var returns = await _db.ReturnsAndExchanges
                .OrderByDescending(r => r.ReturnId)
                .Take(20)
                .ToListAsync();
            return Ok(returns);
        }

        // 8. View daily closing reports & perform day-end register closing
        [HttpGet("closing-report/preview")]
        public IActionResult GetDailyClosingPreview([FromQuery] int branchId = 1)
        {
            return Ok(new
            {
                branchId,
                closingDate = DateTime.UtcNow.Date,
                openingCash = 5000.00,
                cashSales = 48500.00,
                upiSales = 84200.00,
                cardSales = 16220.00,
                totalDailySales = 148920.00,
                dayExpenses = 3200.00,
                expectedPhysicalCash = 50300.00, // opening + cashSales - dayExpenses
                pairsSold = 342,
                returnsCount = 3,
                status = "Ready for Store Manager Signoff"
            });
        }

        [HttpPost("closing-report/submit")]
        public async Task<IActionResult> SubmitClosingReport([FromBody] DailyClosingReport report)
        {
            report.CreatedAt = DateTime.UtcNow;
            _db.DailyClosingReports.Add(report);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Day closing report submitted and locked successfully", reportId = report.ReportId });
        }
    }
}
