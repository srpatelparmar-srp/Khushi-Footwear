using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using KhushiFootwear.API.Data;
using KhushiFootwear.API.Models;

namespace KhushiFootwear.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class SalesExecutiveController : ControllerBase
    {
        private readonly KhushiDbContext _context;

        public SalesExecutiveController(KhushiDbContext context)
        {
            _context = context;
        }

        // 1. Register New Customers
        [HttpPost("customers/register")]
        public async Task<IActionResult> RegisterCustomer([FromBody] Customer customer)
        {
            if (string.IsNullOrWhiteSpace(customer.FullName) || string.IsNullOrWhiteSpace(customer.Mobile))
            {
                return BadRequest("Customer full name and mobile number are required.");
            }

            var existing = await _context.Customers.FirstOrDefaultAsync(c => c.Mobile == customer.Mobile);
            if (existing != null)
            {
                return Ok(new { Message = "Customer already registered with this mobile number.", Customer = existing });
            }

            if (customer.ShopId <= 0) customer.ShopId = 1;
            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();
            return Ok(new { Message = "Customer registered successfully.", Customer = customer });
        }

        // 2. View Customer Details
        [HttpGet("customers")]
        public async Task<IActionResult> GetCustomers([FromQuery] string? search)
        {
            var query = _context.Customers.AsQueryable();
            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(c => c.FullName.Contains(search) || c.Mobile.Contains(search));
            }
            var list = await query.OrderByDescending(c => c.CustomerId).Take(50).ToListAsync();
            return Ok(list);
        }

        // 3. Search Footwear Products
        [HttpGet("products/search")]
        public async Task<IActionResult> SearchProducts([FromQuery] string? query, [FromQuery] int? categoryId, [FromQuery] int? brandId)
        {
            var q = _context.Products.Where(p => p.IsActive).AsQueryable();

            if (!string.IsNullOrWhiteSpace(query))
            {
                q = q.Where(p => p.ProductName.Contains(query) || (p.ArticleNumber != null && p.ArticleNumber.Contains(query)) || (p.Brand != null && p.Brand.Contains(query)));
            }
            if (categoryId.HasValue) q = q.Where(p => p.CategoryId == categoryId.Value);

            var products = await q.ToListAsync();
            return Ok(products);
        }

        // 4. Check Product Availability & 5. Check Shoe Sizes and Colors
        [HttpGet("products/{productId}/availability")]
        public async Task<IActionResult> CheckProductAvailability(int productId)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product == null) return NotFound("Product not found.");

            var variants = await _context.ProductVariants
                .Where(v => v.ProductId == productId && v.IsActive)
                .Join(_context.ShoeSizes, v => v.SizeId, s => s.SizeId, (v, s) => new { v, s })
                .Join(_context.ShoeColors, vs => vs.v.ColorId, c => c.ColorId, (vs, c) => new
                {
                    vs.v.VariantId,
                    vs.v.SKU,
                    vs.v.Barcode,
                    Size = vs.s.SizeNumber,
                    SizeUnit = vs.s.StandardUnit,
                    Color = c.ColorName,
                    ColorHex = c.ColorHex,
                    vs.v.SellingPrice,
                    vs.v.MRP
                })
                .ToListAsync();

            var variantIds = variants.Select(v => v.VariantId).ToList();
            var stocks = await _context.Inventory
                .Where(i => variantIds.Contains(i.VariantId))
                .ToListAsync();

            var result = variants.Select(v =>
            {
                var inv = stocks.FirstOrDefault(s => s.VariantId == v.VariantId);
                var qty = inv?.QuantityOnHand ?? 0;
                return new
                {
                    v.VariantId,
                    v.SKU,
                    v.Barcode,
                    v.Size,
                    v.SizeUnit,
                    v.Color,
                    v.ColorHex,
                    v.SellingPrice,
                    v.MRP,
                    QuantityOnHand = qty,
                    AvailabilityStatus = qty > 0 ? (qty <= 3 ? "LOW_STOCK" : "IN_STOCK") : "OUT_OF_STOCK"
                };
            });

            return Ok(new
            {
                Product = product,
                Variants = result
            });
        }

        // 6. Create Sales Orders
        [HttpPost("orders/create")]
        public async Task<IActionResult> CreateSalesOrder([FromBody] SalesInvoice order)
        {
            if (string.IsNullOrWhiteSpace(order.InvoiceNumber))
            {
                order.InvoiceNumber = $"ORD-EX-{DateTime.UtcNow:yyyyMMddHHmmss}";
            }
            order.InvoiceDate = DateTime.UtcNow;
            order.Status = "CONFIRMED";
            _context.SalesInvoices.Add(order);
            await _context.SaveChangesAsync();
            return Ok(order);
        }

        // 7. Manage Customer Enquiries & 8. Follow up with Customers
        [HttpGet("enquiries")]
        public async Task<IActionResult> GetEnquiries([FromQuery] string? status)
        {
            var query = _context.CustomerEnquiries.AsQueryable();
            if (!string.IsNullOrWhiteSpace(status))
            {
                query = query.Where(e => e.Status == status);
            }
            var list = await query.OrderByDescending(e => e.CreatedAt).ToListAsync();
            return Ok(list);
        }

        [HttpPost("enquiries")]
        public async Task<IActionResult> AddEnquiry([FromBody] CustomerEnquiry enquiry)
        {
            _context.CustomerEnquiries.Add(enquiry);
            await _context.SaveChangesAsync();
            return Ok(enquiry);
        }

        [HttpPatch("enquiries/{enquiryId}/status")]
        public async Task<IActionResult> UpdateEnquiryStatus(int enquiryId, [FromQuery] string status, [FromQuery] DateTime? followUpDate)
        {
            var enquiry = await _context.CustomerEnquiries.FindAsync(enquiryId);
            if (enquiry == null) return NotFound("Enquiry not found.");

            enquiry.Status = status;
            if (followUpDate.HasValue) enquiry.NextFollowUpDate = followUpDate.Value;

            await _context.SaveChangesAsync();
            return Ok(enquiry);
        }

        // 9. Manage Product Recommendations
        [HttpGet("recommendations")]
        public async Task<IActionResult> GetRecommendations([FromQuery] string? brand, [FromQuery] string? category)
        {
            var query = _context.Products.Where(p => p.IsActive).AsQueryable();
            if (!string.IsNullOrWhiteSpace(brand))
            {
                query = query.Where(p => p.Brand == brand);
            }

            var recommendations = await query.Take(6).ToListAsync();
            return Ok(recommendations);
        }

        // 10. View Personal Sales Targets & 11. View Sales Performance & 12. View Commission Reports
        [HttpGet("performance/{userId}")]
        public async Task<IActionResult> GetPerformance(int userId)
        {
            var targets = await _context.SalesTargets
                .Where(t => t.UserId == userId)
                .OrderByDescending(t => t.TargetId)
                .ToListAsync();

            var currentTarget = targets.FirstOrDefault();
            var totalCommission = targets.Sum(t => t.CommissionEarned);
            var totalSales = targets.Sum(t => t.AchievedAmount);

            return Ok(new
            {
                UserId = userId,
                CurrentTarget = currentTarget,
                TotalSalesAchieved = totalSales,
                TotalCommissionEarned = totalCommission,
                TargetHistory = targets
            });
        }
    }
}
