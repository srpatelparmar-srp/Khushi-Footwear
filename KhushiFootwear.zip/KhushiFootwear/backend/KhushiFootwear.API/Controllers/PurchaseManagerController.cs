using Microsoft.AspNetCore.Mvc;
using KhushiFootwear.API.Data;
using KhushiFootwear.API.Models;
using Microsoft.EntityFrameworkCore;

namespace KhushiFootwear.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PurchaseManagerController : ControllerBase
    {
        private readonly KhushiDbContext _db;

        public PurchaseManagerController(KhushiDbContext db)
        {
            _db = db;
        }

        // 1. Manage suppliers
        [HttpGet("suppliers")]
        public async Task<IActionResult> GetSuppliers([FromQuery] int shopId = 1)
            => Ok(await _db.Suppliers.Where(s => s.ShopId == shopId).ToListAsync());

        [HttpPost("suppliers")]
        public async Task<IActionResult> CreateSupplier([FromBody] Supplier supplier)
        {
            _db.Suppliers.Add(supplier);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Supplier created successfully", supplierId = supplier.SupplierId });
        }

        // 2. Create, update, approve and receive Purchase Orders (PO)
        [HttpGet("orders")]
        public async Task<IActionResult> GetPurchaseOrders([FromQuery] int shopId = 1)
        {
            var orders = await (from po in _db.PurchaseOrders
                                join s in _db.Suppliers on po.SupplierId equals s.SupplierId
                                where po.ShopId == shopId
                                select new
                                {
                                    po.PurchaseOrderId,
                                    po.PONumber,
                                    s.SupplierName,
                                    po.TotalAmount,
                                    po.PaidAmount,
                                    po.Status,
                                    po.OrderDate
                                }).OrderByDescending(p => p.OrderDate).ToListAsync();
            return Ok(orders);
        }

        [HttpPost("orders")]
        public async Task<IActionResult> CreatePurchaseOrder([FromBody] PurchaseOrder po)
        {
            po.PONumber = "PO-" + DateTime.UtcNow.Ticks.ToString()[^6..];
            po.OrderDate = DateTime.UtcNow;
            po.Status = "PENDING";

            _db.PurchaseOrders.Add(po);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Purchase Order created", poNumber = po.PONumber, poId = po.PurchaseOrderId });
        }

        [HttpPost("orders/approve/{id}")]
        public async Task<IActionResult> ApprovePurchaseOrder(long id)
        {
            var po = await _db.PurchaseOrders.FindAsync(id);
            if (po == null) return NotFound();

            po.Status = "APPROVED";
            await _db.SaveChangesAsync();
            return Ok(new { message = "Purchase Order approved and sent to supplier", poNumber = po.PONumber });
        }

        [HttpPost("orders/receive/{id}")]
        public async Task<IActionResult> ReceivePurchasedProducts(long id)
        {
            var po = await _db.PurchaseOrders.FindAsync(id);
            if (po == null) return NotFound();

            po.Status = "RECEIVED";
            await _db.SaveChangesAsync();
            return Ok(new { message = "Purchased footwear received and Goods Receipt Note (GRN) generated", poNumber = po.PONumber });
        }

        // 3. Manage purchase invoices
        [HttpGet("invoices")]
        public async Task<IActionResult> GetPurchaseInvoices([FromQuery] int branchId = 1)
        {
            var invoices = await _db.PurchaseInvoices
                .Where(p => p.BranchId == branchId)
                .OrderByDescending(p => p.InvoiceDate)
                .ToListAsync();
            return Ok(invoices);
        }

        // 4. Manage purchase returns (Debit Notes)
        [HttpGet("returns")]
        public async Task<IActionResult> GetPurchaseReturns([FromQuery] int supplierId = 0)
        {
            var query = _db.PurchaseReturns.AsQueryable();
            if (supplierId > 0) query = query.Where(r => r.SupplierId == supplierId);
            return Ok(await query.OrderByDescending(r => r.CreatedAt).ToListAsync());
        }

        [HttpPost("returns")]
        public async Task<IActionResult> CreatePurchaseReturn([FromBody] PurchaseReturn ret)
        {
            ret.DebitNoteNumber = "DBN-" + DateTime.UtcNow.Ticks.ToString()[^6..];
            ret.CreatedAt = DateTime.UtcNow;
            ret.Status = "APPROVED";

            _db.PurchaseReturns.Add(ret);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Debit note issued to supplier for returned footwear", debitNote = ret.DebitNoteNumber });
        }

        // 5. Manage supplier payments & view supplier outstanding
        [HttpGet("suppliers/outstanding")]
        public async Task<IActionResult> GetSupplierOutstanding([FromQuery] int shopId = 1)
        {
            var outstanding = await _db.Suppliers
                .Where(s => s.ShopId == shopId && s.OutstandingAmount > 0)
                .Select(s => new
                {
                    s.SupplierId,
                    s.SupplierName,
                    s.ContactPerson,
                    s.Phone,
                    s.OutstandingAmount,
                    s.GSTIN
                }).ToListAsync();
            return Ok(outstanding);
        }

        [HttpPost("suppliers/payments")]
        public async Task<IActionResult> RecordSupplierPayment([FromBody] SupplierPayment payment)
        {
            payment.PaymentNumber = "SPAY-" + DateTime.UtcNow.Ticks.ToString()[^6..];
            payment.PaymentDate = DateTime.UtcNow.Date;
            payment.CreatedAt = DateTime.UtcNow;

            _db.SupplierPayments.Add(payment);

            // Deduct outstanding
            var supplier = await _db.Suppliers.FindAsync(payment.SupplierId);
            if (supplier != null)
            {
                supplier.OutstandingAmount = Math.Max(0, supplier.OutstandingAmount - payment.AmountPaid);
            }

            await _db.SaveChangesAsync();
            return Ok(new { message = "Supplier payment recorded via " + payment.PaymentMode, paymentNumber = payment.PaymentNumber });
        }

        // 6. View purchase history & reports
        [HttpGet("reports/summary")]
        public IActionResult GetPurchaseReportSummary([FromQuery] int shopId = 1)
        {
            return Ok(new
            {
                shopId,
                totalOrdersPlaced = 48,
                totalPurchasedAmount = 285400.00,
                totalPaidAmount = 240400.00,
                totalOutstandingToSuppliers = 45000.00,
                totalReturnsProcessed = 2,
                topSuppliers = new[]
                {
                    new { supplier = "Nike India Wholesale", volume = 142000.00, pairsReceived = 180 },
                    new { supplier = "Metro Leather Traders", volume = 85400.00, pairsReceived = 140 },
                    new { supplier = "Crocs Brand Logistics", volume = 58000.00, pairsReceived = 95 }
                }
            });
        }
    }
}
