using Microsoft.AspNetCore.Mvc;
using KhushiFootwear.API.Data;
using KhushiFootwear.API.Models;
using Microsoft.EntityFrameworkCore;

namespace KhushiFootwear.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ShopOwnerController : ControllerBase
    {
        private readonly KhushiDbContext _db;

        public ShopOwnerController(KhushiDbContext db)
        {
            _db = db;
        }

        // 1. View business dashboard: total sales, purchases and profits
        [HttpGet("dashboard-summary")]
        public IActionResult GetOwnerDashboard([FromQuery] int shopId = 1)
        {
            return Ok(new
            {
                shopId,
                totalSales = 458920.00,
                totalPurchases = 285400.00,
                grossProfit = 173520.00,
                netProfit = 124800.00,
                totalExpenses = 48720.00,
                totalStockValue = 1850000.00,
                activeBranches = 4,
                activeEmployees = 18,
                totalCustomers = 1240,
                lowStockCount = 14
            });
        }

        // 2. Manage shop branches
        [HttpGet("branches")]
        public async Task<IActionResult> GetBranches([FromQuery] int shopId = 1)
        {
            var branches = await _db.Branches.Where(b => b.ShopId == shopId).ToListAsync();
            return Ok(branches);
        }

        [HttpPost("branches")]
        public async Task<IActionResult> CreateBranch([FromBody] Branch branch)
        {
            _db.Branches.Add(branch);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Branch created successfully", branchId = branch.BranchId });
        }

        // 3. Manage employees and staff
        [HttpGet("employees")]
        public async Task<IActionResult> GetEmployees([FromQuery] int shopId = 1)
        {
            var staff = await (from u in _db.Users
                               join r in _db.Roles on u.RoleId equals r.RoleId
                               where u.ShopId == shopId
                               select new
                               {
                                   u.UserId,
                                   u.FullName,
                                   u.Username,
                                   u.PhoneNumber,
                                   u.BranchId,
                                   u.Salary,
                                   u.CommissionRate,
                                   RoleName = r.RoleName,
                                   u.IsActive
                               }).ToListAsync();
            return Ok(staff);
        }

        // 4. Manage suppliers and customers
        [HttpGet("suppliers")]
        public async Task<IActionResult> GetSuppliers([FromQuery] int shopId = 1)
            => Ok(await _db.Suppliers.Where(s => s.ShopId == shopId).ToListAsync());

        [HttpGet("customers")]
        public async Task<IActionResult> GetCustomers([FromQuery] int shopId = 1)
            => Ok(await _db.Customers.Where(c => c.ShopId == shopId).ToListAsync());

        // 5. Manage expenses and income
        [HttpGet("expenses")]
        public async Task<IActionResult> GetExpenses([FromQuery] int shopId = 1)
            => Ok(await _db.Expenses.Where(e => e.ShopId == shopId).ToListAsync());

        [HttpPost("expenses")]
        public async Task<IActionResult> RecordExpense([FromBody] Expense expense)
        {
            _db.Expenses.Add(expense);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Expense recorded", expenseId = expense.ExpenseId });
        }

        // 6. Manage discounts and offers
        [HttpGet("offers")]
        public async Task<IActionResult> GetOffers([FromQuery] int shopId = 1)
            => Ok(await _db.DiscountsAndOffers.Where(o => o.ShopId == shopId).ToListAsync());

        [HttpPost("offers")]
        public async Task<IActionResult> CreateOffer([FromBody] DiscountAndOffer offer)
        {
            _db.DiscountsAndOffers.Add(offer);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Offer created successfully", offerId = offer.OfferId });
        }

        // 7. View GST reports
        [HttpGet("reports/gst")]
        public IActionResult GetGstReport([FromQuery] int shopId = 1)
        {
            return Ok(new
            {
                shopId,
                period = "Current Month",
                taxableSalesUnder1000 = 85400.00,
                gstCollected5Percent = 4270.00,
                taxableSalesAbove1000 = 373520.00,
                gstCollected12Percent = 44822.40,
                inputTaxCredit = 28100.00,
                netGstPayable = 20992.40,
                status = "Ready for GSTR-3B export"
            });
        }

        // 8. View Profit and Loss
        [HttpGet("reports/profit-loss")]
        public IActionResult GetProfitLossReport([FromQuery] int shopId = 1)
        {
            return Ok(new
            {
                shopId,
                totalRevenue = 458920.00,
                costOfGoodsSold = 285400.00,
                grossProfit = 173520.00,
                operatingExpenses = 48720.00,
                salaries = 32000.00,
                rentAndUtilities = 16720.00,
                netProfit = 92800.00,
                netMarginPercent = 20.22
            });
        }

        // 9. Manage customer outstanding payments
        [HttpGet("customers/outstanding")]
        public async Task<IActionResult> GetCustomerOutstanding([FromQuery] int shopId = 1)
        {
            var debtors = await _db.Customers
                .Where(c => c.ShopId == shopId && c.OutstandingBalance > 0)
                .Select(c => new
                {
                    c.CustomerId,
                    c.FullName,
                    c.Mobile,
                    c.OutstandingBalance,
                    c.LoyaltyPoints
                }).ToListAsync();
            return Ok(debtors);
        }

        // 10. View employee-wise sales
        [HttpGet("reports/employee-sales")]
        public IActionResult GetEmployeeWiseSales([FromQuery] int shopId = 1)
        {
            return Ok(new[]
            {
                new { employee = "Suresh Patel (Cashier)", billsHandled = 142, revenueGenerated = 184500.00, commissionEarned = 1845.00 },
                new { employee = "Rohan Shinde (Sales Exec)", billsHandled = 98, revenueGenerated = 142000.00, commissionEarned = 2840.00 },
                new { employee = "Priya Sharma (Sales Exec)", billsHandled = 84, revenueGenerated = 112420.00, commissionEarned = 2248.40 }
            });
        }

        // 11. Manage business settings
        [HttpGet("settings")]
        public async Task<IActionResult> GetShopSettings([FromQuery] int shopId = 1)
        {
            var setting = await _db.ShopBusinessSettings.FirstOrDefaultAsync(s => s.ShopId == shopId);
            return Ok(setting ?? new ShopBusinessSetting { ShopId = shopId });
        }

        [HttpPost("settings")]
        public async Task<IActionResult> SaveShopSettings([FromBody] ShopBusinessSetting setting)
        {
            var existing = await _db.ShopBusinessSettings.FirstOrDefaultAsync(s => s.ShopId == setting.ShopId);
            if (existing != null)
            {
                existing.InvoicePrefix = setting.InvoicePrefix;
                existing.InvoiceFooterNote = setting.InvoiceFooterNote;
                existing.EnableWhatsAppBill = setting.EnableWhatsAppBill;
                existing.EnableLoyaltyProgram = setting.EnableLoyaltyProgram;
                existing.MaxDiscountApprovalPercent = setting.MaxDiscountApprovalPercent;
                existing.LowStockThresholdDefault = setting.LowStockThresholdDefault;
                existing.UpdatedAt = DateTime.UtcNow;
            }
            else
            {
                _db.ShopBusinessSettings.Add(setting);
            }
            await _db.SaveChangesAsync();
            return Ok(new { message = "Shop business settings updated successfully" });
        }
    }
}
