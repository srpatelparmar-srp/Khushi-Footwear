using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using KhushiFootwear.API.Data;
using KhushiFootwear.API.Models;

namespace KhushiFootwear.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly KhushiDbContext _context;

        public CustomerController(KhushiDbContext context)
        {
            _context = context;
        }

        // 1. Register & 2. Manage Profile
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Customer customer)
        {
            if (string.IsNullOrWhiteSpace(customer.FullName) || string.IsNullOrWhiteSpace(customer.Mobile))
            {
                return BadRequest("Full Name and Mobile are required.");
            }

            var existing = await _context.Customers.FirstOrDefaultAsync(c => c.Mobile == customer.Mobile);
            if (existing != null)
            {
                return Ok(new { Message = "Customer profile already exists.", Customer = existing });
            }

            if (customer.ShopId <= 0) customer.ShopId = 1;
            customer.LoyaltyPoints = 50; // 50 welcome loyalty bonus points
            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();
            return Ok(new { Message = "Registered successfully. 50 Welcome bonus points awarded!", Customer = customer });
        }

        [HttpGet("profile/{customerId}")]
        public async Task<IActionResult> GetProfile(int customerId)
        {
            var customer = await _context.Customers.FindAsync(customerId);
            if (customer == null) return NotFound("Customer profile not found.");
            return Ok(customer);
        }

        [HttpPut("profile/{customerId}")]
        public async Task<IActionResult> UpdateProfile(int customerId, [FromBody] Customer update)
        {
            var customer = await _context.Customers.FindAsync(customerId);
            if (customer == null) return NotFound("Customer not found.");

            customer.FullName = update.FullName;
            customer.PreferredShoeSize = update.PreferredShoeSize;
            await _context.SaveChangesAsync();
            return Ok(customer);
        }

        // 3. Browse Footwear Products & 4. Category & 5. Brand & 6. Size & 7. Color & 8. Price Filters
        [HttpGet("products")]
        public async Task<IActionResult> BrowseProducts(
            [FromQuery] string? search,
            [FromQuery] int? categoryId,
            [FromQuery] string? brand,
            [FromQuery] int? sizeId,
            [FromQuery] int? colorId,
            [FromQuery] decimal? minPrice,
            [FromQuery] decimal? maxPrice)
        {
            var query = _context.Products.Where(p => p.IsActive).AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(p => p.ProductName.Contains(search) || (p.Brand != null && p.Brand.Contains(search)));
            }
            if (categoryId.HasValue) query = query.Where(p => p.CategoryId == categoryId.Value);
            if (!string.IsNullOrWhiteSpace(brand)) query = query.Where(p => p.Brand == brand);

            var products = await query.ToListAsync();

            if (minPrice.HasValue) products = products.Where(p => p.BasePrice >= minPrice.Value).ToList();
            if (maxPrice.HasValue) products = products.Where(p => p.BasePrice <= maxPrice.Value).ToList();

            return Ok(products);
        }

        // 9. View Product Details with Variants
        [HttpGet("products/{productId}")]
        public async Task<IActionResult> GetProductDetails(int productId)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product == null) return NotFound("Product not found.");

            var variants = await _context.ProductVariants
                .Where(v => v.ProductId == productId && v.IsActive)
                .Join(_context.ShoeSizes, v => v.SizeId, s => s.SizeId, (v, s) => new { v, s })
                .Join(_context.ShoeColors, vs => vs.v.ColorId, c => c.ColorId, (vs, c) => new
                {
                    vs.v.VariantId,
                    vs.v.SKU,
                    vs.v.Barcode,
                    vs.v.SellingPrice,
                    vs.v.MRP,
                    Size = vs.s.SizeNumber,
                    Color = c.ColorName,
                    ColorHex = c.ColorHex
                })
                .ToListAsync();

            var reviews = await _context.CustomerReviews
                .Where(r => r.ProductId == productId)
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();

            var avgRating = reviews.Any() ? Math.Round(reviews.Average(r => r.Rating), 1) : 4.8;

            return Ok(new
            {
                Product = product,
                Variants = variants,
                AverageRating = avgRating,
                ReviewsCount = reviews.Count,
                Reviews = reviews
            });
        }

        // 10. Wishlist Management
        [HttpGet("wishlist/{customerId}")]
        public async Task<IActionResult> GetWishlist(int customerId)
        {
            var list = await _context.CustomerWishlists
                .Where(w => w.CustomerId == customerId)
                .Join(_context.Products, w => w.ProductId, p => p.ProductId, (w, p) => new
                {
                    w.WishlistId,
                    w.ProductId,
                    p.ProductName,
                    p.Brand,
                    p.BasePrice,
                    p.ImageUrl,
                    w.AddedAt
                })
                .ToListAsync();
            return Ok(list);
        }

        [HttpPost("wishlist")]
        public async Task<IActionResult> AddToWishlist([FromBody] CustomerWishlist item)
        {
            var exists = await _context.CustomerWishlists
                .AnyAsync(w => w.CustomerId == item.CustomerId && w.ProductId == item.ProductId);
            if (exists) return Ok(new { Message = "Product is already in wishlist." });

            _context.CustomerWishlists.Add(item);
            await _context.SaveChangesAsync();
            return Ok(new { Message = "Added to wishlist.", Item = item });
        }

        [HttpDelete("wishlist/{wishlistId}")]
        public async Task<IActionResult> RemoveFromWishlist(long wishlistId)
        {
            var item = await _context.CustomerWishlists.FindAsync(wishlistId);
            if (item != null)
            {
                _context.CustomerWishlists.Remove(item);
                await _context.SaveChangesAsync();
            }
            return Ok(new { Message = "Removed from wishlist." });
        }

        // 11. Shopping Cart Management
        [HttpGet("cart/{customerId}")]
        public async Task<IActionResult> GetCart(int customerId)
        {
            var items = await _context.CustomerCartItems
                .Where(c => c.CustomerId == customerId)
                .Join(_context.ProductVariants, c => c.VariantId, v => v.VariantId, (c, v) => new { c, v })
                .Join(_context.Products, cv => cv.v.ProductId, p => p.ProductId, (cv, p) => new
                {
                    cv.c.CartItemId,
                    cv.c.CustomerId,
                    cv.c.VariantId,
                    cv.c.Quantity,
                    p.ProductName,
                    p.Brand,
                    cv.v.SellingPrice,
                    cv.v.MRP,
                    ItemTotal = cv.c.Quantity * cv.v.SellingPrice
                })
                .ToListAsync();

            var grandTotal = items.Sum(i => i.ItemTotal);
            return Ok(new { GrandTotal = grandTotal, Items = items });
        }

        [HttpPost("cart")]
        public async Task<IActionResult> AddToCart([FromBody] CustomerCartItem item)
        {
            var existing = await _context.CustomerCartItems
                .FirstOrDefaultAsync(c => c.CustomerId == item.CustomerId && c.VariantId == item.VariantId);

            if (existing != null)
            {
                existing.Quantity += item.Quantity;
            }
            else
            {
                _context.CustomerCartItems.Add(item);
            }
            await _context.SaveChangesAsync();
            return Ok(new { Message = "Cart updated successfully." });
        }

        [HttpDelete("cart/{cartItemId}")]
        public async Task<IActionResult> RemoveFromCart(long cartItemId)
        {
            var item = await _context.CustomerCartItems.FindAsync(cartItemId);
            if (item != null)
            {
                _context.CustomerCartItems.Remove(item);
                await _context.SaveChangesAsync();
            }
            return Ok(new { Message = "Item removed from cart." });
        }

        // 12. Apply Coupons
        [HttpGet("offers")]
        public async Task<IActionResult> GetActiveOffers()
        {
            var offers = await _context.DiscountsAndOffers
                .Where(d => d.IsActive && d.EndDate >= DateTime.UtcNow)
                .ToListAsync();
            return Ok(offers);
        }

        // 13. Place Orders (Online / COD)
        [HttpPost("orders/checkout")]
        public async Task<IActionResult> CheckoutOrder([FromBody] SalesInvoice order)
        {
            if (string.IsNullOrWhiteSpace(order.InvoiceNumber))
            {
                order.InvoiceNumber = $"ORD-ONL-{DateTime.UtcNow:yyyyMMddHHmmss}";
            }
            order.InvoiceDate = DateTime.UtcNow;
            order.Status = "CONFIRMED";
            _context.SalesInvoices.Add(order);
            await _context.SaveChangesAsync();

            // Register tracking record
            var tracking = new OnlineOrderTracking
            {
                InvoiceId = order.InvoiceId,
                TrackingNumber = $"TRK-{DateTime.UtcNow:yyMMdd}-{order.InvoiceId}",
                CourierPartner = "Delhivery Footwear Express",
                CurrentStatus = "ORDER_CONFIRMED",
                CurrentLocation = "Khushi Footwear Main Warehouse",
                EstimatedDeliveryDate = DateTime.UtcNow.AddDays(3),
                StatusRemarks = "Order confirmed. Awaiting packing."
            };
            _context.OnlineOrderTrackings.Add(tracking);

            // Award loyalty points
            var loyalty = new CustomerLoyaltyLedger
            {
                CustomerId = order.CustomerId ?? 1,
                PointsEarned = (int)(order.GrandTotal / 100),
                PointsRedeemed = 0,
                CurrentBalance = (int)(order.GrandTotal / 100),
                TransactionReason = $"Loyalty points on online order {order.InvoiceNumber}",
                InvoiceId = order.InvoiceId
            };
            _context.CustomerLoyaltyLedgers.Add(loyalty);

            await _context.SaveChangesAsync();

            return Ok(new
            {
                Message = "Order placed successfully!",
                Invoice = order,
                Tracking = tracking
            });
        }

        // 14. Track Orders & 15. View Order History
        [HttpGet("orders/customer/{customerId}")]
        public async Task<IActionResult> GetOrderHistory(int customerId)
        {
            var orders = await _context.SalesInvoices
                .Where(s => s.CustomerId == customerId)
                .OrderByDescending(s => s.InvoiceDate)
                .ToListAsync();
            return Ok(orders);
        }

        [HttpGet("orders/{invoiceId}/tracking")]
        public async Task<IActionResult> TrackOrder(int invoiceId)
        {
            var tracking = await _context.OnlineOrderTrackings
                .FirstOrDefaultAsync(t => t.InvoiceId == invoiceId);

            if (tracking == null)
            {
                return Ok(new
                {
                    InvoiceId = invoiceId,
                    Status = "DISPATCH_IN_PROGRESS",
                    CourierPartner = "Express Logistics",
                    CurrentLocation = "Khushi Footwear Central Store",
                    EstimatedDeliveryDate = DateTime.UtcNow.AddDays(2)
                });
            }

            return Ok(tracking);
        }

        // 16. Request Returns and Exchanges
        [HttpPost("returns/request")]
        public async Task<IActionResult> RequestReturnOrExchange([FromBody] ReturnOrExchange request)
        {
            request.ReturnDate = DateTime.UtcNow;
            request.ActionTaken = "PENDING_APPROVAL";
            _context.ReturnsAndExchanges.Add(request);
            await _context.SaveChangesAsync();
            return Ok(new { Message = "Return/Exchange request lodged successfully.", Request = request });
        }

        // 17. Submit Product Reviews
        [HttpPost("reviews")]
        public async Task<IActionResult> SubmitReview([FromBody] CustomerReview review)
        {
            _context.CustomerReviews.Add(review);
            await _context.SaveChangesAsync();
            return Ok(new { Message = "Review submitted successfully.", Review = review });
        }

        // 18. Loyalty Points
        [HttpGet("loyalty/{customerId}")]
        public async Task<IActionResult> GetLoyaltyPoints(int customerId)
        {
            var ledgers = await _context.CustomerLoyaltyLedgers
                .Where(l => l.CustomerId == customerId)
                .OrderByDescending(l => l.CreatedAt)
                .ToListAsync();

            var totalEarned = ledgers.Sum(l => l.PointsEarned);
            var totalRedeemed = ledgers.Sum(l => l.PointsRedeemed);
            var currentBalance = totalEarned - totalRedeemed;

            return Ok(new
            {
                CustomerId = customerId,
                CurrentBalance = currentBalance,
                History = ledgers
            });
        }
    }
}
