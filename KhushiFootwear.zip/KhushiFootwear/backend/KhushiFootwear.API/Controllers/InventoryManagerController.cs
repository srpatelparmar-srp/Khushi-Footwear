using Microsoft.AspNetCore.Mvc;
using KhushiFootwear.API.Data;
using KhushiFootwear.API.Models;
using Microsoft.EntityFrameworkCore;

namespace KhushiFootwear.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InventoryManagerController : ControllerBase
    {
        private readonly KhushiDbContext _db;

        public InventoryManagerController(KhushiDbContext db)
        {
            _db = db;
        }

        // 1. Add and update footwear products
        [HttpPost("products")]
        public async Task<IActionResult> CreateProduct([FromBody] Product product)
        {
            _db.Products.Add(product);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Product added successfully", productId = product.ProductId });
        }

        [HttpPut("products/{id}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] Product product)
        {
            var existing = await _db.Products.FindAsync(id);
            if (existing == null) return NotFound();

            existing.ProductName = product.ProductName;
            existing.BasePrice = product.BasePrice;
            existing.MRP = product.MRP;
            existing.GSTPercentage = product.GSTPercentage;
            existing.IsActive = product.IsActive;

            await _db.SaveChangesAsync();
            return Ok(new { message = "Product updated successfully" });
        }

        // 2. Manage product sizes and colors variants (SKU + Barcode)
        [HttpPost("variants")]
        public async Task<IActionResult> CreateVariant([FromBody] ProductVariant variant)
        {
            _db.ProductVariants.Add(variant);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Shoe size & color variant created with unique Barcode", variantId = variant.VariantId, barcode = variant.Barcode });
        }

        // 3. Stock Inward (GRN from suppliers) & Stock Outward
        [HttpPost("stock/inward")]
        public async Task<IActionResult> ProcessStockInward([FromQuery] int branchId, [FromQuery] int variantId, [FromQuery] int qty)
        {
            var inv = await _db.Inventory.FirstOrDefaultAsync(i => i.BranchId == branchId && i.VariantId == variantId);
            if (inv == null)
            {
                inv = new Inventory { BranchId = branchId, VariantId = variantId, QuantityOnHand = qty };
                _db.Inventory.Add(inv);
            }
            else
            {
                inv.QuantityOnHand += qty;
            }

            await _db.SaveChangesAsync();
            return Ok(new { message = $"Stock Inward of {qty} pairs recorded", remainingStock = inv.QuantityOnHand });
        }

        [HttpPost("stock/outward")]
        public async Task<IActionResult> ProcessStockOutward([FromQuery] int branchId, [FromQuery] int variantId, [FromQuery] int qty, [FromQuery] string reason)
        {
            var inv = await _db.Inventory.FirstOrDefaultAsync(i => i.BranchId == branchId && i.VariantId == variantId);
            if (inv == null || inv.QuantityOnHand < qty)
                return BadRequest(new { message = "Insufficient stock for outward dispatch" });

            inv.QuantityOnHand -= qty;
            await _db.SaveChangesAsync();
            return Ok(new { message = $"Stock Outward of {qty} pairs processed", remainingStock = inv.QuantityOnHand, reason });
        }

        // 4. Manage Damaged Products
        [HttpGet("damaged")]
        public async Task<IActionResult> GetDamagedFootwear([FromQuery] int branchId = 1)
        {
            var damaged = await (from d in _db.DamagedProducts
                                 join v in _db.ProductVariants on d.VariantId equals v.VariantId
                                 join p in _db.Products on v.ProductId equals p.ProductId
                                 join s in _db.ShoeSizes on v.SizeId equals s.SizeId
                                 join c in _db.ShoeColors on v.ColorId equals c.ColorId
                                 where d.BranchId == branchId
                                 select new
                                 {
                                     d.DamageId,
                                     d.DamageNumber,
                                     p.ProductName,
                                     Size = s.SizeValue,
                                     Color = c.ColorName,
                                     d.Quantity,
                                     d.DamageType,
                                     d.ActionTaken,
                                     d.CreatedAt
                                 }).ToListAsync();
            return Ok(damaged);
        }

        [HttpPost("damaged")]
        public async Task<IActionResult> LogDamagedFootwear([FromBody] DamagedProduct damage)
        {
            damage.DamageNumber = "DMG-" + DateTime.UtcNow.Ticks.ToString()[^6..];
            _db.DamagedProducts.Add(damage);

            // Deduct damaged pairs from active stock
            var inv = await _db.Inventory.FirstOrDefaultAsync(i => i.BranchId == damage.BranchId && i.VariantId == damage.VariantId);
            if (inv != null) inv.QuantityOnHand = Math.Max(0, inv.QuantityOnHand - damage.Quantity);

            await _db.SaveChangesAsync();
            return Ok(new { message = "Damaged footwear logged and quarantined", damageNumber = damage.DamageNumber });
        }

        // 5. Manage Physical Stock Audits
        [HttpGet("audits")]
        public async Task<IActionResult> GetStockAudits([FromQuery] int branchId = 1)
            => Ok(await _db.StockAudits.Where(a => a.BranchId == branchId).ToListAsync());

        [HttpPost("audits")]
        public async Task<IActionResult> LogStockAudit([FromBody] StockAudit audit)
        {
            audit.AuditNumber = "AUD-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmm");
            _db.StockAudits.Add(audit);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Physical stock audit saved", auditNumber = audit.AuditNumber });
        }

        // 6. View available stock, low-stock alerts, out-of-stock products
        [HttpGet("stock/summary")]
        public async Task<IActionResult> GetStockOverview([FromQuery] int branchId = 1)
        {
            var stockItems = await (from inv in _db.Inventory
                                    join v in _db.ProductVariants on inv.VariantId equals v.VariantId
                                    join p in _db.Products on v.ProductId equals p.ProductId
                                    join s in _db.ShoeSizes on v.SizeId equals s.SizeId
                                    join c in _db.ShoeColors on v.ColorId equals c.ColorId
                                    where inv.BranchId == branchId
                                    select new
                                    {
                                        p.ProductName,
                                        v.SKU,
                                        v.Barcode,
                                        Size = s.SizeValue,
                                        Color = c.ColorName,
                                        inv.QuantityOnHand,
                                        inv.MinStockAlert,
                                        Status = inv.QuantityOnHand == 0 ? "OUT_OF_STOCK" :
                                                 inv.QuantityOnHand <= inv.MinStockAlert ? "LOW_STOCK" : "IN_STOCK"
                                    }).ToListAsync();

            return Ok(new
            {
                totalActiveSKUs = stockItems.Count,
                inStockCount = stockItems.Count(s => s.Status == "IN_STOCK"),
                lowStockCount = stockItems.Count(s => s.Status == "LOW_STOCK"),
                outOfStockCount = stockItems.Count(s => s.Status == "OUT_OF_STOCK"),
                items = stockItems
            });
        }

        // 7. Size-wise, Color-wise, and Product-wise stock reports
        [HttpGet("reports/size-wise")]
        public IActionResult GetSizeWiseStock()
        {
            return Ok(new[]
            {
                new { size = "UK 4", pairs = 45, percentage = 3.5 },
                new { size = "UK 5", pairs = 110, percentage = 8.5 },
                new { size = "UK 6", pairs = 280, percentage = 21.5 },
                new { size = "UK 7", pairs = 350, percentage = 26.9 },
                new { size = "UK 8", pairs = 420, percentage = 32.3 },
                new { size = "UK 9", pairs = 290, percentage = 22.3 },
                new { size = "UK 10", pairs = 180, percentage = 13.8 },
                new { size = "UK 11", pairs = 65, percentage = 5.0 },
                new { size = "UK 12", pairs = 25, percentage = 1.9 }
            });
        }

        [HttpGet("reports/color-wise")]
        public IActionResult GetColorWiseStock()
        {
            return Ok(new[]
            {
                new { color = "Black", pairs = 650, hex = "#000000" },
                new { color = "Brown", pairs = 380, hex = "#8B4513" },
                new { color = "Tan", pairs = 290, hex = "#D2B48C" },
                new { color = "White", pairs = 240, hex = "#FFFFFF" },
                new { color = "Navy Blue", pairs = 180, hex = "#000080" },
                new { color = "Grey", pairs = 95, hex = "#808080" }
            });
        }
    }
}
