using Microsoft.EntityFrameworkCore;
using KhushiFootwear.API.Models;

namespace KhushiFootwear.API.Data
{
    public class KhushiDbContext : DbContext
    {
        public KhushiDbContext(DbContextOptions<KhushiDbContext> options) : base(options) { }

        public DbSet<Role> Roles => Set<Role>();
        public DbSet<Shop> Shops => Set<Shop>();
        public DbSet<Branch> Branches => Set<Branch>();
        public DbSet<User> Users => Set<User>();
        public DbSet<Brand> Brands => Set<Brand>();
        public DbSet<Category> Categories => Set<Category>();
        public DbSet<ShoeSize> ShoeSizes => Set<ShoeSize>();
        public DbSet<ShoeColor> ShoeColors => Set<ShoeColor>();
        public DbSet<Product> Products => Set<Product>();
        public DbSet<ProductVariant> ProductVariants => Set<ProductVariant>();
        public DbSet<Inventory> Inventory => Set<Inventory>();
        public DbSet<Customer> Customers => Set<Customer>();
        public DbSet<Supplier> Suppliers => Set<Supplier>();
        public DbSet<SalesInvoice> SalesInvoices => Set<SalesInvoice>();
        public DbSet<PurchaseOrder> PurchaseOrders => Set<PurchaseOrder>();
        public DbSet<PurchaseInvoice> PurchaseInvoices => Set<PurchaseInvoice>();
        public DbSet<PurchaseReturn> PurchaseReturns => Set<PurchaseReturn>();
        public DbSet<SupplierPayment> SupplierPayments => Set<SupplierPayment>();
        public DbSet<Expense> Expenses => Set<Expense>();
        public DbSet<ReturnOrExchange> ReturnsAndExchanges => Set<ReturnOrExchange>();

        // Inventory Manager DbSets
        public DbSet<StockAudit> StockAudits => Set<StockAudit>();
        public DbSet<DamagedProduct> DamagedProducts => Set<DamagedProduct>();

        // Cashier / POS DbSets
        public DbSet<CashCounterShift> CashCounterShifts => Set<CashCounterShift>();
        public DbSet<InvoicePayment> InvoicePayments => Set<InvoicePayment>();
        public DbSet<InvoiceDispatch> InvoiceDispatches => Set<InvoiceDispatch>();
        public DbSet<ExchangePass> ExchangePasses => Set<ExchangePass>();
        public DbSet<WhatsAppDeliveryLog> WhatsAppDeliveryLogs => Set<WhatsAppDeliveryLog>();
        public DbSet<FootwearSizeChartConversion> FootwearSizeChartConversions => Set<FootwearSizeChartConversion>();
        public DbSet<FootwearRackLocation> FootwearRackLocations => Set<FootwearRackLocation>();
        public DbSet<AiVisualProductAttribute> AiVisualProductAttributes => Set<AiVisualProductAttribute>();
        public DbSet<AiVisualSearchLog> AiVisualSearchLogs => Set<AiVisualSearchLog>();
        public DbSet<AiDemandForecast> AiDemandForecasts => Set<AiDemandForecast>();
        public DbSet<AiFestivalSeasonRule> AiFestivalSeasonRules => Set<AiFestivalSeasonRule>();
        public DbSet<AiCrossSellRule> AiCrossSellRules => Set<AiCrossSellRule>();
        public DbSet<AiCrossSellConversionLog> AiCrossSellConversionLogs => Set<AiCrossSellConversionLog>();
        public DbSet<AiShoeWearLifecycle> AiShoeWearLifecycles => Set<AiShoeWearLifecycle>();
        public DbSet<AiCustomerRetentionVoucher> AiCustomerRetentionVouchers => Set<AiCustomerRetentionVoucher>();
        public DbSet<AiDeadStockMarkdown> AiDeadStockMarkdowns => Set<AiDeadStockMarkdown>();
        public DbSet<AiVoiceQueryLog> AiVoiceQueryLogs => Set<AiVoiceQueryLog>();

        // Store Manager DbSets
        public DbSet<StockAdjustment> StockAdjustments => Set<StockAdjustment>();
        public DbSet<StockTransfer> StockTransfers => Set<StockTransfer>();
        public DbSet<EmployeeAttendance> EmployeeAttendances => Set<EmployeeAttendance>();
        public DbSet<DiscountApproval> DiscountApprovals => Set<DiscountApproval>();
        public DbSet<DailyClosingReport> DailyClosingReports => Set<DailyClosingReport>();

        // Shop Owner DbSets
        public DbSet<DiscountAndOffer> DiscountsAndOffers => Set<DiscountAndOffer>();
        public DbSet<CustomerCreditLedger> CustomerCreditLedgers => Set<CustomerCreditLedger>();
        public DbSet<ShopBusinessSetting> ShopBusinessSettings => Set<ShopBusinessSetting>();

        // Super Admin DbSets
        public DbSet<SubscriptionPlan> SubscriptionPlans => Set<SubscriptionPlan>();
        public DbSet<TaxSetting> TaxSettings => Set<TaxSetting>();
        public DbSet<SystemSetting> SystemSettings => Set<SystemSetting>();
        public DbSet<DatabaseBackup> DatabaseBackups => Set<DatabaseBackup>();
        public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

        // Accountant DbSets
        public DbSet<CashbookLedger> CashbookLedgers => Set<CashbookLedger>();
        public DbSet<BankTransaction> BankTransactions => Set<BankTransaction>();
        public DbSet<SalaryDisbursement> SalaryDisbursements => Set<SalaryDisbursement>();

        // Sales Executive DbSets
        public DbSet<CustomerEnquiry> CustomerEnquiries => Set<CustomerEnquiry>();
        public DbSet<SalesTarget> SalesTargets => Set<SalesTarget>();

        // Customer (E-Commerce) DbSets
        public DbSet<CustomerWishlist> CustomerWishlists => Set<CustomerWishlist>();
        public DbSet<CustomerCartItem> CustomerCartItems => Set<CustomerCartItem>();
        public DbSet<CustomerReview> CustomerReviews => Set<CustomerReview>();
        public DbSet<CustomerLoyaltyLedger> CustomerLoyaltyLedgers => Set<CustomerLoyaltyLedger>();
        public DbSet<OnlineOrderTracking> OnlineOrderTrackings => Set<OnlineOrderTracking>();

        // Notifications DbSet
        public DbSet<SystemNotification> SystemNotifications => Set<SystemNotification>();
    }
}
