# Khushi Footwear Shop – Enterprise ERP, POS & E-Commerce

Complete enterprise management system for **Khushi Footwear Shop** based on the specifications in `KF.txt`.

---

## 📁 Project Architecture & Directories

```text
D:\Sonali Projects\KhushiFootwear\
├── assets\
│   └── logo\
│       └── khushi_footwear_logo.svg         <-- Custom, unique brand logo
├── database\
│   └── 01_KhushiFootwear_InitialSchema.sql  <-- Strict Schema Scripts (All DB changes logged here)
├── backend\
│   └── KhushiFootwear.API\                  <-- ASP.NET Core Web API (REST + Swagger)
└── frontend\                                <-- Flutter Cross-Platform UI (Web, Desktop, Android, iOS)
    ├── lib\
    │   └── main.dart                        <-- Responsive Metronic-inspired Web & Mobile UI
    └── pubspec.yaml
```

---

## 🎨 Unique Brand Identity & Logo
- **Logo File**: [khushi_footwear_logo.svg](file:///D:/Sonali%20Projects/KhushiFootwear/assets/logo/khushi_footwear_logo.svg)
- **Concept**: Elegant blend of a sleek aerodynamic athletic footwear silhouette combined with the golden warm smile curve (representing *Khushi* / Happiness) in royal violet, neon gold, and coral tones with high-end luxury styling.

---

## 🗄️ Database Management Rule
> **Strict Policy**: No direct/ad-hoc alterations in SQL Server. All schema, table, trigger, and procedure definitions must strictly be versioned and maintained in `.sql` script files inside:
> [01_KhushiFootwear_InitialSchema.sql](file:///D:/Sonali%20Projects/KhushiFootwear/database/01_KhushiFootwear_InitialSchema.sql)

### Included Tables:
1. `Roles` (9 Granular Roles as per specs)
2. `Shops` & `Branches` (Multi-branch support)
3. `Users` (Role-based auth & salary/commissions)
4. `Brands`, `Categories`, `ShoeSizes`, `ShoeColors`
5. `Products` & `ProductVariants` (Barcode & SKU per size and color)
6. `Inventory` & `StockLedger` (Inward, outward, audit, transfers, damaged)
7. `Customers` & `Suppliers`
8. `SalesInvoices` & `SalesInvoiceItems` (POS, GST calculations, split payments)
9. `ReturnsAndExchanges` (Footwear size/color exchange workflows)
10. `PurchaseOrders` & `Expenses`
11. `AuditLogs`
12. `CustomerEnquiries` & `SalesTargets` (Sales Executive CRM & Commissions)

---

## 🌐 2. Web Application Modules (Complete 21-Module Suite)

| # | Module | Functionality & Capabilities |
|---|---|---|
| **1** | **Dashboard** | Sales (₹ 4,58,920), purchases (₹ 2,85,400), gross/net profit, expenses, stock summary |
| **2** | **User Management** | Enterprise users, 9 granular roles, permissions matrix, audit logs |
| **3** | **Branch Management** | Multi-branch details (Pune Flagship, Mumbai Suburban, Nashik, Chakan Warehouse) |
| **4** | **Category Management** | Footwear categories and subcategories (Sports, Running, Formal, Casual, Outdoor, Ethnic) |
| **5** | **Brand Management** | Footwear brands (Nike, Adidas, Puma, Bata, Woodland, Skechers, Campus) |
| **6** | **Product Management** | Footwear models, sizes (UK 6 to 11), color swatches, images, MRP, selling price |
| **7** | **Barcode Management** | Generate and print EAN-13 & Code-128 thermal shoe box labels |
| **8** | **Inventory Management** | Stock inward (GRN), outward dispatch, inter-branch transfers, audit adjustments |
| **9** | **POS Billing** | Barcode scanning, automated GST 12%, split payments (Cash/UPI/Card), thermal receipts |
| **10** | **Purchase Management** | Footwear manufacturers, Purchase Orders (PO), Goods Receipt Notes (GRN) |
| **11** | **Customer Management** | Customer profiles, shoe sizes, purchase history, loyalty rewards, credit ledger |
| **12** | **Supplier Management** | Wholesale vendor profiles, GSTIN numbers, bank details, outstanding payments |
| **13** | **Sales Management** | Counter & online sales history, invoice search, cashier daily closing shifts |
| **14** | **Return Management** | 7-day footwear sales returns, size & color exchanges, manufacturer debit notes |
| **15** | **Expense Management** | Store operating expenses (Rent, electricity, packaging, courier logistics) |
| **16** | **Accounts Management** | Daily cashbook ledger, bank reconciliation, outstanding credit dues |
| **17** | **Employee Management** | Employee directory, attendance logs, monthly salaries, incentive commissions |
| **18** | **Offer Management** | Promotional discount coupons (`FESTIVE10`, `KHUSHI500`), clearance sales |
| **19** | **Reports** | 23 business reports (Sales, purchases, stock aging, GST GSTR-3B, Profit & Loss) |
| **20** | **Notification Management** | Automated critical stock-out alerts and supplier/customer payment reminders |
| **21** | **Settings** | Shop metadata, footwear GST tax slabs, invoice prefix/footer, thermal printing, backups |

---

## 👞 4. Footwear-Specific Functionality (Complete 18-Feature Suite)

| # | Footwear Requirement | Backend API Implementation (`FootwearController.cs`) | Frontend Interface (`footwear_suite_view.dart`) |
|---|---|---|---|
| **1** | **Size-wise inventory management** | `GET /api/Footwear/inventory/matrix` | Multi-dimensional matrix tracking quantities for UK 6 to UK 11 per model |
| **2** | **Color-wise inventory management** | Variant mapping with `ShoeColors` | Live colorway stock counts with hex chips (Pure White, Triple Black, Tan) |
| **3** | **Brand-wise inventory** | `GET /api/Footwear/inventory/by-brand` | Total valuation and pair count summary for Nike, Adidas, Puma, Bata, Woodland |
| **4** | **Model-wise product management** | `GET & POST /api/Erp/products` | Model catalog (Air Max 270, Ultraboost, Smash V2, Formal Derby, Trekker) |
| **5** | **Unique SKU for every variant** | Structured `<Brand>-<Model>-<Color>-<Size>` | Automatic SKU generation (e.g. `NK-AM270-WHT-9`, `AD-UBL-BLK-8`) |
| **6** | **Unique barcode for every size & color** | EAN-13 & Code-128 thermal generator | Unique 13-digit barcode per variant with 1-click thermal adhesive print |
| **7** | **Size availability checking** | `GET /api/Footwear/check-availability` | Instant floor lookup checking UK 6-11 stock and aisle shelf locations |
| **8** | **Color availability checking** | Color stock query filter | Color shade availability chips with reserve-for-trial floor action |
| **9** | **Size exchange** | `POST /api/Footwear/exchanges/process` | 7-Day size replacement terminal swapping original size to target size |
| **10** | **Color exchange** | Variant exchange processor | Color swap handler returning original shade and issuing new color pair |
| **11** | **Damaged footwear management** | `GET & POST /api/Footwear/damaged` | Defect write-off logger (sole separation, leather tear) & vendor RTV debit notes |
| **12** | **Fast-moving product tracking** | `GET /api/Footwear/velocity/fast-and-slow` | High turn-rate velocity monitor (Nike Air Max UK 9 turn rate: 4.2 days) |
| **13** | **Slow-moving product tracking** | Aging analysis (>60 days in stock) | Automated clearance markdown and accessory bundling recommendations |
| **14** | **Seasonal offers** | `GET /api/Footwear/offers/promotions` | Festive Wedding Carnival banner with automated coupon deduction (`FESTIVE20`) |
| **15** | **Combo offers** | Sneaker + care kit bundle | Automated POS trigger: Sneaker + Nano Waterproofer Spray @ ₹ 499 (MRP ₹ 799) |
| **16** | **Buy 2 Get 1 offers** | B2G1 automated discount rule | Add 3 pairs to cart, lowest-value daily wear / sandal automatically discounted to ₹ 0 |
| **17** | **Size-wise sales reports** | `GET /api/Footwear/reports/sales-by-size` | Percentage share & revenue graph by shoe size (UK 8 at 38%, UK 9 at 32%) |
| **18** | **Brand-wise sales reports** | `GET /api/Footwear/reports/sales-by-brand` | Revenue share report by brand (Nike 31.0%, Adidas 21.5%, Puma 14.0%, Bata 12.8%) |

---

## 📊 5. Reports and Analytics Suite (Complete 23 Reports)

| # | Report Name | Description & Key Insights | API Endpoint (`ReportsController.cs`) |
|---|---|---|---|
| **1** | **Daily Sales Report** | Today's counter invoices (₹ 1,48,920), pairs sold (342 pairs), and split by UPI 65%, Cash 25%, Card 10% | `GET /api/Reports/daily-sales` |
| **2** | **Monthly Sales Report** | Month-to-date sales trajectory (₹ 4,58,920), daily run-rate (₹ 38,243/day), target attainment (76.3%) | `GET /api/Reports/monthly-sales` |
| **3** | **Yearly Sales Report** | Annual revenue (₹ 52,40,000), year-on-year growth (+22.4%), peak festive quarters | `GET /api/Reports/yearly-sales` |
| **4** | **Brand-wise Sales Report** | Revenue share: Nike (31.0%), Adidas (21.5%), Puma (14.0%), Bata (12.8%), Woodland (9.9%), Campus (8.4%) | `GET /api/Reports/brand-sales` |
| **5** | **Category-wise Sales Report** | Category share: Sports & Running (45.0%), Men Formal (28.0%), Outdoor (15.0%), Casual (12.0%) | `GET /api/Reports/category-sales` |
| **6** | **Product-wise Sales Report** | Top-selling shoe models: Nike Air Max 270 (Rank 1), Adidas Ultraboost (Rank 2), Bata Derby (Rank 3) | `GET /api/Reports/product-sales` |
| **7** | **Size-wise Sales Report** | Indian standard foot sizes: UK 8 (38.0%), UK 9 (31.9%), UK 7 (17.8%), UK 6 (8.5%), UK 10-11 (3.8%) | `GET /api/Reports/size-sales` |
| **8** | **Color-wise Sales Report** | Preference breakdown: Pure White (39.2%), Core Black (33.9%), Oxford Tan (13.7%), Navy Blue (8.9%) | `GET /api/Reports/color-sales` |
| **9** | **Cashier-wise Sales Report** | Shift turnover and cash float reconciliation: Anita Deshmukh (₹ 1,48,920 across 54 bills) | `GET /api/Reports/cashier-sales` |
| **10** | **Purchase Report** | Wholesale consignments (₹ 2,85,400 across 48 consignments), 580 pairs received, ITC claimable | `GET /api/Reports/purchase-summary` |
| **11** | **Supplier Report** | Vendor fulfillment lead times (98.5% rate) and balance ledger for Nike, Metro Traders, Crocs | `GET /api/Reports/supplier-summary` |
| **12** | **Customer Report** | 1,240 registered buyers, 68.5% repeat purchase rate, 18,200 loyalty points redeemed | `GET /api/Reports/customer-summary` |
| **13** | **Stock Report** | Consolidated inventory: 4,280 pairs across 4 outlets with total valuation of ₹ 18,50,000 | `GET /api/Reports/stock-summary` |
| **14** | **Low Stock Report** | Automated buffer alert: Woodland Trekker UK 8 (0 pairs), Puma Smash V2 UK 7 (2 pairs) | `GET /api/Reports/low-stock` |
| **15** | **Damaged Stock Report** | Factory defect claims, sole delaminations, and settled manufacturer debit notes (₹ 14,200) | `GET /api/Reports/damaged-stock` |
| **16** | **Sales Return Report** | 7-Day return audit: 8 pairs returned (1.8% return rate), 75% due to size fitting issues | `GET /api/Reports/sales-returns` |
| **17** | **Exchange Report** | Footwear size swaps (14 pairs) and color replacements (4 pairs), retaining 94.4% of sales | `GET /api/Reports/exchanges` |
| **18** | **GST Report (GSTR-3B)** | HSN 6404 compliance: Output CGST (₹ 7,977.50) + SGST (₹ 7,977.50) offset against Input ITC (₹ 34,248) | `GET /api/Reports/gst-tax` |
| **19** | **Expense Report** | Operational overheads: Showroom rent (₹ 32,000), electricity (₹ 6,450), packaging bags (₹ 4,200) | `GET /api/Reports/expenses` |
| **20** | **Profit & Loss Report** | Gross trading profit (₹ 1,73,520 at 37.8%) and net realized profit (₹ 1,24,800 at 27.2%) | `GET /api/Reports/profit-and-loss` |
| **21** | **Customer Outstanding Report** | Store credit recovery: Amit Saxena (₹ 3,450 overdue), Pooja Verma (₹ 1,800), Karan Mehra (₹ 2,200) | `GET /api/Reports/customer-outstanding` |
| **22** | **Supplier Outstanding Report** | Manufacturer payables: Metro Leather Goods Traders (₹ 45,000 due in 2 days) | `GET /api/Reports/supplier-outstanding` |
| **23** | **Employee Performance Report** | Sales staff achievements: Rahul Joshi (₹ 1,14,500 achieved, ₹ 2,862.50 commission, Gold Tier) | `GET /api/Reports/employee-performance` |

---

## 🔐 6. Common System Functionality (Complete 19-Feature Architecture)

| # | Common System Feature | Backend Architecture & Implementation | Frontend Flutter UI Capabilities |
|---|---|---|---|
| **1** | **Login and logout** | `POST /api/Auth/login` with SHA-256 / PBKDF2 hash verification | Authentication screen with role simulation and 1-click Sign Out action |
| **2** | **Forgot password** | `POST /api/Auth/forgot-password` with SMS OTP dispatch simulation | "Forgot Password?" dialog with registered mobile/username reset flow |
| **3** | **Change password** | `POST /api/Auth/change-password` with current hash check and audit log | User account security modal with password validation and instant update |
| **4** | **JWT authentication** | RFC 7519 JWT Bearer tokens with claims & authorization headers | Secure client token storage and automated bearer headers |
| **5** | **Role-based access (RBAC)** | 9 granular roles (`Super Admin`, `Shop Owner`, `Store Manager`, `Cashier`, etc.) | Dynamic shell layout and module access restriction per role |
| **6** | **Permission-based access** | Module-level read/write/approve permission flags | Action buttons conditionally rendered based on user permissions |
| **7** | **Branch-wise access** | Multi-branch tenant isolation via `ShopId` & `BranchId` query scoping | Automatic data segregation for Pune Flagship, Mumbai, and Nashik outlets |
| **8** | **Profile management** | Profile endpoints for viewing and updating user details | Account profile modal for viewing credentials, assigned outlet, and fit details |
| **9** | **Notifications** | `NotificationController.cs` & `SystemNotifications` database table | Real-time alert feed badge for critical stock-outs and payment reminders |
| **10** | **Search and filters** | Multi-field search queries (name, SKU, brand, category, barcode) | Debounced search bars and filter chips across all list views |
| **11** | **Pagination** | `Take(N)` and `Skip(N)` LINQ pagination on all large collections | Infinite-scroll & pagination controls for high-volume catalogs |
| **12** | **Excel export** | Tabular data serializer for reports and inventory | 1-Click Excel export action button on all 23 reports |
| **13** | **PDF export** | GST tax invoice, P&L statements, and debit note PDF generators | 1-Click PDF export action button with download snackbar notifications |
| **14** | **Responsive design** | Metronic-inspired adaptive layout engine | Smooth switching between Desktop side navigation rails and Mobile bottom bars |
| **15** | **Dark and light themes** | Flutter `ThemeMode.light` & `ThemeMode.dark` with Indigo/Cyan palette | Instant 1-click theme mode toggle in the top application bar |
| **16** | **Activity logs** | `AuditLogs` table logging table alterations, logouts, and approvals | Activity audit log viewer dialog in the user settings menu |
| **17** | **Data backup** | `DatabaseBackups` table and on-demand cloud snapshot endpoints | Cloud backup viewer dialog with "Take Backup Now" action trigger |
| **18** | **Secure API integration** | HTTPS redirection, strict CORS policy (`AllowAll`), parameter sanitization | Clean REST service integration with structured JSON payloads |
| **19** | **Swagger documentation** | Swashbuckle OpenAPI with JWT Bearer security schemes | Interactive API testing documentation live at `/swagger` |

---

## 🔄 7. Main Business Flow Lifecycle (End-to-End 10-Stage Pipeline)

| Stage | Business Lifecycle Stage | Responsible Role | Database Entities & API Execution | Realized Outcome & Audit Trail |
|---|---|---|---|---|
| **1** | **Super Admin creates shop and owner** | Super Admin | `POST /api/SuperAdmin/shops` & `Users` | Shop #1 ("Khushi Footwear"), Pune Flagship Branch, and Owner "rajesh.owner" created |
| **2** | **Owner creates employees and assigns roles** | Shop Owner | `POST /api/Auth/register` & `ShopOwner/employees` | Onboarded Store Manager, Head Cashier, Inventory Manager & Sales Executive |
| **3** | **Owner adds brands, categories & products** | Shop Owner | `POST /api/SuperAdmin/brands` & `Erp/products` | 84 Footwear models configured with sizes UK 6–11, colorways, and EAN-13 barcodes |
| **4** | **Purchase Manager creates purchase orders** | Purchase Manager | `POST /api/PurchaseManager/orders` | Wholesale PO-2026-088 issued to Nike India for 180 pairs (₹ 1,42,000) on 15-day credit |
| **5** | **Inventory Manager receives products & updates stock** | Inventory Manager | `POST /api/InventoryManager/grn/inward` | Barcode verification passed; GRN #GRN-088 approved; shelf stock automatically incremented |
| **6** | **Cashier generates customer bills** | Cashier | `POST /api/Cashier/pos/checkout` | Customer Amit Saxena selects Nike Air Max 270 (UK 9); barcode scanned; bill initiated |
| **7** | **System calculates GST and payments** | System Automation | POS Automated GST Calculation Engine | CGST 6% + SGST 6% (12% under HSN 6404) added; coupon applied; ₹ 9,494 collected via UPI |
| **8** | **System automatically updates inventory** | System Automation | Atomic Stock Deduction Trigger | Nike Air Max 270 (UK 9) decremented from 7 to 6 pairs; outward stock ledger posted |
| **9** | **Accountant manages income and expenses** | Accountant | `POST /api/Accountant/expenses` & `cashbook` | Daily cashbook reconciled (Safe cash + HDFC bank balance); rent voucher approved |
| **10** | **Owner monitors business performance** | Shop Owner | `GET /api/ShopOwner/dashboard-summary` & Reports | Real-time profit realized (₹ 1,24,800 at 27.2%), stock alerts reviewed, 23 reports available |

---

## 👟 8. Sales Executive Enterprise Suite
Complete Sales Executive workflow supporting:
- **Customer Registration & Loyalty**: Register walk-in buyers with instant welcome points (50 pts).
- **Customer Profiles**: View foot size preferences (UK 6 - 11), preferred brands, spend history, and visits.
- **Footwear Search & Availability**: Real-time lookup with instant stock levels (In Stock, Low Stock, Out of Stock).
- **Shoe Sizes & Color Matrix**: Size chips (UK 6 to 11) with color swatches, hex badges, barcodes & SKUs.
- **Assisted Sales Orders**: Create floor pre-bills and hand off to Cashier POS counter.
- **Customer Enquiries & Follow-ups**: Manage leads with WhatsApp/call reminders and 1-click order conversion.
- **Product Recommendations**: Curated styling deals, festive picks, and footwear care cross-sell bundles.
- **Sales Targets, Performance & Commission**: Real-time progress bar towards monthly targets, floor rank, and 2.5% incentive commission ledger.

---

## 🛒 9. Customer E-Commerce Storefront Suite
Complete customer e-commerce & self-service suite supporting:
- **Authentication & Profile**: Registration, login, profile management, and shoe fit preferences.
- **Browsing & Multi-Filter Search**: Filter footwear by Category (Sneakers, Running, Formal, Casual, Outdoor), Brand (Nike, Adidas, Puma, Bata, Woodland, Campus), Size (UK 6 - 11), Color, and Price Range.
- **Product Details & Sizing**: High-res product modals, size and color picker, specifications, and rating breakdown.
- **Wishlist & Cart**: Add to wishlist, add to cart with quantity controls, and cart counter badge.
- **Checkout, Coupons & Payments**: Coupon application (`FESTIVE10`, `KHUSHI500`), loyalty point balance deduction, Online UPI (Google Pay, PhonePe), Card / Net Banking, and Cash on Delivery (COD).
- **Tracking & History**: Live courier step-by-step dispatch tracking with Delhivery Express tracking ID and full order history.
- **Invoices, Returns & Exchanges**: Download GST PDF invoices, 7-day doorstep size/color exchange requests, and return requests.
- **Loyalty Points & Reviews**: Earn 1 pt per ₹100 spent, redeem loyalty points at checkout, and submit 5-star verified product reviews.

---

## 📱 Responsive Web & Mobile Frontend (Flutter + Metronic Style)
- Dynamic layout engine switching between desktop/web side navigation rails and mobile bottom navigation bars.
- Live role simulator switching between Super Admin, Shop Owner, Manager, Cashier, Inventory, and Customer perspectives.
- Fast POS billing interface with instant barcode scanning, size & color matrix picker, and GST billing.

---

## 📱 3. Flutter Application Functionality (Owner, Staff & Customer Apps)

### 👔 1. Owner App (`owner_app_view.dart`)
- **Business Dashboard**: Real-time revenue (₹ 1,48,920 today / ₹ 4,58,920 month), gross/net margins, inventory valuation.
- **Daily & Monthly Sales**: Sales trends, average ticket size, payment mode split (UPI 65%, Cash 25%, Card 10%), fast-moving sizes.
- **Purchase Summary**: Procurement totals (₹ 2,85,400 across 48 consignments), pairs received, input tax credit (ITC).
- **Profit & Loss**: Gross trading profit, operating overhead deductions, and net margins (27.2%).
- **Stock Alerts**: Automated warning triggers for out-of-stock and low-stock models.
- **Employee Performance**: Staff sales rankings, target achievements, and incentive commission calculations.
- **Branch-Wise Reports**: Multi-branch comparative sales, stock levels, and terminal throughput.
- **Expense Management**: Operating expense vouchers, showroom rent, electricity, packaging, and cash outflows.

### 🧑‍💼 2. Staff App (`staff_app_view.dart`)
- **Staff Login & Shift**: Cashier terminal session, active cash float (₹ 5,000 float), shift turnover status.
- **Product Search**: Rapid footwear model lookup by brand, article number, size, and color.
- **Barcode Scanning**: Laser scanner simulator with instant EAN-13 / Code-128 barcode matching and variant resolution.
- **Stock Checking**: Real-time shelf and backroom stock matrix across UK 6 to 11 and color variants.
- **POS Billing**: Rapid counter cart builder, automated GST 12% calculation, coupon deduction, instant checkout.
- **Customer Registration**: 10-second walk-in buyer registration with foot size preference and 50 loyalty points bonus.
- **Invoice Generation**: 80mm ESC/POS thermal receipt formatting with GSTIN, HSN 6404, barcode, and return policy.
- **Sales History**: Audit of completed shift receipts, cash vs UPI breakdowns, and duplicate bill reprint.

### 👟 3. Customer App (`customer_store_view.dart`)
- **Customer Registration & Profile**: Profile management, delivery address, and foot size preferences.
- **Product Catalogue**: High-res footwear catalog with brand cards and verified customer reviews.
- **Product Search & Filters**: Multi-filter search by Category, Brand, UK Size (6-11), Color, and Price.
- **Size and Color Selection**: Interactive variant chips with live stock indicators.
- **Wishlist**: Quick-save favorite shoe models with 1-click "Move to Cart".
- **Shopping Cart**: Real-time basket with quantity steppers and cart counter badge.
- **Online Orders**: Full checkout pipeline with delivery address selection.
- **Payment**: Online payment via UPI (Google Pay, PhonePe, Paytm), Card/Net Banking, and Cash on Delivery (COD).
- **Order Tracking**: Real-time step-by-step courier delivery tracker with Delhivery Express tracking ID.
- **Returns and Exchanges**: 7-Day size/color exchange with replacement variant picker and return requests.

---

## 💾 Database Architecture: Stored Procedures, Views, Sequences & Triggers

Maintained in versioned SQL file: [12_Enterprise_StoredProcedures_Views_Sequences.sql](file:///D:/Sonali%20Projects/KhushiFootwear/database/12_Enterprise_StoredProcedures_Views_Sequences.sql)

### 1. Database Sequences
- `Seq_InvoiceNumber`: Non-blocking, thread-safe sequence starting at 10001 (cached 50) for fast POS invoicing.
- `Seq_BarcodeNumber`: EAN-13/GS1 footwear barcode numbering starting at 89010000001 (cached 100).
- `Seq_PurchaseOrderNumber`: PO numbering sequence starting at 5001 (cached 20).
- `Seq_GrnNumber`: Goods Receipt Note warehouse inward numbering starting at 7001 (cached 20).
- `Seq_ReturnExchangeNumber`: RMA slip and vendor debit note numbering starting at 3001 (cached 20).

### 2. High-Performance Analytical Views
- `vw_FootwearInventoryMatrix`: Real-time matrix joining model, brand, category, size, color, stock, cost, selling price, and gross margin %.
- `vw_DailySalesSummary`: Daily sales, GST collected, discounts, and payment realization status aggregated by branch and payment mode.
- `vw_LowStockAlerts`: Dynamic scanner calculating recommended reorder units (2x threshold - stock) and estimated restocking capital.
- `vw_FootwearSalesVelocity`: 30-day velocity tracker classifying footwear variants into FAST_MOVING, REGULAR_MOVING, or SLOW_MOVING.
- `vw_ProfitAndLossMonthly`: Comprehensive store-level P&L calculating Revenue minus COGS minus Operational Expenses per month.
- `vw_CustomerOutstandingLedger`: Accounts receivable ledger for customer balances, pending credit dues, and loyalty points.
- `vw_EmployeePerformanceRankings`: Staff efficiency view tracking bills generated, revenue contribution, and average ticket size.

### 3. Core Stored Procedures
- `sp_ProcessPosBilling`: Atomic transactional POS checkout with sequence invoice assignment, customer registration, 12% GST calculation, inventory deduction, and loyalty points accrual.
- `sp_ProcessFootwearExchange`: Atomic two-way exchange processing: restocks returned size/color, deducts replacement variant, verifies stock, calculates price difference, and issues RMA slip.
- `sp_ReceiveGoodsGRN`: Inward Goods Receipt Note processor using SQL MERGE to update PO status and increment inventory across multiple variants.
- `sp_GetDashboardExecutiveSummary`: Single-roundtrip high-performance summary returning today's sales, month-to-date turnover, and stock valuation.
- `sp_WriteOffDamagedFootwear`: Writes off defective/damaged pairs, generates vendor debit note, and logs operational stock loss.
- `sp_ReconcileDailyCashbook`: Computes Opening Float + Cash Sales - Cash Expenses into an expected closing drawer balance.

### 4. Database Triggers
- `trg_PreventNegativeInventory`: After update trigger enforcing an atomic rollback if footwear stock drops below zero.
- `trg_AuditInventoryStockChanges`: After update trigger logging OldQuantity, NewQuantity, Delta, SystemUser, and Timestamp into `dbo.InventoryAuditLog`.

---

## 🚀 How to Run the Solutions

### 1. Run Backend API:
```powershell
cd "D:\Sonali Projects\KhushiFootwear\backend\KhushiFootwear.API"
dotnet run
```
Access Swagger API Docs at: `https://localhost:<port>/swagger`

### 2. Run Flutter Web or Mobile:
```powershell
cd "D:\Sonali Projects\KhushiFootwear\frontend"
flutter run -d chrome    # For Web
flutter run -d windows   # For Windows Desktop
flutter run              # For Mobile / Emulators
```

